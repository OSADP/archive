/*
 * 
 */
package server.android.swri;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import server.android.swri.IClient.SocketState;
import server.android.swri.TCPClient.ReconnectLoop;
import server.android.swri.TCPClient.SocketProcessor;
import android.util.Log;

// TODO: Auto-generated Javadoc
/**
 * The Class UDPClient.
 */
public class UDPClient implements IClient
{
	
	/**
	 * The Class SocketProcessor.
	 */
	public class SocketProcessor implements Runnable
	{
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run()
		{
			try
			{
				if(mClientSocket != null)
				{
					while(mContinueProcess && mClientSocket.isConnected())
					{
						//read bytes from network stream into buffer
						Log.d(TAG, "Listening on socket: " + mClientSocket.getLocalPort());
						//int numBytes = mClientSocket.getInputStream().read(mBuffer, 0, mBuffer.length);
						
						DatagramPacket pReceived = new DatagramPacket(mBuffer, mBuffer.length, mPort);
						
						mClientSocket.receive(pReceived);
						
						//keep count if we receive nothing
						if(pReceived.getLength() == 0)
						{
							mZeroBytesReceived++;
							
							//if we have exceeded threshold show that we are disconnected
							if(mZeroBytesReceived > 4)
							{
								if(!mStateListeners.isEmpty())
								{
									fireSocketStateChangeEvent(new SocketStateChangeEvent(this, SocketState.NotConnected, mClientThread.getName()));
								}
								mContinueProcess = false;
							}
							
							//wait and try again
							else
							{
								Thread.sleep(500);
							}
						}
						
						else if(pReceived.getLength() == -1)
						{
							//disconnected
							if(mUDPClient != null)
							{
								mUDPClient.stop();
							}
						}
						
						//handle data
						else
						{
							mZeroBytesReceived = 0;
							Log.d(TAG, "Handling data");
							handleReceived(mBuffer, pReceived.getLength());
						}
					}
				}
			} 
			
			catch (IOException e)
			{
				mHasSocket = false;
				fireSocketStateChangeEvent(new SocketStateChangeEvent(mUDPClient, SocketState.NotConnected, mClientThread.getName()));
				e.printStackTrace();
				Log.d(TAG, "IOException in SocketProcessor");

			} 
			
			catch (InterruptedException e)
			{
				fireSocketStateChangeEvent(new SocketStateChangeEvent(mUDPClient, SocketState.NotConnected, mClientThread.getName()));
				e.printStackTrace();
				Log.d(TAG, "InterruptedException in SocketProcessor");
			}
		}
	}
	
	/**
	 * The Class ReconnectLoop.
	 */
	public class ReconnectLoop implements Runnable
	{

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run()
		{
			while(!connect() && mIsRunning)
			{
				try
				{
					Thread.sleep(5000);
				} 
				
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			if(mIsRunning)
			{
				start("mClientThreadName");
			}
		}
	}
	
	/**
	 * The Class SocketCreator.
	 */
	public class SocketCreator implements Runnable
	{
		
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run()
		
		{
			try
			{
				mClientSocket = new DatagramSocket(mPort);
				mHasSocket = true;
				connect();	
			} 
			
			catch (SocketException e)
			{
				mHasSocket = false;
				e.printStackTrace();
			} 
		}
	}
	
	/** The Constant BUFFER_SIZE. */
	private static final int BUFFER_SIZE = 10240;
	
	/** The m zero bytes received. */
	private int mZeroBytesReceived = 0;
	
	/** The m port. */
	private int mPort = 0;
	
	/** The m received count. */
	private int mReceivedCount = 0;
	
	/** The m buffer. */
	private byte mBuffer[] = new  byte[BUFFER_SIZE];
	
	/** The m received buffer. */
	private byte mReceivedBuffer[] = new  byte[BUFFER_SIZE];
	
	/** The m continue process. */
	private Boolean mContinueProcess = false;
	
	/** The m has socket. */
	private Boolean mHasSocket = false;
	
	/** The m is running. */
	private Boolean mIsRunning = false;
	
	/** The m processing messages. */
	private Boolean mProcessingMessages = false;
	
	/** The m client thread. */
	private Thread mClientThread = null;
	
	/** The m reconnect thread. */
	private Thread mReconnectThread = null;
	
	/** The m socket thread. */
	private Thread mSocketThread = null;
	
	/** The TAG. */
	private String TAG = "UDPClient";
	
	/** The m client thread name. */
	private String mClientThreadName = null;
	
	/** The m client socket. */
	private DatagramSocket mClientSocket = null;
	
	/** The m udp client. */
	private UDPClient mUDPClient = null;	
	
	/** The m state listeners. */
	private List<ISocketStateListener> mStateListeners;
	
	/** The m message listeners. */
	private List<ISocketMessageListener> mMessageListeners;
	
	/**
	 * Instantiates a new uDP client.
	 *
	 * @param pPort the port
	 */
	UDPClient(int pPort)
	{
		try
		{
			mPort = pPort;
			mStateListeners = new ArrayList<ISocketStateListener>();
			mMessageListeners = new ArrayList<ISocketMessageListener>();
			mUDPClient = this;

			//create socket on new thread
			if(!mHasSocket)
			{
				mSocketThread = new Thread(new SocketCreator());
				mSocketThread.setName("SocketThread :" + mPort);
				
				//this calls SocketCreator.run()
				mSocketThread.start();
			}
			
		} 
		
		catch (Exception e)
		{
			e.printStackTrace();
			Log.d(TAG, "Exception in TCPClient() constructor: " + e);
		}
	}
	
	//Events
	/**
	 * Adds the socket state listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void addSocketStateListener(ISocketStateListener pListener)
	{
		mStateListeners.add(pListener);
	}
	
	/**
	 * Removes the socket state listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void removeSocketStateListener(ISocketStateListener pListener)
	{
		mStateListeners.remove(pListener);
	}
	
	/**
	 * Adds the socket message listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void addSocketMessageListener(ISocketMessageListener pListener)
	{
		mMessageListeners.add(pListener);
	}
	
	/**
	 * Removes the socket message listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void removeSocketMessageListener(ISocketMessageListener pListener)
	{
		mMessageListeners.remove(pListener);
	}
	
	/**
	 * Removes the socket state handlers.
	 */
	private void RemoveSocketStateHandlers()
	{
		
		mStateListeners.clear();
	}
	
	/**
	 * Removes the message received handlers.
	 */
	private void RemoveMessageReceivedHandlers()
	{
		mMessageListeners.clear();
	}
	
	//Fire SocketStateChangeEvent
	/**
	 * Fire socket state change event.
	 *
	 * @param pEvent the event
	 */
	public synchronized void fireSocketStateChangeEvent(SocketStateChangeEvent pEvent)
	{
		Iterator<ISocketStateListener> listeners = mStateListeners.iterator();
		while(listeners.hasNext())
		{
			listeners.next().onSocketStateChanged(pEvent);
		}
	}
	
	//Fire SocketStateChangeEvent
	/**
	 * Fire socket message received event.
	 *
	 * @param pEvent the event
	 */
	public synchronized void fireSocketMessageReceivedEvent(ReceivedMessageFromSocket pEvent)
	{
		Iterator<ISocketMessageListener> listeners = mMessageListeners.iterator();
		while(listeners.hasNext())
		{
			listeners.next().handleReceived(pEvent);
		}
	}
	
	/**
	 * Alive.
	 *
	 * @return the boolean
	 */
	public Boolean Alive()
	{
		return mClientThread != null && mClientThread.isAlive();
	}	
	
	/**
	 * Gets the checks if is running.
	 *
	 * @return the checks if is running
	 */
	public Boolean getIsRunning()
	{
		return mIsRunning;
	}

	/**
	 * Sets the checks if is running.
	 *
	 * @param mIsRunning the new checks if is running
	 */
	public void setIsRunning(Boolean mIsRunning)
	{
		this.mIsRunning = mIsRunning;
	}

	//IClient methods:
	
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#handleReceived(byte[], int)
	 */
	public Boolean handleReceived(byte[] pData, int pDataLength)
	{
		Boolean dataHandled = false;
		
		synchronized(mReceivedBuffer)
		{
			try
			{				
				//make a new buffer if not large enough
				if(mReceivedBuffer.length < mReceivedCount + pDataLength)
				{
					byte[] temp = new byte[mReceivedCount + pDataLength];
					java.lang.System.arraycopy(mReceivedBuffer, 0, temp, 0, mReceivedCount);
					mReceivedBuffer = new byte[mReceivedCount + pDataLength];
					java.lang.System.arraycopy(temp, 0, mReceivedBuffer, 0, mReceivedCount);
				}
				
				//copy new data to buffer
				java.lang.System.arraycopy(pData, 0, mReceivedBuffer, mReceivedCount, pDataLength);
				//mReceivedCount += pDataLength;
				
				//copy first message and notify listeners when a complete message has been received
				byte[] frontMessage = new byte[pDataLength];
				java.lang.System.arraycopy(mReceivedBuffer, 0, frontMessage, 0, pDataLength);
				
				ReceivedMessageFromSocket messageReceived = new ReceivedMessageFromSocket(this, frontMessage);
				fireSocketMessageReceivedEvent(messageReceived);
			} 
			
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
				dataHandled = false;
			}
		}
		
		return dataHandled;
	}

	/* (non-Javadoc)
	 * @see server.android.swri.IClient#Connect()
	 */
	public Boolean connect()
	{
		//nothing needed for udp
		
		return true;
	}


	/* (non-Javadoc)
	 * @see server.android.swri.IClient#send(byte[])
	 */
	public Boolean send(byte[] pData)
	{
		Boolean sent = false;
		try
		{
			//mClientSocket.getOutputStream().write(pData, 0, pData.length);
			DatagramPacket toSend = new DatagramPacket(pData, pData.length, mPort);
			mClientSocket.send(toSend);
			sent = true;
		} 
		
		catch (IOException e)
		{
			e.printStackTrace();
			sent = false;
		}
		
		return sent;	
	}
	
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#start(java.lang.String)
	 */
	public Boolean start(String pThreadName)
	{
		try
		{
			if(mHasSocket)
			{
				mContinueProcess = true;
				mClientThread = new Thread(new SocketProcessor());
				mClientThread.setName(pThreadName);
				mClientThreadName = pThreadName;
				//this calls SocketProcessor.run()
				mClientThread.start();
				
				mIsRunning = true;
			}
			else
			{
				mIsRunning = false;
			}
		} 
		
		catch (Exception e)
		{
			e.printStackTrace();
			mContinueProcess = false;
			mIsRunning = false;
		}
		
		return mIsRunning;
	}
	
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#startReconnectThread()
	 */
	public void startReconnectThread()
	{
		if(mReconnectThread == null)
		{
			mReconnectThread = new Thread(new ReconnectLoop());
			mReconnectThread.start();	
		}		
	}
	
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#stop()
	 */
	public void stop()
	{
		mHasSocket = false;
		mContinueProcess = false;
		if(mClientSocket != null)
		{
			try
			{
				mClientSocket.close();
				RemoveMessageReceivedHandlers();
			} 
			
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}
