package server.android.swri;

import java.io.IOException;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckedTextView;
import android.widget.Spinner;
import android.widget.TextView;

public class SoundSpinner extends Spinner implements android.widget.AdapterView.OnItemSelectedListener {

	String[] mSounds;
	Context mContext;
	boolean ignoreSound = true;
	
	public SoundSpinner(Context context, String[] pSounds) {
		super(context);
		
		mSounds = pSounds;
		mContext = context;
		this.setOnItemSelectedListener(this);
		
	}
	

	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		
		if (!ignoreSound) {
			CharSequence soundString = ((TextView) arg1).getText();
			if (((String) soundString).equals(RsdDviConstants.RINGTONE_STRING)) {

				//play ringtone
				Uri notification = RingtoneManager
						.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
				Ringtone ringtone = RingtoneManager.getRingtone(mContext,
						notification);
				PlayAudioAlertMessage thisMessage = new PlayAudioAlertMessage(
						"Spinner Sound Message", ringtone);
				thisMessage.play();
			} else {
				AssetFileDescriptor assetFileDescriptor;
				try {
					assetFileDescriptor = mContext.getAssets().openFd(
							(String) soundString);
					PlayAudioAssetMessage thisMessage = new PlayAudioAssetMessage(
							"Spinner Sound Message", assetFileDescriptor);
					thisMessage.play();

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
		ignoreSound = false;	
	}

	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}

}
