/*
 * 
 */
package server.android.swri;

/**
 * The Class RsdDviConstants.
 */
public class RsdDviConstants {
	
	public class Header {
	
	static final int SYNC_FRAME_A = 0xFF;
	
	static final int SYNC_FRAME_B = 0x7D;
	
	static final int HEADER_LENGTH = 6;
	
	}
	
	
	/**
	 * The Enum AdvisoryType.
	 */
	public enum AdvisoryType {
	    
    	J2735_TRAVELER_ADVISORY,	    

	    CURVE_SPEED_WARNING,

	    EMERGENCY_ELECTRONIC_BRAKE_LIGHTS,
    	
	    FORWARD_COLLISION_WARNING,  
    	
    	WRONG_WAY_DRIVER;
	}
	
	public enum ShutdownType {
		
		POWER_DISCONNECT,
		
		SHUTDOWN_MSG;
	}
	

	
	
	public static class RSDSystem {
		
		/**
		 * The Enum SystemComponent.
		 */
		public enum SystemComponent {
			
			RSDCore,
			
			VehicleConnection,
			
			GPS,
			
			DAS,
			
			DVI
		}
		
		public class Component {
		
			static final int RSDCore = 0;
			
			static final int VehicleConnection = 1;
			
			static final int GPS = 2;
			
			static final int DAS = 3;
			
			static final int DVI = 4;
		}
		
		public class Status {
		
			static final int Unknown = 0;
			
			static final int Active = 1;
			
			static final int  Error = 2;
			
			static final int  Timeout = 3;
			
			static final int  Disabled = 4;
		
		}
	}
	
	/**
	 * The Class TrailerConfigData.
	 */
	public class TrailerConfigData {
		
		static final String DATA_1 = "DATA_1";
		static final String DATA_2 = "DATA_2";
		static final String DATA_3 = "DATA_3";
		static final String DATA_4 = "DATA_4";
		static final String DATA_5 = "DATA_5";
		static final String DATA_6 = "DATA_6";

		static final String TRAILER_LENGTH = "trailerLength";
		
		static final int DATA_1_BYTE_INDEX = 6;
		static final int DATA_2_BYTE_INDEX = 7;
		static final int DATA_3_BYTE_INDEX = 8;
		static final int DATA_4_BYTE_INDEX = 9;
		static final int DATA_5_BYTE_INDEX = 10;
		static final int DATA_6_BYTE_INDEX = 11;

	}
	
	public class DriverConfigData {
		
		static final String BRIGHTNESS = "brightness";
	}
	
	public class SafetyAppMessageData {
		
		/** The m advisory type byte index. */
		static final int MESSAGE_TYPE_INDEX = 6;
		
		/** The m id text byte index. */
		static final int ID_BYTE_INDEX = 7;
		
		static final int CATEGORY_BYTE_INDEX = 15;
		
		static final int PRIORITY_BYTE_INDEX = 17;
		
		static final int TITLE_LENGTH_BYTE_INDEX = 18;
		
		static final int TITLE_TEXT_BYTE_INDEX = 19;
		
	}
	
	//Messaging between Radio/AndroidService and between AndroidService/Activity
	/**
	 * The Class MessageType.
	 */
	public class MessageType {
		
		/** The Constant SYSTEM_STATUS_MESSAGE. */
		static final int SYSTEM_STATUS_MESSAGE = 1;
		
		/** The Constant TRAILER_CONFIGURATION_REQ. */
		static final int TRAILER_CONFIGURATION_REQ = 2;
	    
    	/** The Constant TRAILER_CONFIGURATION_RESP. */
    	static final int TRAILER_CONFIGURATION_RESP = 3;
	    
    	/** The Constant ADD_SAFETY_APP_MSG. */
    	static final int ADD_SAFETY_APP_MSG = 4;
	    
    	/** The Constant ACTIVATE_SAFETY_APP_MSG. */
    	static final int ACTIVATE_SAFETY_APP_MSG = 5;
	    
    	/** The Constant DEACTIVATE_SAFETY_APP_MSG. */
    	static final int DEACTIVATE_SAFETY_APP_MSG = 6;
	    
    	/** The Constant REMOVE_SAFETY_APP_MSG. */
    	static final int REMOVE_SAFETY_APP_MSG = 7;
	    
    	/** The Constant UPDATE_SAFETY_APP_MSG. */
    	static final int UPDATE_SAFETY_APP_MSG = 8;
	    
		/** The Constant SAFETY_APP_CACHE_REQ. */
		static final int SAFETY_APP_CACHE_REQ = 9;
    	
    	/** The Constant SHUTDOWN_MSG. */
	    static final int SHUTDOWN_MSG = 10;
	    
	    //these are internal to service/activity and not defined by ICD
	    /** The Constant CLEAR_DISPLAY_MSG. */
    	static final int CLEAR_DISPLAY_MSG = 11;
	    
    	/** The Constant SET_DISPLAY_MSG. */
    	static final int SET_DISPLAY_MSG = 12;
    	
    	static final int SET_DEBUG_DISPLAY_MSG = 13;
    	
    	/** The Constant SET_DISPLAY_MSG. */
    	static final int SET_STATUS_MSG = 14;
	    
    	/** The Constant PLAY_AUDIO_MSG. */
    	static final int PLAY_AUDIO_MSG = 15;
		
		/** The Constant REGISTER_CLIENT_MSG. */
		static final int REGISTER_CLIENT_MSG = 16;
		
		/** The Constant UNREGISTER_CLIENT_MSG. */
		static final int UNREGISTER_CLIENT_MSG = 17;
	}
	
	/** The Constant SHARED_PREF_FILE. */
	public static final String SHARED_PREF_FILE = "server.android.swri.prefs";
	
	public static final String RINGTONE_STRING = "RINGTONE";

}
