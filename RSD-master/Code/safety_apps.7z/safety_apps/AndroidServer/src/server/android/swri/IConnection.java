/*
 * 
 */
package server.android.swri;

/**
 * The Class IConnection.
 */
public class IConnection {

}
