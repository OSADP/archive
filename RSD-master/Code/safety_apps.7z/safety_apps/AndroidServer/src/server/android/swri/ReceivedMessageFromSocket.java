/*
 * 
 */
package server.android.swri;
import java.util.EventObject;

// TODO: Auto-generated Javadoc
/**
 * The Class ReceivedMessageFromSocket.
 */
public class ReceivedMessageFromSocket extends EventObject
{
		//variables needed in event
		/** The data. */
		private byte[] data;
		
		/**
		 * Instantiates a new received message from socket.
		 *
		 * @param source the source
		 * @param pData the data
		 */
		public ReceivedMessageFromSocket(Object source, byte[] pData){
			super(source);
			data = pData;
		}
		
		/**
		 * Data.
		 *
		 * @return the byte[]
		 */
		public byte[] Data(){
			return data;
		}	
}
