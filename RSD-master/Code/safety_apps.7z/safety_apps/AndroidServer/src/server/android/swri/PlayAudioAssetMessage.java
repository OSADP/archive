/*
 * 
 */
package server.android.swri;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import server.android.swri.RsdDviConstants.MessageType;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.util.Log;

// TODO: Auto-generated Javadoc
/**
 * The Class PlayAudioMessage.
 */
public class PlayAudioAssetMessage extends ActivityMessage implements IAudioMessage{	
	
	/**
	 * The Class AssetPlayer.
	 */
	private class AssetPlayer implements Runnable, OnErrorListener {
		
		MediaPlayer player;
		
		/**
		 * The Class StopTask.
		 */
		private class StopTask extends TimerTask{
			
			/* (non-Javadoc)
			 * @see java.util.TimerTask#run()
			 */
			@Override
			public void run(){
				stop();
			}
		}

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run(){
			player = new MediaPlayer();
			try{
				player.setOnErrorListener(this);
				player.setDataSource(mAssetFileDescriptor.getFileDescriptor(), mAssetFileDescriptor.getStartOffset(),mAssetFileDescriptor.getLength());
				player.prepare();
				player.start();
				
				//setup timer if there is a duration
				if(mDuration != -1){
					if(mStopAudioTimer != null){
						mStopAudioTimer.cancel();
					}
					mStopAudioTimer = new Timer();
					mStopAudioTimer.schedule(new StopTask(), mDuration);
				}
			}catch (IOException e1){
				e1.printStackTrace();
				if(player != null) {
					player.release();
				}

			} 	
			catch(Exception e) {
				e.printStackTrace();
				if(player != null) {
					player.release();
				}
			}
		}
		
		/**
		 * Stop.
		 */
		private void stop(){
			try {
				if(player != null) {
					player.stop();
					player.reset();
				}
				
				mStopAudioTimer.cancel();
			} catch (IllegalStateException e) {
				e.printStackTrace();
				if(player != null) {
					player.release();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				if(player != null) {
					player.release();
				}
			}
		}
		


		/* (non-Javadoc)
		 * @see android.media.MediaPlayer.OnErrorListener#onError(android.media.MediaPlayer, int, int)
		 */
		public boolean onError(MediaPlayer pMediaPlayer, int arg1, int arg2) {

			//if error set MediaPlayer to null
			if(pMediaPlayer != null)
			{
				pMediaPlayer.release();
				pMediaPlayer = null;
				Log.d(TAG, "onError() : ");
			}
			
			return false;
		}

	}
	
	/** The m asset file descriptor. */
	private AssetFileDescriptor mAssetFileDescriptor;
	
	/** The m duration. */
	private int mDuration;
	
	private String TAG = "PlayAudioAssetMessage";
	
	/** The m stop audio timer. */
	Timer mStopAudioTimer = null;
	
	/** The m player. */
	//MediaPlayer mPlayer = null;
	
	Thread mAudioThread = null;

	/**
	 * Instantiates a new play audio message.
	 *
	 * @param pMessage the message
	 * @param pAssetName the asset name
	 */
	public PlayAudioAssetMessage(String pMessage, AssetFileDescriptor pAssetName){
		//create message with no duration
		this(pMessage, pAssetName, -1);
	}
	
	/**
	 * Instantiates a new play audio message.
	 *
	 * @param pMessage the message
	 * @param pAssetName the asset name
	 * @param pDuration the duration
	 */
	public PlayAudioAssetMessage(String pMessage, AssetFileDescriptor pAssetName, int pDuration){
		super(MessageType.PLAY_AUDIO_MSG, pMessage);
		mAssetFileDescriptor = pAssetName;
		mDuration = pDuration;
	}

	/**
	 * Gets the asset file descriptor.
	 *
	 * @return the asset file descriptor
	 */
	public AssetFileDescriptor getAssetFileDescriptor(){
		return mAssetFileDescriptor;
	}

	/* (non-Javadoc)
	 * @see server.android.swri.ActivityMessage#getDuration()
	 */
	public int getDuration(){
		return mDuration;
	}

	/* (non-Javadoc)
	 * @see server.android.swri.IAudioMessage#play()
	 */
	public synchronized void play(){
		try {
			mAudioThread = new Thread(new AssetPlayer());
			mAudioThread.start();		

		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception in play() : " + e.getMessage());
		}
	}

}
