/*
 * 
 */
package server.android.swri;

import android.content.ClipData.Item;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;

// TODO: Auto-generated Javadoc
/**
 * The Class Configuration.
 */
public class Configuration{
	
	/** The m shared preferences. */
	private SharedPreferences mSharedPreferences;
	
	/** The m local cache. */
	private TreeMap<String, Object> mLocalCache;
	
	private HashMap<String, Integer> mIconMap;
	
	
	
	/** The m instance. */
	private static Configuration mInstance;
	
	/** The m context. */
	private Context mContext;
    
    /**
     * Instantiates a new configuration.
     *
     * @param pContext the context
     * @param pSharedPreferencesName the shared preferences name
     */
    private Configuration(Context pContext, String pSharedPreferencesName){
    	
    	mContext = pContext;
    	
    	mSharedPreferences = pContext.getSharedPreferences(pSharedPreferencesName, 0);

    	mLocalCache = new TreeMap<String, Object>();
    	
        //use defaults or shared preferences as configured in shared preferences
    	if(mSharedPreferences.getBoolean("UseDefaults", mContext.getResources().getBoolean(R.bool.UseDefaults))) {
    		loadDefaultValues();
    	}
    	else {
    		loadSharedPreferences();
    	}
    }

    
    /**
     * Gets the single instance of Configuration.
     *
     * @param pContext the context
     * @param pSharedPreferencesName the shared preferences name
     * @return single instance of Configuration
     */
    public static Configuration getInstance(Context pContext, String pSharedPreferencesName){
    	synchronized (Configuration.class){
			if (mInstance == null){

				mInstance = new Configuration(pContext, pSharedPreferencesName);
			}
			return mInstance;
		}
    }
    
    /**
     * Load default values.
     */
    protected void loadDefaultValues() {

    	mLocalCache.put("DelayUntilShutdown", mContext.getResources().getInteger(R.integer.DelayUntilShutdown));
    	
    	mLocalCache.put("HostIPNumber", mContext.getString(R.string.HostIPNumber));
    
    	//mLocalCache.put("TetheredHostIPNumber", mContext.getString(R.string.TetheredHostIPNumber));
    
    	//mLocalCache.put("DSRCHostIPNumber",  mContext.getString(R.string.DSRCHostIPNumber));
    	
    	//mLocalCache.put("DSRCBluetoothMacAddress", mContext.getString(R.string.DSRCBluetoothMacAddress));
    	
    	mLocalCache.put("Port",  mContext.getResources().getInteger(R.integer.Port));
    
    	mLocalCache.put("ReconnectNumAttempts",  mContext.getResources().getInteger(R.integer.ReconnectNumAttempts));
    	
    	mLocalCache.put("ReconnectWaitTime",  mContext.getResources().getInteger(R.integer.ReconnectWaitTime));
    	
    	mLocalCache.put("MessageRefreshRateInHertz",  mContext.getResources().getInteger(R.integer.MessageRefreshRateInHertz));
    	
    	mLocalCache.put("LockdownTablet",  mContext.getResources().getBoolean(R.bool.LockdownTablet));
    	
    	mLocalCache.put("GestureRecognitionThreshold",  mContext.getResources().getInteger(R.integer.GestureRecognitionThreshold));
    	
    	mLocalCache.put("SkipDemo",  mContext.getResources().getBoolean(R.bool.SkipDemo));

        mLocalCache.put("UseDefaults",  mContext.getResources().getBoolean(R.bool.UseDefaults));
        
        //mLocalCache.put("UseWiredTether",  mContext.getResources().getBoolean(R.bool.UseWiredTether));
        
        mLocalCache.put("StartOnBoot",  mContext.getResources().getBoolean(R.bool.StartOnBoot));
        
        mLocalCache.put("COLOR_Unknown", mContext.getResources().getColor(R.color.Unknown));
        
        mLocalCache.put("COLOR_Active", mContext.getResources().getColor(R.color.Active));
        
        mLocalCache.put("COLOR_Error", mContext.getResources().getColor(R.color.Error));
        
        mLocalCache.put("COLOR_Timeout", mContext.getResources().getColor(R.color.Timeout));
        
        mLocalCache.put("COLOR_Disabled", mContext.getResources().getColor(R.color.Disabled));
        
        mLocalCache.put("DebugEnabled",  mContext.getResources().getBoolean(R.bool.DebugEnabled));
        
        mLocalCache.put("DelayUntilRSDInitiatedShutdown", mContext.getResources().getInteger(R.integer.DelayUntilRSDInitiatedShutdown));
        
        mLocalCache.put("CAT_0",  mContext.getResources().getInteger(R.integer.CAT_0));
        
        mLocalCache.put("CAT_1",  mContext.getResources().getInteger(R.integer.CAT_1));
        
        mLocalCache.put("CAT_2",  mContext.getResources().getInteger(R.integer.CAT_2));
        
        mLocalCache.put("CAT_3",  mContext.getResources().getInteger(R.integer.CAT_3));
        
        mLocalCache.put("CAT_4",  mContext.getResources().getInteger(R.integer.CAT_4));
        
        mLocalCache.put("CAT_5",  mContext.getResources().getInteger(R.integer.CAT_5));
        
        mLocalCache.put("CAT_6",  mContext.getResources().getInteger(R.integer.CAT_6));
        
        mLocalCache.put("CAT_7",  mContext.getResources().getInteger(R.integer.CAT_7));
        
        mLocalCache.put("SND_J2735_TRAVELER_ADVISORY", mContext.getString(R.string.SND_J2735_TRAVELER_ADVISORY));
        
        mLocalCache.put("SND_CURVE_SPEED_WARNING_ALERT", mContext.getString(R.string.SND_CURVE_SPEED_WARNING_ALERT));
        
        mLocalCache.put("SND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS", mContext.getString(R.string.SND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS));
        
        mLocalCache.put("SND_FORWARD_COLLISION_WARNING", mContext.getString(R.string.SND_FORWARD_COLLISION_WARNING));
        
        mLocalCache.put("SND_WRONG_WAY_DRIVER", mContext.getString(R.string.SND_WRONG_WAY_DRIVER));
        
        mLocalCache.put("SND_DEFAULT", mContext.getString(R.string.SND_DEFAULT));
        
        mLocalCache.put("DisableInputSpeedThreshold",  mContext.getResources().getInteger(R.integer.DisableInputSpeedThreshold));
        
        mLocalCache.put("TimeoutInterval",  mContext.getResources().getInteger(R.integer.TimeoutInterval));
        
        mLocalCache.put("LoggingEnabled",  mContext.getResources().getBoolean(R.bool.LoggingEnabled)); 
        
        mLocalCache.put("BRIGHTNESS",  mSharedPreferences.getInt("BRIGHTNESS", mContext.getResources().getInteger(R.integer.BRIGHTNESS)));
        
        mLocalCache.put("ShutdownAudioAlertEnabled",  mContext.getResources().getBoolean(R.bool.ShutdownAudioAlertEnabled)); 
        
        mLocalCache.put("ShutdownTimerDelay",  mSharedPreferences.getInt("ShutdownTimerDelay", mContext.getResources().getInteger(R.integer.ShutdownTimerDelay)));
    }
    
    /**
     * Load shared preferences.
     */
    protected void loadSharedPreferences() {
    	
    	mLocalCache.put("DelayUntilShutdown", mSharedPreferences.getInt("DelayUntilShutdown", mContext.getResources().getInteger(R.integer.DelayUntilShutdown)));
    	
    	mLocalCache.put("HostIPNumber", mSharedPreferences.getString("HostIPNumber", mContext.getString(R.string.HostIPNumber)));
    
    	//mLocalCache.put("TetheredHostIPNumber", mSharedPreferences.getString("TetheredHostIPNumber", mContext.getString(R.string.TetheredHostIPNumber)));
    
    	//mLocalCache.put("DSRCHostIPNumber",  mSharedPreferences.getString("DSRCHostIPNumber", mContext.getString(R.string.DSRCHostIPNumber)));
    	
    	//mLocalCache.put("DSRCBluetoothMacAddress", mSharedPreferences.getString("DSRCBluetoothMacAddress", mContext.getString(R.string.DSRCBluetoothMacAddress)));
    	
    	mLocalCache.put("Port",  mSharedPreferences.getInt("Port", mContext.getResources().getInteger(R.integer.Port)));
    
    	mLocalCache.put("ReconnectNumAttempts",  mSharedPreferences.getInt("ReconnectNumAttempts", mContext.getResources().getInteger(R.integer.ReconnectNumAttempts)));
    	
    	mLocalCache.put("ReconnectWaitTime",  mSharedPreferences.getInt("ReconnectWaitTime", mContext.getResources().getInteger(R.integer.ReconnectWaitTime)));
    	
    	mLocalCache.put("MessageRefreshRateInHertz",  mSharedPreferences.getInt("MessageRefreshRateInHertz", mContext.getResources().getInteger(R.integer.MessageRefreshRateInHertz)));
    	
    	mLocalCache.put("LockdownTablet",  mSharedPreferences.getBoolean("LockdownTablet", mContext.getResources().getBoolean(R.bool.LockdownTablet)));
    	
    	mLocalCache.put("GestureRecognitionThreshold",  mSharedPreferences.getInt("GestureRecognitionThreshold", mContext.getResources().getInteger(R.integer.GestureRecognitionThreshold)));
    	
    	mLocalCache.put("SkipDemo",  mSharedPreferences.getBoolean("SkipDemo", mContext.getResources().getBoolean(R.bool.SkipDemo)));

        mLocalCache.put("UseDefaults",  mSharedPreferences.getBoolean("UseDefaults", mContext.getResources().getBoolean(R.bool.UseDefaults)));
        
        //mLocalCache.put("UseWiredTether",  mSharedPreferences.getBoolean("UseWiredTether", mContext.getResources().getBoolean(R.bool.UseWiredTether)));
        
        mLocalCache.put("StartOnBoot",  mSharedPreferences.getBoolean("StartOnBoot", mContext.getResources().getBoolean(R.bool.StartOnBoot)));
        
        mLocalCache.put("COLOR_Unknown", mSharedPreferences.getInt("COLOR_Unknown", mContext.getResources().getColor(R.color.Unknown)));
        
        int test =  mSharedPreferences.getInt("COLOR_Active", mContext.getResources().getColor(R.color.Active));
        
        mLocalCache.put("COLOR_Active", mSharedPreferences.getInt("COLOR_Active", mContext.getResources().getColor(R.color.Active)));
        
        mLocalCache.put("COLOR_Error", mSharedPreferences.getInt("COLOR_Error", mContext.getResources().getColor(R.color.Error)));
        
        mLocalCache.put("COLOR_Timeout", mSharedPreferences.getInt("COLOR_Timeout", mContext.getResources().getColor(R.color.Timeout)));
        
        mLocalCache.put("COLOR_Disabled", mSharedPreferences.getInt("COLOR_Disabled", mContext.getResources().getColor(R.color.Disabled)));
        
        mLocalCache.put("DebugEnabled",  mSharedPreferences.getBoolean("DebugEnabled", mContext.getResources().getBoolean(R.bool.DebugEnabled)));
        
        mLocalCache.put("DelayUntilRSDInitiatedShutdown", mSharedPreferences.getInt("DelayUntilRSDInitiatedShutdown", mContext.getResources().getInteger(R.integer.DelayUntilRSDInitiatedShutdown)));
        
        mLocalCache.put("LoggingEnabled",  mSharedPreferences.getBoolean("LoggingEnabled", mContext.getResources().getBoolean(R.bool.LoggingEnabled)));
        
    
        mLocalCache.put("CAT_0",  mSharedPreferences.getInt("CAT_0", mContext.getResources().getInteger(R.integer.CAT_0)));
        
        mLocalCache.put("CAT_1",  mSharedPreferences.getInt("CAT_1", mContext.getResources().getInteger(R.integer.CAT_1)));
        
        mLocalCache.put("CAT_2",  mSharedPreferences.getInt("CAT_2", mContext.getResources().getInteger(R.integer.CAT_2)));
        
        mLocalCache.put("CAT_3",  mSharedPreferences.getInt("CAT_3", mContext.getResources().getInteger(R.integer.CAT_3)));
        
        mLocalCache.put("CAT_4",  mSharedPreferences.getInt("CAT_4", mContext.getResources().getInteger(R.integer.CAT_4)));
        
        mLocalCache.put("CAT_5",  mSharedPreferences.getInt("CAT_5", mContext.getResources().getInteger(R.integer.CAT_5)));
        
        mLocalCache.put("CAT_6",  mSharedPreferences.getInt("CAT_6", mContext.getResources().getInteger(R.integer.CAT_6)));
        
        mLocalCache.put("CAT_7",  mSharedPreferences.getInt("CAT_7", mContext.getResources().getInteger(R.integer.CAT_7)));
        
        
        mLocalCache.put("SND_J2735_TRAVELER_ADVISORY", mSharedPreferences.getString("SND_J2735_TRAVELER_ADVISORY", mContext.getString(R.string.SND_J2735_TRAVELER_ADVISORY)));
        
        mLocalCache.put("SND_CURVE_SPEED_WARNING_ALERT", mSharedPreferences.getString("SND_CURVE_SPEED_WARNING_ALERT", mContext.getString(R.string.SND_CURVE_SPEED_WARNING_ALERT)));
        
        mLocalCache.put("SND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS", mSharedPreferences.getString("SND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS", mContext.getString(R.string.SND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS)));
        
        mLocalCache.put("SND_FORWARD_COLLISION_WARNING", mSharedPreferences.getString("SND_FORWARD_COLLISION_WARNING", mContext.getString(R.string.SND_FORWARD_COLLISION_WARNING)));
        
        mLocalCache.put("SND_WRONG_WAY_DRIVER", mSharedPreferences.getString("SND_WRONG_WAY_DRIVER", mContext.getString(R.string.SND_WRONG_WAY_DRIVER)));
        
        mLocalCache.put("SND_DEFAULT", mSharedPreferences.getString("SND_DEFAULT", mContext.getString(R.string.SND_DEFAULT)));
        
        mLocalCache.put("DisableInputSpeedThreshold",  mSharedPreferences.getInt("DisableInputSpeedThreshold", mContext.getResources().getInteger(R.integer.DisableInputSpeedThreshold)));
        
        mLocalCache.put("TimeoutInterval",  mSharedPreferences.getInt("TimeoutInterval", mContext.getResources().getInteger(R.integer.TimeoutInterval)));
        
        mLocalCache.put("BRIGHTNESS",  mSharedPreferences.getInt("BRIGHTNESS", mContext.getResources().getInteger(R.integer.BRIGHTNESS)));
        
        mLocalCache.put("ShutdownAudioAlertEnabled",  mSharedPreferences.getBoolean("ShutdownAudioAlertEnabled", mContext.getResources().getBoolean(R.bool.ShutdownAudioAlertEnabled)));
        
        mLocalCache.put("ShutdownTimerDelay",  mSharedPreferences.getInt("ShutdownTimerDelay", mContext.getResources().getInteger(R.integer.ShutdownTimerDelay)));
    }
    
    /**
     * Update local cache.
     *
     * @param pNewSettings the new settings
     * @return true, if successful
     */
    protected boolean updateLocalCache(TreeMap<String, Object> pNewSettings) {
		boolean toReturn = false;
		
		try {
			Iterator<String> keys = pNewSettings.keySet().iterator();
			while(keys.hasNext()) {
				String thisKey = keys.next();
				
				//update hashmap
				mLocalCache.put(thisKey, pNewSettings.get(thisKey));
				toReturn = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			toReturn = false;
		}	
    	return toReturn;
    }
    
    /**
     * Update shared preferences.
     *
     * @param pNewSettings the new settings
     * @return true, if successful
     */
    protected boolean updateSharedPreferences(TreeMap<String, Object> pNewSettings) {
		boolean toReturn = false;
		
		try {
			SharedPreferences.Editor editor = mSharedPreferences.edit();
			Iterator<String> keys = pNewSettings.keySet().iterator();
			while(keys.hasNext()) {
				String thisKey = keys.next();
				
				//update Shared Preferences 
				if(pNewSettings.get(thisKey) != null && pNewSettings.get(thisKey).getClass() == String.class) {
					editor.putString(thisKey,  (String) pNewSettings.get(thisKey));
					
				}
				else if(pNewSettings.get(thisKey) != null && pNewSettings.get(thisKey).getClass() == Integer.class) {
					editor.putInt(thisKey,  (Integer) pNewSettings.get(thisKey));
				}
				else if(pNewSettings.get(thisKey) != null && pNewSettings.get(thisKey).getClass() == Boolean.class) {
					editor.putBoolean(thisKey,  (Boolean) pNewSettings.get(thisKey));
				}
			}
			if(editor != null && editor.commit()) {
				toReturn = true;
			}
			

		} catch (Exception e) {
			e.printStackTrace();
			toReturn = false;
		}	
    	return toReturn;
    }
    

    
	/**
	 * Gets the host ip number.
	 *
	 * @return the host ip number
	 */
	public String getHostIPNumber(){
		return (String) mLocalCache.get("HostIPNumber");
	}

	/**
	 * Gets the local host ip number.
	 *
	 * @return the local host ip number
	 */
	public String getTetheredHostIPNumber(){
		return (String) mLocalCache.get("TetheredHostIPNumber");
	}
	
	/**
	 * Gets the dsrc host ip number.
	 *
	 * @return the dsrc host ip number
	 */
	public String getDsrcHostIPNumber() {
		return (String) mLocalCache.get("DsrcHostIPNumber");
	}

	/**
	 * Gets the port.
	 *
	 * @return the port
	 */
	public int getPort(){
		return (Integer) mLocalCache.get("Port");
	}

	/**
	 * Gets the reconnect num attempts.
	 *
	 * @return the reconnect num attempts
	 */
	public int getReconnectNumAttempts(){
		return (Integer) mLocalCache.get("ReconnectNumAttempts");
	}

	/**
	 * Gets the reconnect wait time.
	 *
	 * @return the reconnect wait time
	 */
	public int getReconnectWaitTime(){
		return (Integer) mLocalCache.get("ReconnectWaitTime");
	}

	/**
	 * Gets the delay until shutdown.
	 *
	 * @return the delay until shutdown
	 */
	public int getDelayUntilShutdown(){
		return (Integer) mLocalCache.get("DelayUntilShutdown");
	}
	
	/**
	 * Gets the delay until rsd initiated shutdown.
	 *
	 * @return the delay until rsd initiated shutdown
	 */
	public int getDelayUntilRSDInitiatedShutdown(){
		return (Integer) mLocalCache.get("DelayUntilRSDInitiatedShutdown");
	}
	
	

	/**
	 * Gets the message refresh rate in hertz.
	 *
	 * @return the message refresh rate in hertz
	 */
	public int getMessageRefreshRateInHertz(){
		return (Integer) mLocalCache.get("MessageRefreshRateInHertz");
	}
	
	/**
	 * Gets the message refresh rate in milliseconds.
	 *
	 * @return the message refresh rate in milliseconds
	 */
	public int getMessageRefreshRateInMilliseconds(){
		return 1000/(Integer) mLocalCache.get("MessageRefreshRateInHertz");
	}

	/**
	 * Gets the dsrc bluetooth mac address.
	 *
	 * @return the dsrc bluetooth mac address
	 */
	public String getDsrcBluetoothMacAddress() {
		return (String) mLocalCache.get("DsrcBluetoothMacAddress");
	}

	/**
	 * Gets the lockdown tablet.
	 *
	 * @return the lockdown tablet
	 */
	public boolean getLockdownTablet() {
		return (Boolean) mLocalCache.get("LockdownTablet");
	}

	/**
	 * Gets the gesture recognition threshold.
	 *
	 * @return the gesture recognition threshold
	 */
	public int getGestureRecognitionThreshold() {
		return (Integer) mLocalCache.get("GestureRecognitionThreshold");
	}
	
	/**
	 * Gets the skip demo.
	 *
	 * @return the skip demo
	 */
	public Boolean getSkipDemo() {
		return (Boolean) mLocalCache.get("SkipDemo");
	}
	
	/**
	 * Sets the skip demo.
	 *
	 * @param pSkipDemo the new skip demo
	 */
	public void setSkipDemo(Boolean pSkipDemo) {
		SharedPreferences.Editor editor = mSharedPreferences.edit();
		editor.putBoolean("SkipDemo", pSkipDemo);
		editor.commit();
		
		mLocalCache.put("SkipDemo", pSkipDemo);
	}
	
	public int getBrightness() {
		return (Integer) mLocalCache.get("BRIGHTNESS");
	}
	
	public void setBrightness(int pBrightness) {
		SharedPreferences.Editor editor = mSharedPreferences.edit();
		editor.putInt("BRIGHTNESS", pBrightness);
		editor.commit();
		
		mLocalCache.put("BRIGHTNESS", pBrightness);
	}

    /**
     * Gets the use defaults.
     *
     * @return the use defaults
     */
    public Boolean getUseDefaults() {
		return (Boolean) mLocalCache.get("UseDefaults");
	}

    /**
     * Gets the use wired tether.
     *
     * @return the use wired tether
     */
    public Boolean getUseWiredTether() {
		return (Boolean) mLocalCache.get("UseWiredTether");
	}
    
    /**
     * Gets the start on boot.
     *
     * @return the start on boot
     */
    public Boolean getStartOnBoot() {
		return (Boolean) mLocalCache.get("StartOnBoot");
	}
    
    /**
     * Gets the wireless debug enabled.
     *
     * @return the wireless debug enabled
     */
    public Boolean getDebugEnabled() {
		return (Boolean) mLocalCache.get("DebugEnabled");
	}
    
    public Boolean getLoggingEnabled() {
		return (Boolean) mLocalCache.get("LoggingEnabled");
	}
    
    
    /**
     * Gets the unknown color.
     *
     * @return the unknown color
     */
    public int getUnknownColor() {
    	return (Integer) mLocalCache.get("COLOR_Unknown");
    }
    
    /**
     * Gets the active color.
     *
     * @return the active color
     */
    public int getActiveColor() {
    	return (Integer) mLocalCache.get("COLOR_Active");
    }
    
    /**
     * Gets the error color.
     *
     * @return the error color
     */
    public int getErrorColor() {
    	return (Integer) mLocalCache.get("COLOR_Error");
    }
    
    /**
     * Gets the timeout color.
     *
     * @return the timeout color
     */
    public int getTimeoutColor() {
    	return (Integer) mLocalCache.get("COLOR_Timeout");
    }
    
    /**
     * Gets the disabled color.
     *
     * @return the disabled color
     */
    public int getDisabledColor() {
    	return (Integer) mLocalCache.get("COLOR_Disabled");
    }
    
    public int getCAT_0() {
    	return (Integer) mLocalCache.get("CAT_0");
    }
    
    public int getCAT_1() {
    	return (Integer) mLocalCache.get("CAT_1");
    }
    
    public int getCAT_2() {
    	return (Integer) mLocalCache.get("CAT_2");
    }
    
    public int getCAT_3() {
    	return (Integer) mLocalCache.get("CAT_3");
    }
    
    public int getCAT_4() {
    	return (Integer) mLocalCache.get("CAT_4");
    }
    
    public int getCAT_5() {
    	return (Integer) mLocalCache.get("CAT_5");
    }
    
    public int getCAT_6() {
    	return (Integer) mLocalCache.get("CAT_6");
    }
    
    public int getCAT_7() {
    	return (Integer) mLocalCache.get("CAT_7");
    }
    
    public int getTimeoutInterval() {
    	return (Integer) mLocalCache.get("TimeoutInterval");
    }
    
    
    
	public String getSND_J2735_TRAVELER_ADVISORY() {
		return (String) mLocalCache.get("SND_J2735_TRAVELER_ADVISORY");
	}
	
	public String getSND_CURVE_SPEED_WARNING_ALERT() {
		return (String) mLocalCache.get("SND_CURVE_SPEED_WARNING_ALERT");
	}
	
	public String getSND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS() {
		return (String) mLocalCache.get("SND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS");
	}
	
	public String getSND_FORWARD_COLLISION_WARNING() {
		return (String) mLocalCache.get("SND_FORWARD_COLLISION_WARNING");
	}
	
	public String getSND_WRONG_WAY_DRIVER() {
		return (String) mLocalCache.get("SND_WRONG_WAY_DRIVER");
	}
	
	public String getSND_DEFAULT() {
		return (String) mLocalCache.get("SND_DEFAULT");
	}
	
    public int getDisableInputSpeedThreshold() {
    	return (Integer) mLocalCache.get("DisableInputSpeedThreshold");
    }
    
	public Boolean getShutdownAudioAlertEnabled() {
		return (Boolean) mLocalCache.get("ShutdownAudioAlertEnabled");
	}
	
	public int getShutdownTimerDelay() {
		return (Integer) mLocalCache.get("ShutdownTimerDelay");
	}

	
	/**
	 * Gets the all settings.
	 *
	 * @return the all settings
	 */
	public TreeMap<String, Object> getAllSettings() {
		return mLocalCache;
	}

}
