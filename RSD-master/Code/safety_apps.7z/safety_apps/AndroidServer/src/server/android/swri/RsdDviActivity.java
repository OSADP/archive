/*
 * 
 */
package server.android.swri;

import java.io.File;
import java.util.ArrayList;

import server.android.swri.RsdDviConstants.DriverConfigData;
import server.android.swri.RsdDviConstants.MessageType;
import server.android.swri.RsdDviConstants.RSDSystem;
import server.android.swri.RsdDviConstants.TrailerConfigData;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.gesture.Prediction;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * The Class RsdDviActivity.
 */
public class RsdDviActivity extends Activity implements OnGesturePerformedListener
{ //implements OnClickListener{
	
    /**
     * Class for interacting with the main interface of the service.
     */
    private ServiceConnection mConnection = new ServiceConnection(){
        public void onServiceConnected(ComponentName className,
                IBinder service){
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  We are communicating with our
            // service through an IDL interface, so get a client-side
            // representation of that from the raw service object.
        	mServiceMessenger = new Messenger(service);

			try{
				//monitor service
				
				//send initial message to AndroidService to register for updates
				Message msg = Message.obtain(null, MessageType.REGISTER_CLIENT_MSG);
				msg.replyTo = mMessenger;
				mServiceMessenger.send(msg);
			} catch (RemoteException e){
				StringBuilder log = new StringBuilder();
				log.append("Exception : ");
				log.append(this.getClass());
				log.append(" : ");
				log.append(e.getMessage());
				Log.e(TAG, log.toString());
			}
        }

        public void onServiceDisconnected(ComponentName className) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            mService = null;
        }
    };
    
	class EventReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			
			
			
			
		}
		
	}
    
    /**
     * Handler of incoming messages from service.
     */
    class IncomingHandler extends Handler {  	
        
        /* (non-Javadoc)
         * @see android.os.Handler#handleMessage(android.os.Message)
         */
        @Override
        public void handleMessage(Message msg) {
        	
        	Message resp = null;
        	        	
			switch (msg.what) {
			case MessageType.CLEAR_DISPLAY_MSG:
				resp = Message.obtain(null, 0, 0, 0);
				/*                	Canvas c = new Canvas();
				 c.drawColor(Color.BLACK);*/
				mImageView.setImageDrawable(null);
				
				break;

			case MessageType.SET_DISPLAY_MSG:
				resp = Message.obtain(null, 0, 0, 0);

				//get display text and image from message
				SetDisplayMessage sdp = (SetDisplayMessage) msg.obj;

				mImageView.setImageResource(sdp.getmImageResID());
				mTextView.setText(sdp.getMessage());
				mDebugCountView.setText(null);
				break;
				
			case MessageType.SET_DEBUG_DISPLAY_MSG:
				resp = Message.obtain(null, 0, 0, 0);

				//get display text and image from message
				SetDebugDisplayMessage sddp = (SetDebugDisplayMessage) msg.obj;				

				mImageView.setImageResource(sddp.getmImageResID());
				mTextView.setText(sddp.getMessage());
				mDebugCountView.setText(String.valueOf(sddp.getCount()));
				
				break;
				
			case MessageType.SET_STATUS_MSG:
				resp = Message.obtain(null, 0, 0, 0);

				//get display text and image from message
				SetStatusMessage ssm = (SetStatusMessage) msg.obj;
				
				//set status icons
				setStatusInfo(ssm);

				break;

			case MessageType.PLAY_AUDIO_MSG:
				resp = Message.obtain(null, 0, 0, 0);

				//play audio
				IAudioMessage audioMsg = (IAudioMessage) msg.obj;
				audioMsg.play();
				break;

			case MessageType.TRAILER_CONFIGURATION_REQ:
				resp = Message.obtain(null, 0, 0, 0);
				
				int[] dataValues = (int[]) msg.obj;


				Intent trailerConfigIntent = new Intent();
				trailerConfigIntent.setClassName("server.android.swri", "server.android.swri.SetTrailerConfigurationActivity");
				trailerConfigIntent
						.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
	
				
				trailerConfigIntent.putExtra(TrailerConfigData.DATA_1, dataValues[0]);
				trailerConfigIntent.putExtra(TrailerConfigData.DATA_2, dataValues[1]);
				trailerConfigIntent.putExtra(TrailerConfigData.DATA_3, dataValues[2]);
				trailerConfigIntent.putExtra(TrailerConfigData.DATA_4, dataValues[3]);
				trailerConfigIntent.putExtra(TrailerConfigData.DATA_5, dataValues[4]);
				trailerConfigIntent.putExtra(TrailerConfigData.DATA_6, dataValues[5]);
				
				startActivityForResult(
						trailerConfigIntent,
						IntentRequestCodes.REQUEST_TRAILER_CONFIGURATION_INFO);

				break;
	
				default:
					super.handleMessage(msg);
				}
				try {
					if (resp != null) {
						mServiceMessenger.send(resp);
					}
				} catch (RemoteException e) {
					StringBuilder log = new StringBuilder();
					log.append("Exception : ");
					log.append(this.getClass());
					log.append(" : ");
					log.append(e.getMessage());
					Log.e(TAG, log.toString());
				}
			}
	    }
    
	/**
	 * The Class IntentRequestCodes.
	 */
	private class IntentRequestCodes{
 		/** The Constant REQUEST_TRAILER_CONFIGURATION_INFO. */
 		private static final int REQUEST_TRAILER_CONFIGURATION_INFO = 0;
		 
 		/** The Constant REQUEST_SYSTEM_CONFIGURATION_INFO. */
 		private static final int REQUEST_SYSTEM_CONFIGURATION_INFO = 1;
 		
 		/** The Constant REQUEST_DRIVER_CONFIGURATION_INFO. */
 		private static final int REQUEST_DRIVER_CONFIGURATION_INFO = 2;
	}
	
	
	/** The Constant TAG. */
	static final String TAG = "RsdDviActivity";
	
	/** The m configuration. */
	private Configuration mConfiguration;
	
	/** The m activity. */
	private Context mActivity;
	
	/** The m service. */
	private Intent mService;
	
	/** The m service messenger. */
	private Messenger mServiceMessenger;
	
	/** The m is bound. */
	private boolean mIsBound;
	
	/** The m image view. */
	private ImageView mImageView;	
	
	/** The m text view. */
	private TextView mTextView;
	
	private TextView mDebugCountView;
	
	private boolean mDemoDisabled;
	
	//gesture library was previously created using Android SDK GestureBuilder sample code
	/** The m store file. */
	private final File mStoreFile = new File(Environment.getExternalStorageDirectory(), "gestures");
	
	/** The m gesture library. */
	private GestureLibrary mGestureLibrary;

    /**
     * Target we publish for clients to send messages to IncomingHandler.
     */
    final Messenger mMessenger = new Messenger(new IncomingHandler());
	
    /**
     * Called when the activity is first created.
     *
     * @param savedInstanceState the saved instance state
     */
    @Override
    public void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);
    	Log.d(TAG, "onCreate()");
    	
    	mConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
    	
        requestWindowFeature(Window.FEATURE_NO_TITLE);
	    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	    WindowManager.LayoutParams.FLAG_FULLSCREEN);
	    
		mActivity = this;
        setContentView(R.layout.main);
        mImageView = (ImageView)findViewById(R.id.imageView1);
        mTextView = (TextView)findViewById(R.id.myImageViewText1);
        mDebugCountView = (TextView)findViewById(R.id.myImageViewCount);
        
        connectToService();
        
        //gesture recognition for backdoor into sys config
        mGestureLibrary = GestureLibraries.fromFile(mStoreFile);
        mGestureLibrary.load();
        GestureOverlayView gestures = (GestureOverlayView) findViewById(R.id.gestures);
        gestures.setGestureColor(Color.TRANSPARENT);
        gestures.setUncertainGestureColor(Color.TRANSPARENT);
        gestures.setOrientation(8);

        gestures.addOnGesturePerformedListener(this);
        
        //set brightness
        setScreenBrightness(mConfiguration.getBrightness());
        
        //run demo
        if(!mConfiguration.getSkipDemo()) {
        	
        	Log.d(TAG, "Running Demo");
            runDemo();
        }
        
        
    }
    
    /**
     * Connect to service.
     */
    private void connectToService()
    {
		mService = new Intent(this.getApplicationContext(), RsdDviService.class);
		startService(mService);
		
		doBindService();
    }
    
    /**
     * Do bind service.
     */
    private void doBindService(){
		bindService(mService, mConnection, Context.BIND_AUTO_CREATE);
		mIsBound = true;
		
		Log.d(TAG, "Service is BOUND");
    }
    
    /**
     * Do unbind service.
     */
    private void doUnbindService() {
    	if(mIsBound) {   		
			//send initial message to AndroidService to unregister for updates
			Message msg = Message.obtain(null, MessageType.UNREGISTER_CLIENT_MSG);
        	unbindService(mConnection);
        	
        	Log.d(TAG, "Service is UNBOUND");
        	mIsBound = false;
    	}
    }
    
    /**
     * Run demo.
     */
    private void runDemo() {   	
		if (!mDemoDisabled) {
			Intent mDemoIntent = new Intent();
			mDemoIntent.setClassName("server.android.swri",
					"server.android.swri.RsdDviDemoActivity");
			startActivity(mDemoIntent);
		}
    } 
    
    private void runDriverConfig() {   	
    
		if (!mDemoDisabled) {
			Intent driverConfigIntent = new Intent();
			driverConfigIntent.setClassName("server.android.swri",
					"server.android.swri.SetDriverConfigurationActivity");
			driverConfigIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			//send current brightness level to SetDriverConfigurationActivity
			Float currentBrightness = getWindow().getAttributes().screenBrightness;
			//if < 0 we are using default so send MAX value of 1
			if (currentBrightness < 0) {
				currentBrightness = 1F;
			}
			driverConfigIntent.putExtra(DriverConfigData.BRIGHTNESS,
					currentBrightness);
			startActivityForResult(driverConfigIntent,
					IntentRequestCodes.REQUEST_DRIVER_CONFIGURATION_INFO);
		}

    } 
    
    /**
     * Run system config.
     */
    private void runSystemConfig() {   	
    	
        Intent systemConfigIntent = new Intent(
                mActivity.getApplicationContext(),
                SetSystemConfigurationActivity.class);
			    systemConfigIntent
					.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			    systemConfigIntent
					.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			    startActivityForResult(
					systemConfigIntent,
					IntentRequestCodes.REQUEST_SYSTEM_CONFIGURATION_INFO);
    } 
    
    /**
     * Send trailer config resp.
     *
     * @param pTrailerLength the trailer length
     */
    private void sendTrailerConfigResp(int pTrailerLength) {
    	try {
    		
			Message msg = Message.obtain(null, MessageType.TRAILER_CONFIGURATION_RESP, pTrailerLength);
			msg.replyTo = mMessenger;
			mServiceMessenger.send(msg);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
    }
    
	/**
	 * Sets the brightness.
	 *
	 * @param pBrightness the new brightness
	 */
	public void setScreenBrightness(int pBrightness) {
		float minimumBrightness = .1F;
		float brightnessFloat = (float) pBrightness / 100;
		if(brightnessFloat < minimumBrightness) {
			brightnessFloat = minimumBrightness;
		}	

		WindowManager.LayoutParams lp = getWindow().getAttributes();
		lp.screenBrightness = brightnessFloat;
		getWindow().setAttributes(lp);
	}
    
    /**
     * Sets the status info.
     *
     * @param pMsg the new status info
     */
    private void setStatusInfo(SetStatusMessage pMsg) {
    	 ImageView rsdView = (ImageView)findViewById(R.id.ImageViewRSD);
    	 ImageView vehView = (ImageView)findViewById(R.id.ImageViewVEH);
    	 ImageView gpsView = (ImageView)findViewById(R.id.ImageViewGPS);
    	 ImageView dasView = (ImageView)findViewById(R.id.ImageViewDAS);
    	 ImageView numVehiclesView = (ImageView)findViewById(R.id.ImageViewSpeed);
    	 
    	 TextView numVehiclesTxtView = (TextView)findViewById(R.id.TextViewSpeed);
    	 
    	 rsdView.setColorFilter(getColorForStatus(pMsg.getRSDCore()));
    	 vehView.setColorFilter(getColorForStatus(pMsg.getVehicleConnection()));
    	 gpsView.setColorFilter(getColorForStatus(pMsg.getGPS()));
    	 dasView.setColorFilter(getColorForStatus(pMsg.getDAS())); 
    	 
    	 int numVehicleStatus = getStatusForNumVehicles (pMsg.getNumRemoteVehicles());
    	 
    	 int speedStatus = getStatusForSpeed(pMsg.getSpeed());
    	 //int mph = (int) (pMsg.getSpeed() * 2.2369);
    	 int numberOfOtherVehicles = pMsg.getNumRemoteVehicles();
    	 
    	 Log.d(TAG, "Number of Vehicles Status = "  + speedStatus);
    	 Log.d(TAG, "Number of Vehicles = "  + numberOfOtherVehicles);
    	 
    	 
    	 //if not connected to Radio remove SetTrailerConfigurationActivity
    	 if(pMsg.getRSDCore() == RsdDviConstants.RSDSystem.Status.Error) {
			 finishActivity(IntentRequestCodes.REQUEST_TRAILER_CONFIGURATION_INFO);
    	 }
    	 
    	 //disable or enable user input depending on speed
    	 enableUserInput(pMsg.getSpeed() <= mConfiguration.getDisableInputSpeedThreshold());
    	
    	 numVehiclesView.setColorFilter(getColorForStatus(numVehicleStatus)); 
    	 
    	 //instead of speed we are showing number of vehicles
    	 numVehiclesTxtView.setText(Integer.toString(numberOfOtherVehicles));
    	 numVehiclesTxtView.setAlpha((float) .50);
    }
    
    private void enableUserInput(boolean pEnable) {
    	
		 //disable or enable user input
		 if(pEnable) {
			
			 mDemoDisabled = false;
			 
			 StringBuilder sb = new StringBuilder();
			 sb.append("Demo Mode ENABLED."); 
			 
			 Log.d(TAG, sb.toString());
		 }
		 else {
			 
			 mDemoDisabled = true;
			 
			 StringBuilder sb = new StringBuilder();
			 sb.append("Demo Mode DISABLED.");
		 
			 Log.d(TAG, sb.toString());
			 
			 //remove SetTrailerConfigurationActivity
			 finishActivity(IntentRequestCodes.REQUEST_TRAILER_CONFIGURATION_INFO);
		 }
    }
    
    
    /**
     * Gets the status for speed.
     *
     * @param pSpeed the speed
     * @return the status for speed
     */
    private int getStatusForSpeed(int pSpeed) {
    	
    	int toReturn = RSDSystem.Status.Unknown;
    	
    	if(pSpeed > 0) {
    		
    		toReturn = RSDSystem.Status.Active;
	   	 }
    	
    	return toReturn;
    }
    
    /**
     * Gets the status for speed.
     *
     * @param pSpeed the speed
     * @return the status for speed
     */
    private int getStatusForNumVehicles(int pNumVehicles) {
    	
    	int toReturn = RSDSystem.Status.Unknown;
    	
    	if(pNumVehicles > 0) {
    		
    		toReturn = RSDSystem.Status.Active;
	   	 }
    	
    	return toReturn;
    }
    
    /**
     * Gets the color for status.
     *
     * @param pStatus the status
     * @return the color for status
     */
    private int getColorForStatus(int pStatus) {
    	
    	int toReturn = mConfiguration.getUnknownColor();
    	
    	switch (pStatus) {
    	
    	case RsdDviConstants.RSDSystem.Status.Unknown: 
    		
    		toReturn = mConfiguration.getUnknownColor();
    		
    		break;
    		
    	case RsdDviConstants.RSDSystem.Status.Active:
    		
    		toReturn = mConfiguration.getActiveColor();
    		
    		break;
    		
    	case RsdDviConstants.RSDSystem.Status.Error:
    		
    		toReturn = mConfiguration.getErrorColor();
    		
    		break;
    		
    	case RsdDviConstants.RSDSystem.Status.Timeout:
    		
    		toReturn = mConfiguration.getTimeoutColor();
    		
    		break;
    		
    	case RsdDviConstants.RSDSystem.Status.Disabled:
    		
    		toReturn = mConfiguration.getDisabledColor();
    		
    		break;
    	
    	}
    	
    	return toReturn;
    }

    /* (non-Javadoc)
     * @see android.app.Activity#dispatchKeyEvent(android.view.KeyEvent)
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
    	
    	boolean toReturn;
    	
    	//if configured to be locked down back and home events will be captured by dispatchKeyEvent
        if (mConfiguration.getLockdownTablet()) {
        	toReturn = true;
		}
        else {
        	toReturn = false;
        }
        return toReturn;
    }
    
    /* (non-Javadoc)
     * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    	Bundle extras = null;
    	if(data != null && data.getExtras() != null) {
        	extras = data.getExtras();
    	}
        	
    	switch(requestCode) {
  		
			case IntentRequestCodes.REQUEST_DRIVER_CONFIGURATION_INFO:
	    		if(extras != null) {
	            	
	        	int brightnessInt = extras.getInt(RsdDviConstants.DriverConfigData.BRIGHTNESS);
	        	Log.d(TAG, "SetDriverConfigurationActivity returns : "  + brightnessInt);
	        	setScreenBrightness(brightnessInt);
	        	mConfiguration.setBrightness(brightnessInt);
	        	break;
	    		}	
	    		
			case IntentRequestCodes.REQUEST_SYSTEM_CONFIGURATION_INFO:
				
				//if brightness was changed adjust our brightness accordingly
				setScreenBrightness(mConfiguration.getBrightness());
				break;
				
			case IntentRequestCodes.REQUEST_TRAILER_CONFIGURATION_INFO:
	    		if(extras != null) {
	
	            	int trailerLength = extras.getInt(RsdDviConstants.TrailerConfigData.TRAILER_LENGTH);
	            	
	            	Log.d(TAG, "SetTrailerConfigurationActivity returns : "  + trailerLength);
	            	        	
	            	sendTrailerConfigResp(trailerLength);
	
	    		}
	        	break;
			}
    }
    
    /* (non-Javadoc)
    * @see android.app.Activity#onAttachedToWindow()
    * enables capture of back and home KeyEvents
    */
    @Override
    public void onAttachedToWindow()
    {  
    	   //if configured to be locked down back and home events will be captured by dispatchKeyEvent
           if (mConfiguration.getLockdownTablet()) {
			this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		}
           
		super.onAttachedToWindow();
    }
    
    /* (non-Javadoc)
     * @see android.app.Activity#onDestroy()
     */
    @Override
    public void onDestroy()
    {
    	super.onDestroy();
    	doUnbindService();
    }
    
	/* (non-Javadoc)
	 * @see android.gesture.GestureOverlayView.OnGesturePerformedListener#onGesturePerformed(android.gesture.GestureOverlayView, android.gesture.Gesture)
	 */
	public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
		
		String DEMO_GESTURE_NAME = "Demo";
		String DRIVER_CONFIG_GESTURE_NAME = "Driver";
		String SYSTEM_CONFIG_GESTURE_NAME = "SwRI";
		
	    ArrayList<Prediction> predictions = mGestureLibrary.recognize(gesture);

	    // We want at least one prediction
	    if (predictions.size() > 0) {
	        Prediction prediction = predictions.get(0);
	        
        	Toast notification = Toast.makeText(this, prediction.name + " : " + Double.toString(prediction.score) , 3);
        	notification.show();
	        
	        // We want at least some confidence in the result
	        if (prediction.score > mConfiguration.getGestureRecognitionThreshold()) {

				//start RsdDviDemoActivity or SetSystemConfigurationActivity and get results
                if(prediction.name.equalsIgnoreCase(DEMO_GESTURE_NAME)) {
                    runDemo();
               }
                else if(prediction.name.equalsIgnoreCase(DRIVER_CONFIG_GESTURE_NAME)) {
                	runDriverConfig();
                }
                else if(prediction.name.equalsIgnoreCase(SYSTEM_CONFIG_GESTURE_NAME)) {
                	runSystemConfig();
                }
	        }
	    }
	}
	

}