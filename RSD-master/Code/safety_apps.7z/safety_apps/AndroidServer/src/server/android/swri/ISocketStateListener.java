/*
 * 
 */
package server.android.swri;

// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving ISocketState events.
 * The class that is interested in processing a ISocketState
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addISocketStateListener<code> method. When
 * the ISocketState event occurs, that object's appropriate
 * method is invoked.
 *
 * @see ISocketStateEvent
 */
public interface ISocketStateListener{


	/**
	 * Socket state changed.
	 *
	 * @param event the event
	 */
	public void onSocketStateChanged(SocketStateChangeEvent event);
}
