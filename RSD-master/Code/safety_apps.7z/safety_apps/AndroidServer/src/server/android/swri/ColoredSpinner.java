package server.android.swri;

import android.content.Context;
import android.content.res.TypedArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckedTextView;
import android.widget.Spinner;

public class ColoredSpinner extends Spinner implements android.widget.AdapterView.OnItemSelectedListener{

	TypedArray mColorInts;
	
	public ColoredSpinner(Context context, TypedArray pColors) {
		super(context);

		mColorInts = pColors;
		this.setOnItemSelectedListener(this);
	}
	
	@Override
	public void setSelection(int position) {
	    super.setSelection(position);
	    
	    
	    
	}

	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
	
		//color background
		CharSequence colorString = ((CheckedTextView)arg1).getText();
		
		
		this.setBackgroundColor(mColorInts.getColor(arg2, 0));
		
		int test = 0;
	}

	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}

}
