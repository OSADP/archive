/*
 * 
 */
package server.android.swri;

import server.android.swri.RsdDviConstants.MessageType;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.util.Log;

// TODO: Auto-generated Javadoc
/**
 * The Class PlayAudioAlertMessage.
 */
public class PlayAudioAlertMessage extends ActivityMessage implements IAudioMessage{
	
	/** The m ringtone. */
	private Ringtone mRingtone = null;
	
	/** The TAG. */
	private String TAG = "PlayAudioAlertMessage";
	
	/**
	 * Instantiates a new play audio alert message.
	 *
	 * @param pMessage the message
	 * @param pRingtone the ringtone
	 */
	public PlayAudioAlertMessage(String pMessage, Ringtone pRingtone){
		super(MessageType.PLAY_AUDIO_MSG, pMessage);
		mRingtone = pRingtone;
	}

	/* (non-Javadoc)
	 * @see server.android.swri.IAudioMessage#play()
	 */
	public void play(){
    		try {
				mRingtone.play();
			} catch (Exception e) {

				e.printStackTrace();
			}
	}

}
