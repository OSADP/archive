package server.android.swri;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


public class ColorAdapter extends ArrayAdapter {

	
	public ColorAdapter(Context context, int textViewResourceId, String[] mColorIntStrings) {
		super(context, textViewResourceId, mColorIntStrings);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent) {
		
		View toReturn = convertView;
		
		return toReturn;
		
	}

}
