/*
 * 
 */
package server.android.swri;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import android.util.Log;


// TODO: Auto-generated Javadoc
/**
 * The Class TCPClient.
 */
public class TCPClient implements IClient{	
	
	private class TimeoutTask extends TimerTask {

		@Override
		public void run() {

			//see if we've read data within timeout interval
			Date now = new Date();
			
			StringBuilder sb = new StringBuilder();
			sb.append("Timeout Timer - NOW : ");
			sb.append(now);
			sb.append(", LAST READ : ");
			
			if(mDataReadTime == null) {
				sb.append("NULL");
			}
			if(mDataReadTime != null && now.getTime() - mDataReadTime.getTime() > mTimeoutInterval) {
				sb.append(mDataReadTime.getTime());
				sb.append(", DIFFERENCE : ");
				sb.append(now.getTime() - mDataReadTime.getTime());
				sb.append("\r\n");
				sb.append("VALUE > ");
				sb.append(mTimeoutInterval);
				sb.append(", SETTING TO DISCONNECTED"); 
				mContinueProcess = false;
				Log.d(TAG, sb.toString());
			}
			
		}
		
	}
	
	/**
	 * The Class DataSender.
	 */
	public class DataSender implements Runnable{

		/** The m data. */
		byte[] mData;
		
		/**
		 * Instantiates a new data sender.
		 *
		 * @param pData the data
		 */
		public DataSender(byte[] pData) {
			mData = pData;
		}
		
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {

			send(mData);
		}
		
	}

	/**
	 * The Class SocketProcessor.
	 */
	public class SocketProcessor implements Runnable{
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public synchronized void run(){

			try{
							
				if(mClientSocket != null){
					Log.d(TAG, "LISTENING ON SOCKET : " + mClientSocket.getLocalPort());
					BufferedInputStream inputStream = new BufferedInputStream(mClientSocket.getInputStream());
					int numBytes = 0;
					
					//start with a time value so the TimeoutTimer has something to compare to
					mDataReadTime = new Date();
					
					while(mContinueProcess && mClientSocket.isConnected()){
						
						numBytes = 0;
						
						//read bytes from network stream into buffer
						try {
							numBytes = mClientSocket.getInputStream().read(mBuffer, 0, mBuffer.length);
							//int numBytes = inputStream.read(mBuffer, 0, mBuffer.length);
							
							//set time data was read for timeout timer to use
							mDataReadTime = new Date();
							
							Log.d(TAG, "BYTES  READ : " + numBytes);	
							Log.d(TAG, "TIME  READ : " + mDataReadTime);		
							
							//keep count if we receive nothing
							if(numBytes == 0){
								mZeroBytesReceived++;
								
								//if we have exceeded threshold show that we are disconnected
								if(mZeroBytesReceived > 4)
								{
									if(!mStateListeners.isEmpty())
									{
										mContinueProcess = false;
									}
									
								}else
								{
									Thread.sleep(500);
								}
							}else if(numBytes == -1){
								//disconnected
								if(mTCPClient != null)
								{
									mTCPClient.stop();
									mContinueProcess = false;
								}
							}else
							{
								mZeroBytesReceived = 0;
								handleReceived(mBuffer, numBytes);
							}	
							
							
						} catch (SocketTimeoutException e) {

							//not a problem
						}	
					}
					
					Log.d(TAG, "Exiting Socket Processor");
					mHasSocket = false;
					fireSocketStateChangeEvent(new SocketStateChangeEvent(mTCPClient, SocketState.NotConnected, mClientThread.getName()));
				}
			}
					
			catch (IOException e){
				mHasSocket = false;
				fireSocketStateChangeEvent(new SocketStateChangeEvent(mTCPClient, SocketState.NotConnected, mClientThread.getName()));
				e.printStackTrace();
				Log.d(TAG, "IOException in SocketProcessor");
			}catch (InterruptedException e){
				mHasSocket = false;
				fireSocketStateChangeEvent(new SocketStateChangeEvent(mTCPClient, SocketState.NotConnected, mClientThread.getName()));
				e.printStackTrace();
				Log.d(TAG, "InterruptedException in SocketProcessor");
			}
			catch (Exception e){
				mHasSocket = false;
				fireSocketStateChangeEvent(new SocketStateChangeEvent(mTCPClient, SocketState.NotConnected, mClientThread.getName()));
				e.printStackTrace();
				Log.d(TAG, "GeneralException in SocketProcessor");
			}
			
			mClientThread = null;
		}
	}
	
	/**
	 * The Class ReconnectLoop.
	 */
	public class ReconnectLoop implements Runnable{

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public synchronized void run(){
			int count = 1;
			
			//no need to continue timeout timer while reconnecting
			if(mTimeoutTimer != null) {
				mTimeoutTimer.cancel();
				
				Log.d(TAG, "CANCELLING TIMEOUT TIMER IN RECONNECT LOOP");
			}
			
			mTimeoutTimer = null;
			mTimeoutTask = null;
			
			while(!connect() && count < mNumReconnectAttempts){
				try{
					Log.d(TAG, "Trying to reconnect: Attempt " + count + " / " + mNumReconnectAttempts);
					Thread.sleep(mReconnectWaitTime);
					count++;
				}catch (InterruptedException e){
					e.printStackTrace();
				}
			}

			if(mConnected){
				if(mClientThreadName == null) {
					mClientThreadName = "RSDThread";
				}
				start(mClientThreadName);
			}else{
				Log.d(TAG, "Unable to reconnect after " + count + " attempts");

			}
			mReconnectThread = null;
		}
	}
	
	/**
	 * The Class SocketCreator.
	 */
	public class SocketConnector implements Runnable{
		
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run(){
			connect();	
		}
	}
	
	/** The Constant BUFFER_SIZE. */
	private static final int BUFFER_SIZE = 10240;
	
	/** The Constant HEADER_SIZE. */
	private static final int HEADER_SIZE = 5;
	
	/** The Constant BYTE_ARRAY_MESSAGE_LENGTH_INDEX. */
	private static final int BYTE_ARRAY_MESSAGE_LENGTH_INDEX = 4;
	
	/** The Constant BYTE_ARRAY_MESSAGE_TYPE_INDEX. */
	private static final int BYTE_ARRAY_MESSAGE_TYPE_INDEX = 2;
	
	/** The m zero bytes received. */
	private int mZeroBytesReceived = 0;
	
	/** The m remote port. */
	private int mRemotePort = 0;
	
	/** The m received index. */
	private int mReceivedIndex = 0;
	
	/** The m buffer. */
	private byte mBuffer[] = new  byte[BUFFER_SIZE];
	
	/** The m received buffer. */
	private byte mReceivedBuffer[] = new  byte[BUFFER_SIZE];
	
	/** The m connected. */
	private boolean mConnected = false;
	
	/** The m continue process. */
	private boolean mContinueProcess = false;
	
	/** The m has socket. */
	private boolean mHasSocket = false;
	
	/** The m is running. */
	private boolean mIsRunning = false;
	
	/** The m processing data. */
	private boolean mProcessingData = false;
	
	/** The m reconnecting. */
	private boolean mReconnecting = false;
	
	/** The m client thread. */
	private Thread mClientThread = null;
	
	/** The m reconnect thread. */
	private Thread mReconnectThread = null;
	
	/** The m socket thread. */
	private Thread mSocketThread = null;
	
	/** The TAG. */
	private String TAG = "TCPClient";
	
	/** The m client thread name. */
	private String mClientThreadName = null;
	
	/** The m remote address. */
	private InetAddress mRemoteAddress = null;
	
	/** The m client socket. */
	private Socket mClientSocket = null;
	
	/** The m tcp client. */
	private TCPClient mTCPClient = null;	
	
	/** The m state listeners. */
	private List<ISocketStateListener> mStateListeners;
	
	/** The m message listeners. */
	private List<ISocketMessageListener> mMessageListeners;
	
	/** The m num reconnect attempts. */
	private int mNumReconnectAttempts;
	
	/** The m reconnect wait time. */
	private int mReconnectWaitTime;
	
	private Timer mTimeoutTimer;
	
	private TimeoutTask mTimeoutTask;
	
	private int mTimeoutInterval;
	
	private Date mDataReadTime;
	
	
	/**
	 * Alive.
	 *
	 * @return the boolean
	 */
	public Boolean Alive(){
		return mClientThread != null && mClientThread.isAlive();
	}	
	
	/**
	 * Checks if is connected.
	 *
	 * @return the boolean
	 */
	public Boolean isConnected(){
		return mConnected;
	}
	
	/**
	 * Gets the checks if is running.
	 *
	 * @return the checks if is running
	 */
	public Boolean getIsRunning(){
		return mIsRunning;
	}

	/**
	 * Sets the checks if is running.
	 *
	 * @param mIsRunning the new checks if is running
	 */
	public void setIsRunning(Boolean mIsRunning){
		this.mIsRunning = mIsRunning;
	}

	/**
	 * Instantiates a new tCP client.
	 *
	 * @param pServerAddress the server address
	 * @param pPort the port
	 * used when trying to connect to server
	 * @param pNumReconnectAttempts the num reconnect attempts
	 * @param pReconnectWaitTime the reconnect wait time
	 */
	public TCPClient(InetAddress pServerAddress, int pPort, int pNumReconnectAttempts, int pReconnectWaitTime, int pTimeout){
		try{
			mRemoteAddress = pServerAddress;
			mRemotePort = pPort;
			mStateListeners = new ArrayList<ISocketStateListener>();
			mMessageListeners = new ArrayList<ISocketMessageListener>();
			mTCPClient = this;
			mNumReconnectAttempts = pNumReconnectAttempts;
			mReconnectWaitTime = pReconnectWaitTime;
			mTimeoutInterval = pTimeout;
			//create socket on new thread
			if(!mHasSocket)
			{
				mSocketThread = new Thread(new SocketConnector());
				mSocketThread.setName("SocketThread :" + mRemotePort);
				
				//this calls SocketCreator.run() which calls Connect()
				mSocketThread.start();
			}
			
		}catch (Exception e){
			e.printStackTrace();
			Log.d(TAG, "Exception in TCPClient(InetAddress pServerAddress, int pPort, int pNumReconnectAttempts, int pReconnectWaitTime) constructor: " + e);
		}
	}
	
	/**
	 * Instantiates a new tCP client.
	 *
	 * @param pClientSocket the client socket
	 * Used when listening for clients as server
	 */
	public TCPClient(Socket pClientSocket){
		try {
			mClientSocket = pClientSocket;
			mStateListeners = new ArrayList<ISocketStateListener>();
			mMessageListeners = new ArrayList<ISocketMessageListener>();
			mHasSocket = true;
			mTCPClient = this;	
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception in TCPClient(Socket pClientSocket) constructor: " + e);
		}
	}
	
	//Events
	/**
	 * Adds the i socket state listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void addISocketStateListener(ISocketStateListener pListener){
		mStateListeners.add(pListener);
	}
	
	/**
	 * Removes the socket state listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void removeISocketStateListener(ISocketStateListener pListener){
		mStateListeners.remove(pListener);
	}
	
	/**
	 * Adds the i socket message listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void addISocketMessageListener(ISocketMessageListener pListener){
		if(!mMessageListeners.contains(pListener)) {
			mMessageListeners.add(pListener);
		}
	}
	
	/**
	 * Removes the i socket message listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void removeISocketMessageListener(ISocketMessageListener pListener){
		mMessageListeners.remove(pListener);
	}
	
	/**
	 * Removes the i socket state handlers.
	 */
	private void removeISocketStateHandlers(){
		
		mStateListeners.clear();
	}
	
	/**
	 * Removes the i socket message handlers.
	 */
	private void removeISocketMessageHandlers(){
		mMessageListeners.clear();
	}
	
	/**
	 * Fire socket state change event.
	 *
	 * @param pEvent the event
	 */

	public synchronized void fireSocketStateChangeEvent(SocketStateChangeEvent pEvent){
		Iterator<ISocketStateListener> listeners = mStateListeners.iterator();
		while(listeners.hasNext())
		{
			listeners.next().onSocketStateChanged(pEvent);
		}
	}
	
	/**
	 * Fire socket message received event.
	 *
	 * @param pEvent the event
	 */
	public synchronized void fireSocketMessageReceivedEvent(ReceivedMessageFromSocket pEvent){
		Iterator<ISocketMessageListener> listeners = mMessageListeners.iterator();
		while(listeners.hasNext()){
			listeners.next().handleReceived(pEvent);
		}
	}
	
	/**
	 * Send data on separate thread.
	 *
	 * @param pData the data
	 */
	public void sendDataOnSeparateThread(byte[] pData) {
		//if(mHasSocket && mIsRunning) {
		if(mHasSocket) {
			DataSender thisSender = new DataSender(pData);
			Thread dataThread = new Thread(thisSender);
			dataThread.start();
		}
	}
	
	//IClient Methods:
	
	//Make a connection if there is not already one
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#Connect()
	 */
	public Boolean connect(){
		mConnected = false;
		
		try{
			if(!mHasSocket){
				if(mRemotePort > 0){
					mClientSocket = new Socket(mRemoteAddress, mRemotePort); 
					mClientSocket.setSoTimeout(1000);
					mHasSocket = true;

					//connected
					fireSocketStateChangeEvent(new SocketStateChangeEvent(this, SocketState.Connected, mRemoteAddress + " : " + mRemotePort ));
					mConnected = true;	
				}
			}else{
				//already connected
				mConnected = true;	
			}
		}catch (IOException e){
			e.printStackTrace();
			Log.d(TAG, "Exception in Connect()");
			mConnected = false;
			fireSocketStateChangeEvent(new SocketStateChangeEvent(this, SocketState.NotConnected, mRemoteAddress + " : " + mRemotePort ));
		}
		
		return mConnected;
	}
	
	
	/* (non-Javadoc)
	 * @see IClient#HandleReceived(byte[], int)
	 */
	public Boolean handleReceived(byte[] pData, int pDataLength){
		Boolean dataHandled = false;
		
		StringBuilder sb = new StringBuilder();
		
		for(int i = 0; i < pDataLength; i++){
			sb.append(String.format("%02X",  pData[i]));
		}
		
		Log.d(TAG, "Handling : ");
		Log.d(TAG, sb.toString());
		
		if ((pData[0] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_A && (pData[1] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_B) {
			synchronized (mReceivedBuffer) {
				try {
					//make a new buffer if not large enough
					if (mReceivedBuffer.length < mReceivedIndex + pDataLength) {
						byte[] temp = new byte[mReceivedIndex + pDataLength];
						java.lang.System.arraycopy(mReceivedBuffer, 0, temp, 0,
								mReceivedIndex);
						mReceivedBuffer = new byte[mReceivedIndex + pDataLength];
						java.lang.System.arraycopy(temp, 0, mReceivedBuffer, 0,
								mReceivedIndex);
					}

					//copy new data to buffer
					java.lang.System.arraycopy(pData, 0, mReceivedBuffer,
							mReceivedIndex, pDataLength);
					mReceivedIndex += pDataLength;

					//process data until all complete messages in buffer have been removed
					mProcessingData = true;
					while (mProcessingData) {
						//stop processing if we don't at least have a header from which to derive message size
						if (mReceivedIndex < HEADER_SIZE) {
							mProcessingData = false;
						}

						//we have at least a header
						else {
							ByteArrayInputStream bis = new ByteArrayInputStream(
									mReceivedBuffer,
									BYTE_ARRAY_MESSAGE_LENGTH_INDEX, 2);
							DataInputStream dis = new DataInputStream(bis);
							int msgLength = dis.readUnsignedShort();

							//quit if we don't have complete message yet
							if (mReceivedIndex < msgLength) {
								mProcessingData = false;
							}

							//we have a complete message
							else {
								//copy message into frontMessage for delivery
								byte[] frontMessage = new byte[msgLength];
								java.lang.System.arraycopy(mReceivedBuffer, 0,
										frontMessage, 0, msgLength);
								ReceivedMessageFromSocket messageReceived = new ReceivedMessageFromSocket(
										this, frontMessage);
								fireSocketMessageReceivedEvent(messageReceived);
								dataHandled = true;

								//copy bytes remaining to front of buffer
								java.lang.System.arraycopy(mReceivedBuffer,
										msgLength, mReceivedBuffer, 0,
										mReceivedIndex - msgLength);
								mReceivedIndex -= msgLength;
							}
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					dataHandled = false;
					Log.d(TAG, "Exception in TCPClient.handleReceived: " + e);
				}
			}
		}
		else {
			Log.d(TAG, "Check bytes do not match! Tossing data . . .");
		}
		return dataHandled;
	}

	
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#send(byte[])
	 */
	public Boolean send(byte[] pData){
		Boolean sent = false;
		try{
			StringBuilder sb = new StringBuilder();
			
			for(int i = 0; i < pData.length; i++){
				sb.append(String.format("%02X",  pData[i]));
			}
			
			Log.d(TAG, "Sending : " + sb.toString());
			mClientSocket.getOutputStream().write(pData, 0, pData.length);
			sent = true;
		}catch (IOException e){
			e.printStackTrace();
			sent = false;
			Log.d(TAG, "IOException in TCPClient.send: " + e);
			fireSocketStateChangeEvent(new SocketStateChangeEvent(this, SocketState.NotConnected, mClientThread.getName()));
		}
		catch(Exception e) {
			sent = false;
			Log.d(TAG, "General Exception in TCPClient.send: " + e);
			fireSocketStateChangeEvent(new SocketStateChangeEvent(this, SocketState.NotConnected, mClientThread.getName()));
		}
		
		return sent;	
	}


	/* (non-Javadoc)
	 * @see IClient#Start(java.lang.String)
	 */
	public synchronized Boolean start(String pThreadName){		
		try{
			 //if pThreadName is null we have never connected
			if(pThreadName == null) {
				mClientThreadName = "RsdThread";
			}
			else {
				mClientThreadName = pThreadName;
			}

			//check if mClientThread null to avoid multiple threads
			if(mHasSocket && mClientThread == null){

				mContinueProcess = true;
				mClientThread = new Thread(new SocketProcessor());
				mClientThread.setName(pThreadName);
				//this calls SocketProcessor.run()
				mClientThread.start();
				mIsRunning = true;
				setupTimeoutTimer();
				//connected event below is also fired by connect() - not sure if needed here
				//fireSocketStateChangeEvent(new SocketStateChangeEvent(mTCPClient, SocketState.Connected, mClientThread.getName()));
				
				
			}else{
				mIsRunning = false;
			}
		}catch (Exception e){
			e.printStackTrace();
			mContinueProcess = false;
			mIsRunning = false;
			Log.d(TAG, "Exception in TCPClient.start: " + e);
		}
		
		return mIsRunning;
	}
	
	/**
	 * Setup timeout timer.
	 */
	private void setupTimeoutTimer() {
		
		try {
			//instantiate timers
			//this timer fires to check if radio has not sent data within timeout interval
			mTimeoutTask = new TimeoutTask();

			mTimeoutTimer = new Timer("mTimeoutTimer");
			
			//set task
			mTimeoutTimer.schedule(mTimeoutTask, mTimeoutInterval/2, mTimeoutInterval/1000);
			
			StringBuilder sb = new StringBuilder();
			sb.append("SCHEDULED TIMEOUT TIMER FOR : ");
			sb.append(mTimeoutInterval/2);
			sb.append(" ms");
			
			Log.d(TAG, sb.toString());
			
		} catch (Exception e) {
			Log.d(TAG, "Exception initializing Timeout Timer: " + e.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see server.android.swri.IClient#startReconnectThread()
	 */
	public synchronized void startReconnectThread(){
		if(mReconnectThread == null){
			mReconnectThread = new Thread(new ReconnectLoop());
			mReconnectThread.setName("Reconnect Thread");
			mReconnectThread.start();
		}
	}
	

	/* (non-Javadoc)
	 * @see server.android.swri.IClient#stop()
	 */
	public void stop(){
		mHasSocket = false;
		mContinueProcess = false;
		if(mClientSocket != null){
			try{
				mClientSocket.getInputStream().close();
				mClientSocket.getOutputStream().close();
				mClientSocket.close();
				removeISocketMessageHandlers();
			}catch (IOException e){
				e.printStackTrace();
				Log.d(TAG, "Exception in TCPClient.stop: " + e);
			}
		}
	}
}
