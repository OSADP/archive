/*
 * 
 */
package server.android.swri;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.util.Log;


// TODO: Auto-generated Javadoc
/**
 * The Class TCPServer.
 */
public class TCPServer implements ISocketStateListener{ 
	
	
	/** The port. */
	int port;
	
	/** The server socket. */
	ServerSocket serverSocket;
	
	/** The client socket. */
	Socket clientSocket;
	
	/** The output. */
	PrintWriter output;
	
	/** The input. */
	BufferedReader input;
	
	/** The m client connections. */
	public List<TCPClient> mClientConnections;
	
	/** The m continue reclaim. */
	private boolean mContinueReclaim;
	
	/** The m reclaim thread. */
	private Thread mReclaimThread;
	
	/** The m accepts clients thread. */
	private Thread mAcceptsClientsThread;
	
	/** The m message handler. */
	private ISocketMessageListener mMessageHandler;
	
	/** The m state handler. */
	private ISocketStateListener mStateHandler;
	
	/** The m host ip. */
	private InetAddress mHostIp;
	
	/** The m local port. */
	private int mLocalPort;
	
	/** The m running. */
	private boolean mRunning;
	
	/** The m tcp listener. */
	private TCPListener mTCPListener;
	
	/** The m thread name. */
	private String mThreadName;
	
	/** The m is listening. */
	private boolean mIsListening;
	
	/** The m num reconnect attempts. */
	private int mNumReconnectAttempts;
	
	/** The m reconnect wait time. */
	private int mReconnectWaitTime;
	
	/** The Constant BUFFER_SIZE. */
	private static final int BUFFER_SIZE = 10240;
	
	/** The Constant TAG. */
	private static final String TAG = "TCPServer";
	
	/** The m state listeners. */
	private List<ISocketStateListener> mStateListeners;
	
	private int mTimeoutInterval;
	
	/**
	 * The Class AcceptClients.
	 */
	public class AcceptClients implements Runnable{
		
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run(){
			mTCPListener.Start();
			mContinueReclaim = true;
			
			while(mRunning){
				Socket newSocket = mTCPListener.AcceptSocket();
				TCPClient newClient = new TCPClient(newSocket);
				newClient.addISocketMessageListener(mMessageHandler);
				newClient.addISocketStateListener(mStateHandler);
				mClientConnections.add(newClient);
				newClient.start(mThreadName + " : " + newSocket.getPort());	
			}
		}
	}
	
	/**
	 * The Class ReclaimDeadConnections.
	 */
	public class ReclaimDeadConnections implements Runnable{

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run(){
			List<TCPClient> deadConnections = new ArrayList<TCPClient>();
			
			while (mContinueReclaim){
				try	{
					synchronized (mClientConnections){
						for (int i = 0; i < mClientConnections.size(); i++){
							if (mClientConnections.get(i).Alive()){
								deadConnections.add(mClientConnections.get(i));
							}if (!deadConnections.isEmpty()){
								for (int j = 0; j < deadConnections.size(); j++){
									try{
										if (mClientConnections
												.contains(deadConnections
														.get(j))){
											mClientConnections
													.remove(deadConnections
															.get(j));
										}
									}catch (Exception e){
										e.printStackTrace();
									}
								}
								deadConnections.clear();
							}
						}
					}
				}catch (Exception e){
					e.printStackTrace();
				}
			}
		}
	}
	

	/**
	 * Instantiates a new tCP server.
	 *
	 * @param pHostIP the host ip
	 * @param pPort the port
	 * @param pMessageHandler the message handler
	 * @param pListen the listen
	 * @param pNumReconnectAttempts the num reconnect attempts
	 * @param pReconnectWaitTime the reconnect wait time
	 */
	public TCPServer(InetAddress pHostIP, int pPort, ISocketMessageListener pMessageHandler, boolean pListen, int pNumReconnectAttempts, int pReconnectWaitTime, int pTimeoutInterval){
		mHostIp = pHostIP;
		mLocalPort = pPort;
		mMessageHandler = pMessageHandler;
		mClientConnections = new ArrayList<TCPClient>();
		mIsListening = pListen;
		mNumReconnectAttempts = pNumReconnectAttempts;
		mReconnectWaitTime = pReconnectWaitTime;
		mTimeoutInterval = pTimeoutInterval;
		mStateListeners = new ArrayList<ISocketStateListener>();
	}
	
	/**
	 * Creates the client.
	 *
	 * @return the tCP client
	 */
	public TCPClient CreateClient(){
		TCPClient newClient = new TCPClient(mHostIp, mLocalPort, mNumReconnectAttempts, mReconnectWaitTime, mTimeoutInterval);
		newClient.addISocketMessageListener(mMessageHandler);
		newClient.addISocketStateListener(this);
		
		return newClient;
	}
	
	//events
	//Events
	/**
	 * Adds the i socket state listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void addISocketStateListener(ISocketStateListener pListener){
		mStateListeners.add(pListener);
	}
	
	/**
	 * Removes the socket state listener.
	 *
	 * @param pListener the listener
	 */
	public synchronized void removeISocketStateListener(ISocketStateListener pListener){
		mStateListeners.remove(pListener);
	}
	
	
	/**
	 * Start server.
	 *
	 * @param pThreadName the thread name
	 * @return true, if successful
	 */
	public boolean StartServer(String pThreadName){
		boolean started = false;
		mThreadName = pThreadName;
		try{
			//heartbeat
			//setupHeartbeatTimer();
			
			//accept clients on new thread or act as client
			if(mIsListening){
				mTCPListener = new TCPListener(mHostIp, mLocalPort);
				mAcceptsClientsThread = new Thread(new AcceptClients());
				mAcceptsClientsThread.setName(pThreadName);
					
				//this calls AcceptClients.run()
				mAcceptsClientsThread.start();
			}else{
				TCPClient newClient = CreateClient();
				
/*				InetAddress addr = InetAddress.getByName("192.168.1.4");
				BluetoothClient newClient = new BluetoothClient("192.168.1.3", "192.168.1.4", addr, 24, mLocalPort, 5, 5000);*/
				
				mClientConnections.add(newClient);	
				
				//wait a bit to for client to connect on its own thread
				Thread.sleep(100);
				
				if(newClient.isConnected()){	
					Log.d(TAG, "CONNECTED ON STARTUP : STARTING CLIENT THREAD");
					
					mRunning = true;
					started = true;
					newClient.start(mThreadName + " : " + mLocalPort);
				}
				
			}
		}catch (Exception e){
			e.printStackTrace();
			started = false;
		}
		
		return started;
	}
	
	/**
	 * Send.
	 *
	 * @param pData the data
	 */
	public void Send(byte[] pData){
		for(int i = 0; i < mClientConnections.size(); i++){
			//mClientConnections.get(i).send(pData);
			mClientConnections.get(i).sendDataOnSeparateThread(pData);
		}
	}
	
	/**
	 * Send.
	 *
	 * @param pData the data
	 */
	public void sendHeartbeat(){
		
		byte[] heartbeatMsg = new byte[1];
		
		//Header (radio will ignore because both sync bytes are not present)
		heartbeatMsg[0] = (byte) RsdDviConstants.Header.SYNC_FRAME_A;
		
		for(int i = 0; i < mClientConnections.size(); i++){
			//mClientConnections.get(i).send(pData);
			mClientConnections.get(i).sendDataOnSeparateThread(heartbeatMsg);
		}
		
		Log.d(TAG, "SENDING HEARTBEAT");
	}
	
	/**
	 * Stop.
	 */
	public void Stop(){
		if(mTCPListener != null){
			mTCPListener.Stop();
		}try{
			if(mAcceptsClientsThread != null){
				mAcceptsClientsThread.join();
			}

			mContinueReclaim = false;
			
			if(mReclaimThread != null){
				mReclaimThread.join();
			}
			
			for(int i = 0; i < mClientConnections.size(); i++){
				
				mClientConnections.get(i).stop();
			}
		} 
		
		catch (InterruptedException e){
			e.printStackTrace();
		}
		
	}

	/* (non-Javadoc)
	 * @see server.android.swri.ISocketStateListener#SocketStateChanged(server.android.swri.SocketStateChangeEvent)
	 */
	public synchronized void onSocketStateChanged(SocketStateChangeEvent event){
			switch(event.SocketState()){
				case Connected:
					
					Log.d(TAG, "Connected");
					
					((TCPClient)event.Source()).addISocketMessageListener(mMessageHandler);
					

					
					break;
					
				case NotConnected:

					Log.d(TAG, "NotConnected");
					((TCPClient)event.Source()).startReconnectThread();
					
	
					break;
					
				default:
						
					Log.d(TAG, "default");
					break;
			}
			
			//forward this event to RsdDviService
			Iterator<ISocketStateListener> listeners = mStateListeners.iterator();
			while(listeners.hasNext())
			{
				listeners.next().onSocketStateChanged(event);
			}
	}
}

