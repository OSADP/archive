/*
 * 
 */
package server.android.swri;

// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving ISocketMessage events.
 * The class that is interested in processing a ISocketMessage
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addISocketMessageListener<code> method. When
 * the ISocketMessage event occurs, that object's appropriate
 * method is invoked.
 *
 * @see ISocketMessageEvent
 */
public interface ISocketMessageListener{

	/**
	 * Handle received.
	 *
	 * @param event the event
	 */
	public void handleReceived(ReceivedMessageFromSocket event);
}
