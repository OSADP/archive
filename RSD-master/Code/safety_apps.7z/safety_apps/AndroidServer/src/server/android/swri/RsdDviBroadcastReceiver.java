/*
 * 
 */
package server.android.swri;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

// TODO: Auto-generated Javadoc
/**
 * The Class RsdDviBroadcastReceiver.
 */
public class RsdDviBroadcastReceiver extends BroadcastReceiver
{
	
	/** The TAG. */
	private final String TAG = "RsdDviBroadcastReceiver";

	private Configuration mConfiguration;
	
	
	/* (non-Javadoc)
	 * @see android.content.BroadcastReceiver#onReceive(android.content.Context, android.content.Intent)
	 */
	@Override
	public void onReceive(Context pContext, Intent pIntent)
	{
		Log.d(TAG, "Recieved Intent from BOOT!");
		
		mConfiguration = Configuration.getInstance(pContext, RsdDviConstants.SHARED_PREF_FILE);

/*		Intent mStartupIntent = new Intent(pContext, RsdDviActivity.class);
		mStartupIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);	
		pContext.startActivity(mStartupIntent);*/
		
		try {
			
			if(mConfiguration.getDebugEnabled()) {
				setupWirelessDebugging();
			}
			
			if(mConfiguration.getLoggingEnabled()) {
				enableLoggingToExternalSDCard();
			}
			
/*			if (mConfiguration.getUseWiredTether()) {
				startWiredTether(pContext);
			}*/
						
			if(mConfiguration.getStartOnBoot()) {
				startRSDService(pContext);
			}
		
		} catch (Exception e) {

				e.printStackTrace();
				Log.d(TAG, "Exception in onReceive : " + e.getMessage());
			}
	}
	
	private void startRSDService(Context pContext) {
		
		Log.d(TAG, "Starting RSDService");
		Intent serviceIntent = new Intent(pContext, RsdDviService.class);
		serviceIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);	
		pContext.startService(serviceIntent);
	}
	
	private void startWiredTether(Context pContext) {
		
		Log.d(TAG, "Starting Wired Tether");
		
		//this intent can be used to start wired tether app for ethernet over usb connectivity
		Intent wiredTetherIntent = new Intent();
		wiredTetherIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		wiredTetherIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		wiredTetherIntent.setAction("android.intent.action.VIEW");
		wiredTetherIntent
				.setComponent(ComponentName
						.unflattenFromString("android.tether.usb/android.tether.usb.MainActivity"));
		pContext.startActivity(wiredTetherIntent);
	}
	
	
    private void setupWirelessDebugging() {
    	try{    
    		Log.d(TAG, "Starting Wireless Debugging");
    		
	    	Process process = Runtime.getRuntime().exec("su");
	    	DataOutputStream out = new DataOutputStream(
	    	process.getOutputStream());
	    	out.writeBytes("setprop service.adb.tcp.port 5555 \n");
	    	out.flush();
	    	Thread.sleep(100);
	    	out.writeBytes("stop adbd \n");
	    	out.flush();
	    	Thread.sleep(100);
	    	out.writeBytes("start adbd \n");
	    	out.flush();	
	    	
    	}catch (IOException e){
    		Log.d(TAG, "IOException in setupWirelessDebuggingAndroid(): " + e.getMessage());
    	} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.d(TAG, "Exception in setupWirelessDebuggingAndroid : " + e.getMessage());
		}
    }
    
    private void enableLoggingToExternalSDCard() {
    	try{
    		String path = "/mnt/external_sd/RSD/";
    		String filter = "RsdDviBroadcastReceiver:V RSDDVIService:V RsdDviActivity:V SetSystemConfigurationActivity:V SetTrailerConfigurationActivity:V *:S";
    		
    		Log.d(TAG, "Enabling logging to SDCard");
    		
    		Process process = Runtime.getRuntime().exec("su");
	    	DataOutputStream out = new DataOutputStream(
	    	process.getOutputStream());
	    	
	    	StringBuilder sb = new StringBuilder();
	    	sb.append("logcat -f ");
	    	sb.append(path);
	    	sb.append("RSDLog_");
	    	//sb.append(Calendar.YEAR);
	    	//sb.append(":");
	    	//sb.append(Calendar.MONTH);
	    	//sb.append(":");
	    	//sb.append(Calendar.DATE);
	    	//sb.append(":");
	    	sb.append(new Date().getTime());
	    	sb.append(" ");
	    	
	    	//only log what we are interested in
	    	sb.append(filter);
	    	sb.append(" \n");
	    	out.writeBytes(sb.toString());
	    	out.flush();
    	}
    	catch(Exception e){
    		Log.d(TAG, "Exception thrown while enabling logging to SDCard");
    	}
    }
	
}