/*
 * 
 */
package server.android.swri;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import server.android.swri.RsdDviConstants.AdvisoryType;
import server.android.swri.RsdDviConstants.SafetyAppMessageData;

import android.util.Log;

// TODO: Auto-generated Javadoc
/**
 * The Class SafetyAppMessage.
 */
public class SafetyAppMessage{
	
	
	/** The TAG. */
	private String TAG = "SafetyAppMessage";
	
	/** The m advisory type. */
	private AdvisoryType mAdvisoryType;
	
	/** The m id. */
	private long mID;
	
	/** The m category. */
	private int mCategory;
	
	/** The m priority. */
	private int mPriority;
	
	/** The m title. */
	private String mTitle;
	
	/** The m text lines. */
	private String mText;
	
	/** The m is activated. */
	private boolean mIsActivated;
	
	/** The m time activated. */
	private Date mTimeActivated;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public long getId(){
		return mID;
	}
	
	/**
	 * Gets the checks if is activated.
	 *
	 * @return the checks if is activated
	 */
	public boolean getIsActivated(){
		return mIsActivated;
	}
	
	/**
	 * Gets the checks if is activated.
	 *
	 * @return the checks if is activated
	 */
	public Date getTimeActivated(){
		return mTimeActivated;
	}
	
	/**
	 * Sets the checks if is activated.
	 *
	 * @param mIsActivated the new checks if is activated
	 */
	public void setIsActivated(boolean pIsActivated){
		this.mIsActivated = pIsActivated;
		if(mIsActivated) {
			this.mTimeActivated = new Date();
		}
		else {
			mTimeActivated = null;
		}
	}
	
	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public int getCategory(){
		return mCategory;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority(){
		return mPriority;
	}

	/**
	 * Gets the title.
	 *
	 * @return the title
	 */
	public String getTitle(){
		return mTitle;
	}

	/**
	 * Gets the advisory type.
	 *
	 * @return the advisory type
	 */
	public AdvisoryType getAdvisoryType(){
		return mAdvisoryType;
	}
	
	public SafetyAppMessage(long pId, AdvisoryType pAdvisoryType, int pCategory, boolean pIsActivated, int pPriority, String pTitle, String pText) {
		mID = pId;
		mAdvisoryType = pAdvisoryType;
		mCategory = pCategory;
		mPriority = pPriority;
		mIsActivated = pIsActivated;
		if(pIsActivated) {
			mTimeActivated = new Date();
		}
		else {
			mTimeActivated = null;
		}
		mPriority = pPriority;
		mText = pText;
		mTitle = pTitle;
	}
	

	
	/**
	 * Instantiates a new safety app message.
	 *
	 * @param pData the data
	 */
	public SafetyAppMessage(byte[] pData){
		//evaluate bytes [0] and [1]  as control bytes
		if((pData[0] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_A && (pData[1] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_B){			
			
			try {

				//type
				mAdvisoryType = AdvisoryType.values()[pData[SafetyAppMessageData.MESSAGE_TYPE_INDEX] & 0xFF];
				
				//size (should also be pData.length)
				int messageSize = pData[3] ;
				
				//id
				byte[] idBytes = new byte[8];
				System.arraycopy(pData, SafetyAppMessageData.ID_BYTE_INDEX, idBytes, 0, 8);

				ByteArrayInputStream bis = new ByteArrayInputStream(idBytes, 0, 8);
				DataInputStream dis = new DataInputStream(bis);
				mID = dis.readLong();
				
				//category
				byte[] categoryBytes = new byte[2];
				System.arraycopy(pData, SafetyAppMessageData.CATEGORY_BYTE_INDEX, categoryBytes, 0, 2);
				
				ByteArrayInputStream cat_bis = new ByteArrayInputStream(categoryBytes, 0, 2);
				DataInputStream cat_dis = new DataInputStream(cat_bis);
				mCategory = cat_dis.readShort();
				
				//priority
				mPriority = (pData[SafetyAppMessageData.PRIORITY_BYTE_INDEX] & 0xFF);
				
				//title
				int titleLength = pData[SafetyAppMessageData.TITLE_LENGTH_BYTE_INDEX] & 0xFF;
				byte[] titleBytes = new byte[titleLength];
				System.arraycopy(pData, SafetyAppMessageData.TITLE_LENGTH_BYTE_INDEX + 1, titleBytes, 0, titleLength);
				mTitle = new String(titleBytes);		
		
				//textlines
				int textLengthIndex = SafetyAppMessageData.TITLE_LENGTH_BYTE_INDEX + titleLength + 1;
				int textLength = pData[textLengthIndex];
				byte[] textBytes = new byte[textLength];
				System.arraycopy(pData, ++textLengthIndex, textBytes, 0, textLength);
				mText = new String(textBytes);

				
			} catch (IOException e) {

				e.printStackTrace();
				Log.d(TAG, "IOException in SafetyAppMessage()");
			}
			
			catch (Exception e) {

				e.printStackTrace();
				Log.d(TAG, "General Exception in SafetyAppMessage()");
			}
			
		}else{
			Log.d(TAG, "Invalid Data Format");
		}
	}

}
