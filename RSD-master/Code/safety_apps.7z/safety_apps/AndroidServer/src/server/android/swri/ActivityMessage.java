/*
 * 
 */
package server.android.swri;

// TODO: Auto-generated Javadoc
/**
 * The Class ActivityMessage.
 */
public class ActivityMessage{
	
	/** The m message type. */
	private int mMessageType;
	
	/** The m message. */
	private String mMessage;
	
	/**
	 * Instantiates a new activity message.
	 *
	 * @param pMessageType the message type
	 */
	public ActivityMessage(int pMessageType){
		this(pMessageType, "");
	}
	
	/**
	 * Instantiates a new activity message.
	 *
	 * @param pMessageType the message type
	 * @param pMessage the message
	 * @param pDuration the duration
	 */
	public ActivityMessage(int pMessageType, String pMessage){
		mMessageType = pMessageType;
		mMessage = pMessage;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage(){
		return mMessage;
	}
	
	/**
	 * Sets the message.
	 *
	 * @param pMessage the new message
	 */
	public void setMessage(String pMessage){
		mMessage = pMessage;
	}


	/**
	 * Gets the message type.
	 *
	 * @return the message type
	 */
	public int getMessageType(){
		return mMessageType;
	}
}
