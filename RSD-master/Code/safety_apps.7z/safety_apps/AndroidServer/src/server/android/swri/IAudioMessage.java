/*
 * 
 */
package server.android.swri;

// TODO: Auto-generated Javadoc
/**
 * The Interface IAudioMessage.
 */
public interface IAudioMessage{	
	
	/**
	 * Play.
	 */
	void play();

	/**
	 * Gets the message type.
	 *
	 * @return the message type
	 */
	int getMessageType();
}
