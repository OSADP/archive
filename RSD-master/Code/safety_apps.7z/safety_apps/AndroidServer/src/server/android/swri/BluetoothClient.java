/*
 * 
 */
package server.android.swri;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.TimerTask;

// TODO: Auto-generated Javadoc
/**
 * The Class BluetoothClient.
 */
public class BluetoothClient extends TCPClient{
	
	/**
	 * The Class StreamHandler.
	 */
	public class StreamHandler implements Runnable{

		/** The input stream. */
		InputStream inputStream;
		
		/** The results. */
		List<String> results;
		
		/** The finished processing. */
		boolean finishedProcessing;
		
	    /**
    	 * Instantiates a new stream handler.
    	 *
    	 * @param pInput the input
    	 */
    	StreamHandler(InputStream pInput)
	    {
	    	inputStream = pInput;
	    	results = new ArrayList<String>();
	    }

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
	
        try{
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(isr);
            String line = null;
            while ( (line = br.readLine()) != null){
            	results.add(line);  
            }
            finishedProcessing = true;
        } catch (IOException ioe)
          {
            ioe.printStackTrace();  
            finishedProcessing = true;
          }	
		}
		
		
		/**
		 * Gets the results.
		 *
		 * @return the results
		 */
		public synchronized List<String> getResults()
		{
			while(!finishedProcessing)
			{
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return results;
		}
		
	}
	
    /** The m server bt found. */
    boolean mServerBTFound;
    
    /** The m pan enabled. */
    boolean mPANEnabled;
    
    
    /** The DEVIC e_ name. */
    final String DEVICE_NAME = "bnep0";

	/**
	 * Instantiates a new bluetooth client.
	 *
	 * @param pLocalHostAddress the local host address
	 * @param pServerBTMacAddress the server bt mac address
	 * @param pBTServerAddress the bT server address
	 * @param pBTServerBitmask the bT server bitmask
	 * @param pPort the port
	 * @param pNumReconnectAttempts the num reconnect attempts
	 * @param pReconnectWaitTime the reconnect wait time
	 */
	public BluetoothClient(String pLocalHostAddress, String pServerBTMacAddress, InetAddress pBTServerAddress, int pBTServerBitmask, int pPort,
			int pNumReconnectAttempts, int pReconnectWaitTime) {
		
		//create TCPClient normally 
		super(pBTServerAddress, pPort, pNumReconnectAttempts, pReconnectWaitTime, 5000);
		
		if(initializePAN(pServerBTMacAddress))
		{
			//verify server has bluetooth device
			mServerBTFound = verifyServerBluetooth(DEVICE_NAME);
			if(mServerBTFound)
			{
				//assign ip to device
				if(assignIpToBTDevice(pBTServerAddress.toString(), DEVICE_NAME, pBTServerBitmask))
				{
					//enable ip
					mPANEnabled = activateBTIP(DEVICE_NAME);
				}
			}
		}
	}
	
    /**
     * Initialize pan.
     *
     * @param pBTDeviceToConnectMac the bT device to connect mac
     * @return true, if successful
     */
    private boolean initializePAN(String pBTDeviceToConnectMac) {
    	boolean toReturn = false;
    	
    	try{	
	    		//run "pand -c 00:11:67:24:14:2F" (mac for server BT device)
	    		StringBuilder cmd = new StringBuilder();
	    		cmd.append("pand -c ");
	    		cmd.append(pBTDeviceToConnectMac);
	    		cmd.append(" \n");
		    	Process process = Runtime.getRuntime().exec(cmd.toString());
	    		StreamHandler messageHandler = new StreamHandler(process.getInputStream());
		    	Thread inputThread = new Thread(messageHandler);
		    	inputThread.start();
		    	StreamHandler errorHandler = new StreamHandler(process.getErrorStream());
		    	Thread errorThread = new Thread(new StreamHandler(process.getErrorStream()));
		    	errorThread.start();

		    	//get results and errors
	    		List<String> messages = messageHandler.getResults();
	    		List<String> errors = errorHandler.getResults();
		    	
	    		if(errors.size() == 0)
	    		{
	    			toReturn = true;
	    		}
 	
    	}catch (IOException e){
    		
    	}
		return toReturn;
    }
    
    /**
     * Verify server bluetooth.
     *
     * @param pBTDeviceToConnectMac the bT device to connect mac
     * @return true, if successful
     */
    private boolean verifyServerBluetooth(String pBTDeviceToConnectMac) {
    	boolean toReturn = false;
    	
    	try{  		
	    		//run "ip link show"
	    		StringBuilder cmd = new StringBuilder("ip link show");
	    		cmd.append("\n");
		    	Process process = Runtime.getRuntime().exec(cmd.toString());
	    		StreamHandler messageHandler = new StreamHandler(process.getInputStream());
		    	Thread inputThread = new Thread(messageHandler);
		    	inputThread.start();
		    	StreamHandler errorHandler = new StreamHandler(process.getErrorStream());
		    	Thread errorThread = new Thread(new StreamHandler(process.getErrorStream()));
		    	errorThread.start();

		    	//get results and errors
	    		List<String> messages = messageHandler.getResults();
	    		List<String> errors = errorHandler.getResults();
		    	
		    	for(int i = 0; i < messages.size(); i++)
		    	{
		    		if(messages.get(i).contains(DEVICE_NAME) || errors.size() == 0)
		    		{
		    			toReturn = true;
		    		}
		    	}
    	}catch (IOException e){
    		
    	}
		return toReturn;
    }
    
    /**
     * Assign ip to bt device.
     *
     * @param pBTServerAddress the bT server address
     * @param pDeviceName the device name
     * @param pBitmask the bitmask
     * @return true, if successful
     */
    private boolean assignIpToBTDevice(String pBTServerAddress, String pDeviceName, int pBitmask) {
    	boolean toReturn = false;
    	
    	try{
	    		StringBuilder cmd = new StringBuilder();
	    		cmd.append("ip addr add ");
	    		cmd.append(pBTServerAddress);
	    		cmd.append("/");
	    		cmd.append(pBitmask);
	    		cmd.append(" dev ");
	    		cmd.append(pDeviceName);
	    		cmd.append(" \n");
		    	Process process = Runtime.getRuntime().exec(cmd.toString());
	    		StreamHandler messageHandler = new StreamHandler(process.getInputStream());
		    	Thread inputThread = new Thread(messageHandler);
		    	inputThread.start();
		    	StreamHandler errorHandler = new StreamHandler(process.getErrorStream());
		    	Thread errorThread = new Thread(new StreamHandler(process.getErrorStream()));
		    	errorThread.start();

		    	//get results and errors
	    		List<String> messages = messageHandler.getResults();
	    		List<String> errors = errorHandler.getResults();
		    	
		    	if(errors.size() == 0)
		    	{
		    		toReturn = true;
		    	}
	    	
    	}catch (IOException e){
    		
    	}
		return toReturn;
    }
    
    /**
     * Activate btip.
     *
     * @param pDeviceName the device name
     * @return true, if successful
     */
    private boolean activateBTIP(String pDeviceName) {
    	boolean toReturn = false;

    	try{
	    		StringBuilder cmd = new StringBuilder();
	    		cmd.append("ip link set ");
	    		cmd.append(pDeviceName);
	    		cmd.append(" up");
	    		cmd.append(" \n");
	    		
		    	Process process = Runtime.getRuntime().exec(cmd.toString());
	    		StreamHandler messageHandler = new StreamHandler(process.getInputStream());
		    	Thread inputThread = new Thread(messageHandler);
		    	inputThread.start();
		    	StreamHandler errorHandler = new StreamHandler(process.getErrorStream());
		    	Thread errorThread = new Thread(new StreamHandler(process.getErrorStream()));
		    	errorThread.start();
		    	
		    	//get results and errors
	    		List<String> messages = messageHandler.getResults();
	    		List<String> errors = errorHandler.getResults();
		    	
		    	if(errors.size() == 0)
		    	{
		    		toReturn = true;
		    	}
	    	
    	}catch (IOException e){
    		
    	}
		return toReturn;
    }
}
