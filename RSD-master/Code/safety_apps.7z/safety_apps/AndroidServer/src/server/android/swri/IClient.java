/*
 * 
 */
package server.android.swri;


// TODO: Auto-generated Javadoc
/**
 * The Interface IClient.
 */
public interface IClient{
	
	/**
	 * The Enum SocketState.
	 */
	public enum SocketState{
		
		/** The Not connected. */
		NotConnected,
		
		/** The Connected. */
		Connected
	}
	
	/**
	 * Connect.
	 *
	 * @return the boolean
	 */
	Boolean connect();
		
	/**
	 * Handle received.
	 *
	 * @param pData the data
	 * @param pDataLength the data length
	 * @return the boolean
	 */
	Boolean handleReceived(byte[] pData, int pDataLength);
	
	/**
	 * Send.
	 *
	 * @param pData the data
	 * @return the boolean
	 */
	Boolean send(byte[] pData);
	
	/**
	 * Start.
	 *
	 * @param pThreadName the thread name
	 * @return the boolean
	 */
	Boolean start(String pThreadName);
	
	/**
	 * Start reconnect thread.
	 */
	void startReconnectThread();
	
	/**
	 * Stop.
	 */
	void stop();
}
