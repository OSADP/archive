/*
 * 
 */
package server.android.swri;

import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.view.ViewGroup.LayoutParams;
import android.widget.*;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.CompoundButton.OnCheckedChangeListener;

// TODO: Auto-generated Javadoc
/**
 * The Class RsdDviDemoActivity.
 */
public class RsdDviDemoActivity extends Activity {
	
	private final int CSW_INDEX = 5;
	private final int FCW_INDEX = 6;
	private final int EEBL_INDEX = 7;
	private final int TIM_INDEX = 9;
	
	
	/**
	 * The Class RsdGallery.
	 */
	private class RsdGallery extends Gallery {

		/**
		 * Instantiates a new rsd gallery.
		 *
		 * @param context the context
		 */
		public RsdGallery(Context context) {
			super(context);
		
		}
		
		/* (non-Javadoc)
		 * @see android.widget.Gallery#onFling(android.view.MotionEvent, android.view.MotionEvent, float, float)
		 */
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
		                       float velocityY) {        
		    return false;
		}
	}
	
	/**
	 * The Class Listener.
	 */
	private class Listener implements OnItemSelectedListener, OnCheckedChangeListener {
		
		/* (non-Javadoc)
		 * @see android.widget.AdapterView.OnItemSelectedListener#onItemSelected(android.widget.AdapterView, android.view.View, int, long)
		 */
		public void onItemSelected(AdapterView<?> pParent, View pView, int pPosition,
				long pId) {
			
				PlaySoundForSlide(pPosition);
				
				
				if(pPosition == mLastSlideIndex) {
					finish();
				}
		}
		
		private void PlaySoundForSlide(int pPosition) {
			
			//if slide is of a warning play appropriate sound
			
			try {
				
				AssetFileDescriptor assetFileDescriptor = null;
				
				switch(pPosition) {
				
				case CSW_INDEX:
					
					assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_CURVE_SPEED_WARNING_ALERT());
					break;
					
				case FCW_INDEX:
					
					assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_FORWARD_COLLISION_WARNING());
					break;
					
				case EEBL_INDEX:
					
					assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS());
					break;
					
				case TIM_INDEX:
					
					assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_J2735_TRAVELER_ADVISORY());
					break;
					
				default:
					
					break;
				}
				
				if (assetFileDescriptor != null) {
					IAudioMessage audioMsg = new PlayAudioAssetMessage("ALERT",
							assetFileDescriptor);
					audioMsg.play();
				}
			}
			
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		/* (non-Javadoc)
		 * @see android.widget.AdapterView.OnItemSelectedListener#onNothingSelected(android.widget.AdapterView)
		 */
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see android.widget.CompoundButton.OnCheckedChangeListener#onCheckedChanged(android.widget.CompoundButton, boolean)
		 */
		public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
			mConfiguration.setSkipDemo(arg1);		
		}
	}
	
	/**
	 * The Class ImageAdapter.
	 */
	private class ImageAdapter extends BaseAdapter {
	    
    	/** The m gallery item background. */
    	int mGalleryItemBackground;
	    
    	/** The m context. */
    	private Context mContext;

	    /** The m image ids. */
    	private Integer[] mImageIds = {
	    		R.drawable.demo_1,
	            R.drawable.demo_2,
	            R.drawable.demo_3,
	            R.drawable.demo_4,
	            R.drawable.demo_5,
	            R.drawable.demo_6,
	            R.drawable.demo_7,
	            R.drawable.demo_8,
	            //for version 1.2.0 removed 'Travel Advisory Message' slides from demo
	            //R.drawable.demo_9,
	            //R.drawable.demo_10, 
	            R.drawable.demo_end, 
	            R.drawable.demo_placeholder
	    };

	    /**
    	 * Instantiates a new image adapter.
    	 *
    	 * @param c the c
    	 */
    	public ImageAdapter(Context c) {

    		mContext = c;
	        TypedArray attr = mContext.obtainStyledAttributes(R.styleable.HelloGallery);
	        mGalleryItemBackground = attr.getResourceId(
	                R.styleable.HelloGallery_android_galleryItemBackground, 0);
	        attr.recycle();
		    }
	
		    /* (non-Javadoc)
    		 * @see android.widget.Adapter#getCount()
    		 */
    		public int getCount() {
		        return mImageIds.length;
		    }
	
		    /* (non-Javadoc)
    		 * @see android.widget.Adapter#getItem(int)
    		 */
    		public Object getItem(int position) {
		        return position;
		    }
	
		    /* (non-Javadoc)
    		 * @see android.widget.Adapter#getItemId(int)
    		 */
    		public long getItemId(int position) {
		        return position;
		    }
	
		    /* (non-Javadoc)
    		 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
    		 */
    		public View getView(int position, View convertView, ViewGroup parent) {

		    	View toReturn = null;
		    	
		    	ImageView imageView = new ImageView(mContext);
		    	imageView.setId(position);
		        imageView.setImageResource(mImageIds[position]);
		        imageView.setLayoutParams(new Gallery.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
		        imageView.setBackgroundResource(mGalleryItemBackground);
		        imageView.setBackgroundColor(Color.BLACK);

		    	if(position != mLastSlideIndex - 1) {
		    		toReturn = imageView;
		    	}
		    	else if(position == mLastSlideIndex - 1){
			    	LinearLayout thisView = new LinearLayout(mContext);
			    	thisView.setOrientation(LinearLayout.VERTICAL);
			    	
			    	thisView.addView(imageView);
			    	
			    	mSkipDemoBox = new CheckBox(mContext);
			    	mSkipDemoBox.setText("Skip demo on startup");
			    	mSkipDemoBox.setTextColor(Color.WHITE);
			    	mSkipDemoBox.setTextSize(50);
			    	mSkipDemoBox.setGravity(Gravity.BOTTOM);
			    	mSkipDemoBox.setOnCheckedChangeListener(mListener);
			    	mSkipDemoBox.setVisibility(CheckBox.VISIBLE);
			    	mSkipDemoBox.setChecked(mConfiguration.getSkipDemo());
			    	thisView.addView(mSkipDemoBox);
			    	
			    	toReturn = thisView;
		    	}
		        return toReturn;
		    }
		}	
	
	/** The m context. */
	Context mContext;
	
	/** The m view. */
	LinearLayout mView;
	
	/** The m gallery. */
	RsdGallery mGallery;
	
	/** The m listener. */
	Listener mListener;
	
	/** The m adapter. */
	ImageAdapter mAdapter;
	
	/** The m last slide index. */
	int mLastSlideIndex;
	
	/** The m skip demo box. */
	CheckBox mSkipDemoBox;
	
	/** The m configuration. */
	Configuration mConfiguration;
	
	
    /**
     * Called when the activity is first created.
     *
     * @param savedInstanceState the saved instance state
     */
    @Override
    public void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);
    	mConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
    	
    	mView = new LinearLayout(this);  
    	mGallery = new RsdGallery(this);
    	mAdapter = new ImageAdapter(this);
    	mGallery.setAdapter(mAdapter); 
    	mGallery.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
    	mGallery.setGravity(Gravity.CENTER_HORIZONTAL);
    	mListener = new Listener();
    	mGallery.setOnItemSelectedListener(mListener);
    	mView.addView(mGallery);

    	setContentView(mView);
    	
    	mLastSlideIndex = mAdapter.getCount() - 1;
    }
	
    /* (non-Javadoc)
    * @see android.app.Activity#onAttachedToWindow()
    * enables capture of back and home KeyEvents
    */
    @Override
    public void onAttachedToWindow()
    {  
    	   //if configured to be locked down back and home events will be captured by dispatchKeyEvent
           if (mConfiguration.getLockdownTablet()) {
			this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		}
           
		super.onAttachedToWindow();
    }
    
    /* (non-Javadoc)
     * @see android.app.Activity#dispatchKeyEvent(android.view.KeyEvent)
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
    	
    	boolean toReturn;
    	
    	//if configured to be locked down back and home events will be captured by dispatchKeyEvent
        if (mConfiguration.getLockdownTablet()) {
        	toReturn = true;
		}
        else {
        	toReturn = false;
        }
        return toReturn;
    }
}
