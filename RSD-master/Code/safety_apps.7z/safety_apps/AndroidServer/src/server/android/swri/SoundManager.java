/*
 * 
 */
package server.android.swri;

import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

// TODO: Auto-generated Javadoc
/**
 * The Class SoundManager.
 */
public class SoundManager{
	
	/** The m sound pool. */
	private SoundPool mSoundPool;
	
	/** The m sound pool map. */
	private Map mSoundPoolMap;
	
	/** The m audio manager. */
	private AudioManager mAudioManager;
	
	/** The m context. */
	private Context mContext;
	
	/**
	 * Instantiates a new sound manager.
	 *
	 * @param pContext the context
	 */
	public SoundManager(Context pContext){
		mContext = pContext;
		mSoundPool = new SoundPool(4, AudioManager.STREAM_MUSIC, 0);
		mSoundPoolMap = new HashMap();
		mAudioManager = (AudioManager)mContext.getSystemService(Context.AUDIO_SERVICE);
	}
	
	/**
	 * Adds the sound.
	 *
	 * @param pIndex the index
	 * @param pSoundID the sound id
	 */
	public void addSound(int pIndex, int pSoundID){
		mSoundPoolMap.put(pIndex, mSoundPool.load(mContext, pSoundID, 1));
	}
	
	/**
	 * Play sound.
	 *
	 * @param pIndex the index
	 */
	public void playSound(int pIndex){
	float streamVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
	streamVolume = streamVolume / mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
	    mSoundPool.play((Integer) mSoundPoolMap.get(pIndex), streamVolume, streamVolume, 1, 0, 1f);
	}
	 
	/**
	 * Play looped sound.
	 *
	 * @param pIndex the index
	 */
	public void playLoopedSound(int pIndex){
	    float streamVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
	    streamVolume = streamVolume / mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
	    mSoundPool.play((Integer) mSoundPoolMap.get(pIndex), streamVolume, streamVolume, 1, -1, 1f);
	}
}
