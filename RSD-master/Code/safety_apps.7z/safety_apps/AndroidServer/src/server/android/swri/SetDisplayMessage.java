/*
 * 
 */
package server.android.swri;

import server.android.swri.RsdDviConstants.MessageType;

/**
 * The Class SetDisplayMessage.
 */
public class SetDisplayMessage extends ActivityMessage{
	
	/** The m image res id. */
	private int mImageResID;
	
	/**
	 * Instantiates a new sets the display message.
	 *
	 * @param pMessage the message
	 * @param pImageResId the image res id
	 */
	public SetDisplayMessage(String pMessage, int pImageResId){
		this(pMessage, pImageResId, MessageType.SET_DISPLAY_MSG);
	}

	public SetDisplayMessage(String pMessage, int pImageResId, int setDebugDisplayMsg) {
		super(setDebugDisplayMsg, pMessage);
		mImageResID = pImageResId;
	}

	/**
	 * Gets the m image res id.
	 *
	 * @return the m image res id
	 */
	public int getmImageResID(){
		return mImageResID;
	}

}
