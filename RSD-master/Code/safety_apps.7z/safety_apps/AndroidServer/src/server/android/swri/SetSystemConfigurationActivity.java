/*
 * 
 */
package server.android.swri;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.*;
import android.widget.AdapterView.OnItemSelectedListener;

import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;

import javax.swing.text.TableView;

import server.android.swri.R.color;

// TODO: Auto-generated Javadoc
/**
 * The Class SetSystemConfigurationActivity.
 */
public class SetSystemConfigurationActivity extends Activity implements OnClickListener {
	
    /**
     * Class for interacting with the main interface of the service.
     */
/*    private ServiceConnection mConnection = new ServiceConnection(){
        public void onServiceConnected(ComponentName className,
                IBinder service){
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  We are communicating with our
            // service through an IDL interface, so get a client-side
            // representation of that from the raw service object.
        	mServiceMessenger = new Messenger(service);

			try{
				//monitor service
				
				//send initial message to AndroidService to register for updates
				Message msg = Message.obtain(null, RsdDviService.MessageType.REGISTER_CLIENT_MSG);
				mServiceMessenger.send(msg);
			} catch (RemoteException e){
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }

        public void onServiceDisconnected(ComponentName className) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            mService = null;
        }
    };*/
	
	private enum ConfigurationCodes{
		 
 		/** The CANCEL. */
 		CANCEL,
		 
 		/** The DEFAULTS. */
 		DEFAULTS,
		 
 		/** The NEW. */
 		NEW;
	}
	
	/** The m configuration. */
	private Configuration mConfiguration;
	
    /** The m configuration map. */
    private TreeMap<String, Object> mConfigurationMap;
    
    /** The m local cache. */
    private TreeMap<String, Object> mLocalCache;
    
    /** The m layout view. */
    private LinearLayout mLayoutView;
    
    /** The m fields table. */
    private TableLayout mFieldsTable;
    
    /** The m button table. */
    private TableLayout mButtonTable;
    
	/** The m cat res ids. */
	int[] mCatResIds;
	
	String[] mColorStrings;
	
	TypedArray mColorInts;
	
	/** The m cat res id strings. */
	String[] mCatResIdStrings;
	
	String[] mColorIntStrings;

	
/*	private Intent mService;
	private boolean mIsBound;*/
	/** The TAG. */
private final String TAG = "SetSystemConfigurationActivity";
	
/*	private Messenger mServiceMessenger = null;*/
	
    /**
 * Called when the activity is first created.
 *
 * @param savedInstanceState the saved instance state
 */
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
              
        mConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
          
        mConfigurationMap = mConfiguration.getAllSettings();
        
        mLocalCache = new TreeMap<String, Object>();
        
        loadConfiguration();
        
		this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        
        // Set result CANCELED in case the user backs out
        setResult(Activity.RESULT_CANCELED);
        
/*		mService = new Intent(this.getApplicationContext(), RsdDviService.class);
		doBindService();*/     
    }
    
    /**
     * Load configuration.
     */
    private void loadConfiguration() {
    	
    	int rowHeight = 60;
    	int rowWidth = 700;

        ScrollView scrollView = new ScrollView(this);

    	Iterator<String> keys = mConfigurationMap.keySet().iterator();
    	
    	mLayoutView = new LinearLayout(this);
    	mLayoutView.setOrientation(LinearLayout.VERTICAL);
    	scrollView.addView(mLayoutView);
    	
    	mFieldsTable = new TableLayout(this);
    	mFieldsTable.setOrientation(LinearLayout.VERTICAL);
    	mLayoutView.addView(mFieldsTable);
    	
		mCatResIds = getResources().getIntArray(R.array.CategoryIconIds);
		
		mColorStrings = getResources().getStringArray(R.array.ColorStrings);
		
		mColorInts = getResources().obtainTypedArray(R.array.Colors);
		
		mColorIntStrings = new String[mColorInts.length()];
		
		//get meaningful name for resId
		mCatResIdStrings = new String[mCatResIds.length];
    	 	
        //add a text box for each entry in configuration
    	while(keys.hasNext()) {
    		String thisKey = keys.next();
    		try {
				TextView name = new TextView(this);
				name.setText(thisKey);
				name.setTextSize(40);
				name.setHeight(rowHeight);
				name.setWidth(rowWidth);
				
				Object value = null;
						
				//parse value
				if(mConfigurationMap.get(thisKey) != null && mConfigurationMap.get(thisKey).getClass() == String.class) {		
					
					//if a sound add spinner
					if(thisKey.startsWith("SND_")) {
						
						String[] sounds = getResources().getStringArray(R.array.Sounds);
						
				        Spinner spinner = new SoundSpinner(this, sounds);
						
				        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Sounds, android.R.layout.simple_spinner_item);
				        
				        adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
				        
				        spinner.setAdapter(adapter);
				        
				        //set spinner value to this key
				        for(int i = 0; i < sounds.length; i++) {
				        	if(sounds[i] != null && sounds[i].equals(mConfigurationMap.get(thisKey))) {
				        		spinner.setSelection(i);
				        	}
				        }
						
						value = spinner;
					}
					
					else {
						value = new EditText(this);
						
						((TextView) value).setText((String) mConfigurationMap.get(thisKey));
						((TextView) value).setTextSize(30);
						((TextView) value).setHeight(rowHeight);
						((TextView) value).setInputType(InputType.TYPE_CLASS_TEXT);
					}

				}
				else if(mConfigurationMap.get(thisKey) != null && mConfigurationMap.get(thisKey).getClass() == Integer.class) {
					
					//if a category add spinner
					if(thisKey.startsWith("CAT_")) {
						
						int valueIndex = 0;
						for(int i = 0; i < mCatResIds.length; i++) {
							mCatResIdStrings[i] = getResources().getResourceEntryName(mCatResIds[i]);
							
							//save index of current value
							if(mCatResIds[i] == (Integer) mConfigurationMap.get(thisKey)) {
								valueIndex = i;
							}
						}
						
						Spinner spinner = new Spinner(this);
						
						ArrayAdapter<CharSequence> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, mCatResIdStrings);
						
						spinner.setAdapter(adapter);
						
						spinner.setSelection(valueIndex);
						
						value = spinner;
					}
					
					//if a color add spinner
					else if(thisKey.startsWith("COLOR_")) {
						
						int valueIndex = 0;
						for(int i = 0; i < mColorInts.length(); i++) {
							mColorIntStrings[i] = Integer.toString(mColorInts.getColor(i, 0));
							if(mColorInts.getColor(i, 0) ==  (Integer) mConfigurationMap.get(thisKey)) {
								valueIndex = i;
							}
							
						}
						
						Spinner spinner = new ColoredSpinner(this, mColorInts);
						
						//Spinner spinner = new Spinner(this);
						
						//ArrayAdapter<CharSequence> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, mColorIntStrings);
						
						ArrayAdapter<CharSequence> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, mColorStrings);
						
				        adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
				            
				        spinner.setAdapter(adapter);
				        
				        spinner.setSelection(valueIndex);
				        
				        //spinner.setBackgroundColor(mColorInts.getColor(valueIndex, 0));
				        
						value = spinner;
					}
					
					else {
						 value = new EditText(this);
						((TextView) value).setText(Integer.toString( (Integer) mConfigurationMap.get(thisKey)));
						((TextView) value).setTextSize(30);
						((TextView) value).setHeight(rowHeight);
						((TextView) value).setInputType(InputType.TYPE_CLASS_NUMBER);
					}	

				}
				else if(mConfigurationMap.get(thisKey) != null && mConfigurationMap.get(thisKey).getClass() == Boolean.class) {
					value = new CheckBox(this);
					((CompoundButton) value).setChecked((Boolean)mConfigurationMap.get(thisKey));
					((CompoundButton) value).setHeight(rowHeight);
				}

				if (value != null) {
					//add controls to mLocalCache for easy retrieval
					mLocalCache.put(thisKey, value);
					//add controls to view
					TableRow thisRow = new TableRow(this);
					thisRow.addView(name);
					thisRow.addView((View) value);
					mFieldsTable.addView(thisRow);
				}
			} catch (Exception e) {

				e.printStackTrace();
				Log.d(TAG, "Exception in : loadConfiguration()" + thisKey);
			}
    	}
    	
    	mButtonTable = new TableLayout(this);

    	mButtonTable.setOrientation(LinearLayout.VERTICAL);
    	mButtonTable.setGravity(Gravity.CENTER);
    	mLayoutView.addView(mButtonTable);
    	
    	TableRow buttonRow = new TableRow(this);
    	
    	Button cancelBtn = new Button(this);
    	cancelBtn.setText("Cancel");
    	cancelBtn.setTag(ConfigurationCodes.CANCEL);
    	cancelBtn.setOnClickListener(this);
    	cancelBtn.setWidth(0);
    	buttonRow.addView(cancelBtn);
        
    	Button defaultBtn = new Button(this);
    	defaultBtn.setText("Reset to Defaults");
    	defaultBtn.setTag(ConfigurationCodes.DEFAULTS);
    	defaultBtn.setOnClickListener(this);
    	defaultBtn.setWidth(0);
    	buttonRow.addView(defaultBtn);
    	
    	Button submitBtn = new Button(this);
    	submitBtn.setTag(ConfigurationCodes.NEW);
    	submitBtn.setText("Submit Configuration");
        submitBtn.setOnClickListener(this);
        submitBtn.setWidth(0);
        buttonRow.addView(submitBtn);
        
    	mButtonTable.setColumnStretchable(0, true);
    	mButtonTable.setColumnStretchable(1, true);
    	mButtonTable.setColumnStretchable(2, true);
        mButtonTable.addView(buttonRow);
              
    	setContentView(scrollView);
    }
    
    /**
     * Update configuration map with local values.
     *
     * @return true, if successful
     */
    private boolean updateConfigurationMapWithLocalValues() {
    	boolean toReturn = false;
    	Iterator<String> keys = mConfigurationMap.keySet().iterator();
    	String thisKey = null;
    	while(keys.hasNext()) {
			thisKey = keys.next();
    		try {
				Object edited = null;

				//parse value from EditText into appropriate objects for configuration map
				if(mConfigurationMap.get(thisKey) != null && mConfigurationMap.get(thisKey).getClass() == String.class) {
					//if a sound get value from spinner
					if(thisKey.startsWith("SND_")) {
						edited = ((Spinner)mLocalCache.get(thisKey)).getSelectedItem().toString();
					}
					
					else {
						edited = ((EditText)mLocalCache.get(thisKey)).getText().toString();	
					}
				}
				else if(mConfigurationMap.get(thisKey) != null && mConfigurationMap.get(thisKey).getClass() == Integer.class) {
					
					//if a category get value from spinner
					if(thisKey.startsWith("CAT_")) {
						int selected = ((Spinner)mLocalCache.get(thisKey)).getSelectedItemPosition();
						edited = mCatResIds[selected];
					}
					
					else if(thisKey.startsWith("COLOR_")) {
						
						int index = ((Spinner)mLocalCache.get(thisKey)).getSelectedItemPosition();
						
						//edited = ((Spinner)mLocalCache.get(thisKey)).getSelectedItem().toString();
						edited = mColorInts.getInt(index, 0);
					}
					
					else {
						edited = Integer.parseInt(((EditText)mLocalCache.get(thisKey)).getText().toString());
					}
				}
				else if(mConfigurationMap.get(thisKey) != null && mConfigurationMap.get(thisKey).getClass() == Boolean.class) {
					edited = ((CheckBox)mLocalCache.get(thisKey)).isChecked();
				}
				if(edited != null) {
					mConfigurationMap.put(thisKey, edited);
				}
			} catch (Exception e) {
				Log.d(TAG, "Error parsing EditText: " + thisKey);
			}
    	}
    	
    	return toReturn;
    }


	/* (non-Javadoc)
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	public void onClick(View pView) {
		
        // Create the result Intent
        Intent intent = new Intent();
		
		switch((ConfigurationCodes)pView.getTag()) {
			
			case CANCEL:
		        intent.putExtra(ConfigurationCodes.CANCEL.toString(), true);
		        
		        // Set result and finish this Activity
		        setResult(Activity.RESULT_CANCELED, intent);
		        finish();
				break;
				
			case DEFAULTS:
				//set to values stored in strings.xml
				mConfiguration.loadDefaultValues();
				loadConfiguration();
				
				break;
				
			case NEW:
				intent.putExtra(ConfigurationCodes.NEW.toString(), true);
				updateConfigurationMapWithLocalValues();
				if(mConfiguration.updateSharedPreferences(mConfigurationMap)) {
	    	    	Toast toast = Toast.makeText(this, "Successfully applied changes to Shared Preferences. Some changes may require a reboot.", Toast.LENGTH_LONG);
	    	    	toast.show();
				}
				
				if(mConfiguration.updateLocalCache(mConfigurationMap)) {
	    	    	Toast toast = Toast.makeText(this, "Successfully applied changes configuration cache. Some changes may require a reboot.", Toast.LENGTH_LONG);
	    	    	toast.show();
				}
				
		        // Set result and finish this Activity
		        setResult(Activity.RESULT_OK, intent);
		        finish();
				break;
		
		}
	
	}

}
