package server.android.swri;

import server.android.swri.RsdDviConstants.DriverConfigData;
import server.android.swri.RsdDviConstants.TrailerConfigData;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class SetDriverConfigurationActivity extends Activity implements OnSeekBarChangeListener, OnClickListener{

	private SeekBar mBrightnessBar;
	private Button mCancelButton;
	private Button mSubmitButton;
	private float mOriginalBrightness;
	private int mDesiredBrightness;
	private static float MINIMUM_BRIGHTNESS = .1F;
	
	/** The m configuration. */
	Configuration mConfiguration;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    mConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
	    
	    setContentView(R.layout.set_driver_configuration);
	    
	    mBrightnessBar = (SeekBar)findViewById(R.id.seekBar1);
	    mBrightnessBar.setOnSeekBarChangeListener(this);
	    
	    mSubmitButton = (Button)findViewById(R.id.button1);
	    mSubmitButton.setOnClickListener(this);
	    
	    mCancelButton = (Button)findViewById(R.id.button2);
	    mCancelButton.setOnClickListener(this);
	    
	    //get data sent for this configuration screen
        Bundle data = this.getIntent().getExtras();
        mOriginalBrightness =  data.getFloat(DriverConfigData.BRIGHTNESS, MINIMUM_BRIGHTNESS);
        
        //set position of SeekBar
        int currentBarProgress = (int) (100 * mOriginalBrightness);
        mBrightnessBar.setProgress(currentBarProgress);
	    
        // Set result CANCELED in case the user backs out
        setResult(Activity.RESULT_CANCELED);
	}


	public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
		mDesiredBrightness = arg1;
		float brightness = (float) arg1 / 100;
		if(brightness < MINIMUM_BRIGHTNESS) {
			brightness = MINIMUM_BRIGHTNESS;
		}
		
		setScreenBrightness(brightness);
	}

	public void onStartTrackingTouch(SeekBar arg0) {
		// TODO Auto-generated method stub
	}

	public void onStopTrackingTouch(SeekBar arg0) {
		// TODO Auto-generated method stub
	}
	
    /**
     * Send configuration.
     */
    private void setReturnValue(int pValue) {
        
        Intent intent = new Intent();
        intent.putExtra(RsdDviConstants.DriverConfigData.BRIGHTNESS, pValue);

        // Set result
        setResult(Activity.RESULT_OK, intent);
    }
	
	public void setScreenBrightness(float pBrightness) {
		WindowManager.LayoutParams lp = getWindow().getAttributes();
		lp.screenBrightness = pBrightness;
		getWindow().setAttributes(lp);

	}


	public void onClick(View arg0) {
		switch(arg0.getId()) {
		
		//submit button
		case R.id.button1:
			setReturnValue(mDesiredBrightness);
			finish();
			break;
			
		//cancel button
		case R.id.button2:
			setResult(Activity.RESULT_CANCELED);
			finish();
			break;
		}
	}
	
    /* (non-Javadoc)
    * @see android.app.Activity#onAttachedToWindow()
    * enables capture of back and home KeyEvents
    */
   @Override
    public void onAttachedToWindow()
    {  
		this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
 
		super.onAttachedToWindow();
    }
    
   /* (non-Javadoc)
    * @see android.app.Activity#dispatchKeyEvent(android.view.KeyEvent)
    */
   @Override
   public boolean dispatchKeyEvent(KeyEvent event) {
   	
   	boolean toReturn;
   	
   	//if configured to be locked down back and home events will be captured by dispatchKeyEvent
       if (mConfiguration.getLockdownTablet()) {
       	toReturn = true;
		}
       else {
       	toReturn = false;
       }
       return toReturn;
   }

}
