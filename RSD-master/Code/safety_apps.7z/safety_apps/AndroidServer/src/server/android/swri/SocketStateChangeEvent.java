/*
 * 
 */
package server.android.swri;
import java.util.EventObject;

// TODO: Auto-generated Javadoc
/**
 * The Class SocketStateChangeEvent.
 */
public class SocketStateChangeEvent extends EventObject{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	//variables needed in event
	/** The socket connected. */
	private IClient.SocketState socketConnected;
	
	/** The name. */
	private String name;
	
	/**
	 * Instantiates a new socket state change event.
	 *
	 * @param source the source
	 * @param pState the state
	 * @param pName the name
	 */
	public SocketStateChangeEvent(Object source, IClient.SocketState pState, String pName){
		super(source);
		socketConnected = pState;
		name = pName;
	}
	
	/**
	 * Socket state.
	 *
	 * @return the i client. socket state
	 */
	public IClient.SocketState SocketState(){
		return socketConnected;
	}
	
	/**
	 * Name.
	 *
	 * @return the string
	 */
	public String Name(){
		return name;
	}
	
	/**
	 * Source.
	 *
	 * @return the object
	 */
	public Object Source(){
		return source;
	}
}