/*
 * 
 */
package server.android.swri;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving TCP events.
 * The class that is interested in processing a TCP
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addTCPListener<code> method. When
 * the TCP event occurs, that object's appropriate
 * method is invoked.
 *
 * @see TCPEvent
 */
public class TCPListener
{
	
	/** The m local host. */
	private InetAddress mLocalHost;
	
	/** The m port. */
	private int mPort;
	
	/** The m server socket. */
	private ServerSocket mServerSocket;
	
	/**
	 * Instantiates a new tCP listener.
	 *
	 * @param pHost the host
	 * @param pPort the port
	 */
	public TCPListener(InetAddress pHost, int pPort){
		mLocalHost = pHost;
		mPort = pPort;
	}
	
	/**
	 * Accept socket.
	 *
	 * @return the socket
	 */
	public Socket AcceptSocket(){
		Socket socket = null;
		try
		{
			socket = mServerSocket.accept();
		}catch (IOException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return socket;
	}
	
	/**
	 * Start.
	 */
	public void Start(){
		try{
			mServerSocket = new ServerSocket(mPort);
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Stop.
	 */
	public void Stop(){
		try{
			mServerSocket.close();
		}catch (IOException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
