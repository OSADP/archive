/*
 * 
 */
package server.android.swri;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.drawable.Drawable;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;
import java.lang.Process;
import server.android.swri.RsdDviConstants.Header;
import server.android.swri.RsdDviConstants.MessageType;
import server.android.swri.RsdDviConstants.RSDSystem;
import server.android.swri.RsdDviConstants.ShutdownType;
import server.android.swri.RsdDviConstants.TrailerConfigData;


// TODO: Auto-generated Javadoc
/**
 * The Class RsdDviService.
 */
public class RsdDviService extends Service implements ISocketMessageListener, ISocketStateListener {
	
	/**
	 * The Class RsdPowerChangeReceiver.
	 */
	private class RsdPowerChangeReceiver extends BroadcastReceiver {

		/* (non-Javadoc)
		 * @see android.content.BroadcastReceiver#onReceive(android.content.Context, android.content.Intent)
		 */
		@Override
		public synchronized void onReceive(Context context, Intent intent) {
			
			int pct=100*intent.getIntExtra("level", 1)/intent.getIntExtra("scale", 1);
			int plugged=intent.getIntExtra("plugged", -1);
			if (plugged==BatteryManager.BATTERY_PLUGGED_AC) {
				
				//if rebooting we don't need the timers but nice to leave as is for testing
				cancelShutdownDelayTimer();
				cancelShutdown();
				if(mSleeping)
				{
					reboot();
				}				
			}
			
			else {
				//start timer for DisconnectShutdownDelay (which will initiate the actual shutdown timer upon expiration)
				initiateShutdownDelayTimer(mConfiguration.getShutdownTimerDelay());
				
				//when power is unplugged shut down after configurable delay
				//initiateShutdown(ShutdownType.POWER_DISCONNECT, mConfiguration.getDelayUntilShutdown());
			}
		}	
	}
	
	/**
	 * Initiate shutdown.
	 *
	 * @param pType the type
	 * @param pDelay the delay
	 */
	private synchronized void initiateShutdownDelayTimer(int pDelay) {
		try {
			
			if(mShutdownDelayTask == null)
			{
				mShutdownDelayTask = new ShutdownDelayTask();
			}
			if (mShutdownDelayTimer == null) {
				mShutdownDelayTimer = new Timer("mShutdownDelayTimer");
				mShutdownDelayTimer.schedule(mShutdownDelayTask, pDelay);
				
				Log.d(TAG, "mShutdownDelayTimer scheduled in " + pDelay);
			}
			else {
				Log.d(TAG, "mShutdownDelayTimer already exists");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception initializing ShutdownDelayTimer: " + e.getMessage());
		}
	}
	
	private synchronized void goToSleep() {
		try {
			mSleeping = true;
			mPowerManager.goToSleep(SystemClock.uptimeMillis());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	private synchronized void reboot() {
		try {
			mPowerManager.reboot(POWER_SERVICE);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.d(TAG, e.getMessage());
		}
	}
	
	private synchronized void hibernate() {
		//disable wifi
		
		//stop broadcasting
		cancelBroadcastTimer();
		
		//set screen black
		Message msgToDeliver = Message.obtain(null, MessageType.CLEAR_DISPLAY_MSG, null);
		sendMessageToClients(msgToDeliver);
	}
	
	/**
	 * Cancel timer and stop broadcasting.
	 */
	private void cancelBroadcastTimer() {
		
		try {

			if (mBroadcastTimer != null) {
				mBroadcastTimer.cancel();
			}
				
			if(mBroadcastTask == null)
			{
				mBroadcastTask.cancel();
			}
			
		} catch (Exception e) {
			Log.d(TAG, "Exception cancelling Broadcast Timer: " + e.getMessage());
		}
	}

	
	
	
	/**
	 * Initiate shutdown.
	 *
	 * @param pType the type
	 * @param pDelay the delay
	 */
	private synchronized void initiateShutdown(ShutdownType pType, int pDelay) {
		try {
			
			mShuttingDown = true;
			mShutdownDelay = pDelay;
			mShutdownType = pType;
			
			if(mShutdownTask == null)
			{
				mShutdownTask = new ShutdownTask();
			}
			if (mShutdownTimer == null) {
				mShutdownTimer = new Timer("mShutdownTimer");
				mShutdownTimer.schedule(mShutdownTask, pDelay);
				
				Log.d(TAG, "mShutdownTimer scheduled in " + pDelay);
				
		    	//show RsdDviActivity so users can see shutdown message	
				//message is created in BroadcastTask
		    	startActivity(mRsdDviActivityIntent);
		    	
				mCount = 0;
			}
			else {
				Log.d(TAG, "mShutdownTimer already exists");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception initializing Shutdown Timer: " + e.getMessage());
		}
	}
	
	/**
	 * Cancel shutdown.
	 */
	private synchronized void cancelShutdownDelayTimer() {
		try {
			
			//cancel ShutdownDelayTimer
			if(mShutdownDelayTimer != null) {
				mShutdownDelayTimer.cancel();
				mShutdownDelayTimer = null;
				Log.d(TAG, "Canceling ShutdownDelayTimer");

			}
			if(mShutdownDelayTask != null) {
				mShutdownDelayTask.cancel();
				mShutdownDelayTask = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception canceling ShutdownDelayTimer: " + e.getMessage());
		}
	}
	
	/**
	 * Cancel shutdown.
	 */
	private synchronized void cancelShutdown() {
		try {
			mShuttingDown = false;
			mShutdownDelay = -1;
			
			//cancel ShutdownTimer
			if(mShutdownTimer != null) {
				mShutdownTimer.cancel();
				mShutdownTimer = null;
				Log.d(TAG, "Canceling Shutdown Timer");

			}
			if(mShutdownTask != null) {
				mShutdownTask.cancel();
				mShutdownTask = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception canceling Shutdown Timer: " + e.getMessage());
		}
	}
	
	//following for threaded service
	/**
	 * The Class ServiceHandler.
	 */
	private final class ServiceHandler extends Handler
	{
		//handler for messages
		/**
		 * Instantiates a new service handler.
		 *
		 * @param pLooper the looper
		 */
		public ServiceHandler(Looper pLooper)
		{
			super(pLooper);
		}
	}
	
	/**
	 * The Class BroadcastTask.
	 */
	private class BroadcastTask extends TimerTask{	
		
		/* (non-Javadoc)
		 * @see java.util.TimerTask#run()
		 */
		@Override
		public void run(){
			
			ActivityMessage setDisplayMsg = null;
			IAudioMessage playAudioMsg = null;
			
			try {				
				//get highest priority active SafetyAppMessage
				SafetyAppMessage currentPriorityMessage = getHighestPriorityActiveMessage();
				
				if (!mShuttingDown) {
					//no current active message so set current message to null
					if (currentPriorityMessage == null) {
						mCurrentSafetyAppMessage = null;
					}

					//active message has not changed but check time activated if new send audio
					else if (mCurrentSafetyAppMessage != null
							&& mCurrentSafetyAppMessage.getId() == currentPriorityMessage
									.getId()) {
						setDisplayMsg = createSetDisplayMessage(currentPriorityMessage);
						
						//if this message activated after it was originally activated, send audio
						if(mPreviousActivationTime != null) {
							if(mCurrentSafetyAppMessage.getTimeActivated().compareTo(mPreviousActivationTime) > 0) {
								playAudioMsg = createPlayAudioMessage(currentPriorityMessage);
								
								//set activation time to now
								mPreviousActivationTime = new Date();
							}	
						}
					}

					//message has changed set current message to new message and send setDisplayMsg and playAudioMsg
					else {
						mCurrentSafetyAppMessage = currentPriorityMessage;
						playAudioMsg = createPlayAudioMessage(currentPriorityMessage);
						setDisplayMsg = createSetDisplayMessage(currentPriorityMessage);
						mCount = 0;
						mPreviousActivationTime = new Date();
					}
				}
				
				//shutting down so send warning
				else {							
					int timeRemaining = mShutdownDelay - mCount * mConfiguration.getMessageRefreshRateInMilliseconds();
					
					if(mShutdownType.equals(ShutdownType.POWER_DISCONNECT)) {
						setDisplayMsg = new SetDisplayMessage( String.valueOf(timeRemaining), R.drawable.disconnect);
					}
					else if (mShutdownType.equals(ShutdownType.SHUTDOWN_MSG)) {
						setDisplayMsg = new SetDisplayMessage( String.valueOf(timeRemaining), R.drawable.shutdown);
					}

					//version 1.2.0 audio alert is configurable
					//send single audio first time only
					if(mCount == 0) {
		    			if (mConfiguration.getShutdownAudioAlertEnabled()) {
							if (mConfiguration.getSND_DEFAULT().equals(
									RsdDviConstants.RINGTONE_STRING)) {
								playAudioMsg = new PlayAudioAlertMessage(
										"ALERT", mRingtone);
							} else {
								AssetFileDescriptor assetFileDescriptor = getAssets()
										.openFd(mConfiguration.getSND_DEFAULT());
								playAudioMsg = new PlayAudioAssetMessage(
										"SHUTTING DOWN", assetFileDescriptor);
							}
						}
					}
				}
				
				//play audio if there is one
				if(playAudioMsg != null){
					Message msgToDeliver = Message.obtain(null, playAudioMsg.getMessageType(), playAudioMsg);
					sendMessageToClients(msgToDeliver);
				}
				
				//send setDisplayMsg if there is one
				if(setDisplayMsg != null){
					
					//send as SetDebugDisplayMsg if in debug mode
					if(!mShuttingDown && mConfiguration.getDebugEnabled()) {
						setDisplayMsg = new SetDebugDisplayMessage(setDisplayMsg.getMessage(), ((SetDisplayMessage)setDisplayMsg).getmImageResID(), mCount);
					}
					
					Message msgToDeliver = Message.obtain(null, setDisplayMsg.getMessageType(), setDisplayMsg);
					sendMessageToClients(msgToDeliver);
					mCount++;
				}
				
				//if no setDisplayMsg send clearDisplayMsg
				else {
					Message msgToDeliver = Message.obtain(null, MessageType.CLEAR_DISPLAY_MSG, null);
					sendMessageToClients(msgToDeliver);
				}
			} catch (Exception e) {
				e.printStackTrace();
				Log.d(TAG, "Exception in main run(): " + e.getMessage());
			}
		}	
	}
	
	/**
	 * The Class ShutdownDelayTask.
	 */
	private class ShutdownDelayTask extends TimerTask {

		/* (non-Javadoc)
		 * @see java.util.TimerTask#run()
		 */
		@Override
		public void run() {
			
			//when power is unplugged shut down after configurable delay
			initiateShutdown(ShutdownType.POWER_DISCONNECT, mConfiguration.getDelayUntilShutdown());
		}	
	}
	
	/**
	 * The Class ShutdownTask.
	 */
	private class ShutdownTask extends TimerTask {

		/* (non-Javadoc)
		 * @see java.util.TimerTask#run()
		 */
		@Override
		public void run() {
			
			//add active message to current messages warning user system is going down
			//shutdownAndroid();
			//put unit to sleep
			goToSleep();
		}	
	}
	

    /**
     * The Class IncomingHandler.
     * This handles messages from activity
     */
    class IncomingHandler extends Handler{
        
        /* (non-Javadoc)
         * @see android.os.Handler#handleMessage(android.os.Message)
         */
        @Override
        public void handleMessage(Message msg){
        	
        	try {
				Message resp = null;
				
				switch(msg.what){
					case MessageType.REGISTER_CLIENT_MSG:
						if(!mClients.contains(msg.replyTo)){
							mClients.add(msg.replyTo);	
							Log.d(TAG, "Processing REGISTER_CLIENT_MSG");
						}
						
						//application needs a response in order to bind to this service
						resp = Message.obtain(null, 0, 0, 0);
						
						break;
						
					case MessageType.UNREGISTER_CLIENT_MSG:
						
						if(mClients.contains(msg.replyTo)){
							mClients.remove(msg.replyTo);
							Log.d(TAG, "Processing UNREGISTER_CLIENT_MSG");
						}
						
						break;
						
					case MessageType.TRAILER_CONFIGURATION_RESP:
						
						Log.d(TAG, "Processing TRAILER_CONFIGURATION_RESP");
						
						trailerConfigurationResponse((Integer) msg.obj);
						
					default:
						super.handleMessage(msg);  
						break;
							
				}
				
				sendMessageToClients(resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Log.d(TAG, "Exception in handleMessage(): " + e.getMessage());
			}
        }
        
        
    }
	
	/** The m service looper. */
	private Looper mServiceLooper;
	
	/** The m service handler. */
	private ServiceHandler mServiceHandler;	

	/** The Constant THREAD_PRIORITY_BACKGROUND. */
	static final int THREAD_PRIORITY_BACKGROUND = 0;

    /** The nm. */
	private NotificationManager mNM;
    
    /** The clients (Android Activities). */
	private ArrayList<Messenger> mClients = new ArrayList<Messenger>();
    
    /** The power manager. */
	private PowerManager mPowerManager;
	
    /** The messenger. */
	private final Messenger mMessenger = new Messenger(new IncomingHandler());

	/** The Constant TAG. */
	private static final String TAG = "RSDDVIService";
	
	/** The server. */
	private TCPServer mServer;
	
	/** The safety app messages. */
	private Map<Long, SafetyAppMessage> mSafetyAppMessages;
	
	/** The configuration. */
	private Configuration mConfiguration;
	
	/** The m ringtone. */
	private Ringtone mRingtone;
	
	/** The m broadcast task. */
	private BroadcastTask mBroadcastTask;
	
	/** The m current safety app message. */
	private SafetyAppMessage mCurrentSafetyAppMessage;
	
	/** The broadcast timer. */
	private Timer mBroadcastTimer;

	/** The broadcast count. */
	int mCount = 0;
	
	/** The m rsd dvi activity intent. */
	private Intent mRsdDviActivityIntent;
	
	/** The m power change receiver. */
	private RsdPowerChangeReceiver mPowerChangeReceiver;
	
	/** The shutdown delay timer. */
	private Timer mShutdownDelayTimer;
	
	/** The shutdown delay task. */
	private ShutdownDelayTask mShutdownDelayTask;
	
	/** The shutdown timer. */
	private Timer mShutdownTimer;
	
	/** The shutdown task. */
	private ShutdownTask mShutdownTask;
	
	/** The m shutting down. */
	private boolean mShuttingDown;
	
	/** The m sleepint. */
	private boolean mSleeping;
	
	/** The m shutdown delay. */
	private int mShutdownDelay;
	
	/** The m shutdown type. */
	private ShutdownType mShutdownType;
	
	/** The m demo disabled. */
	private boolean mDemoDisabled;
	
	/** The m inet address. */
	private InetAddress mInetAddress;
	
	private Date mPreviousActivationTime;
	
	private List<String> mApplicationNames;
    
    /* (non-Javadoc)
     * @see android.app.Service#onCreate()
     */
    @Override
    public void onCreate(){
    	mConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
		try{
			Log.d(TAG, "onCreate()");
			HandlerThread thread = new HandlerThread("DVIServiceThread", THREAD_PRIORITY_BACKGROUND);
			thread.start();
			
			mServiceLooper = thread.getLooper();
			mServiceHandler = new ServiceHandler(mServiceLooper);
			
/*			if(mConfiguration.getUseWiredTether()) {
				mInetAddress = InetAddress.getByName(mConfiguration.getTetheredHostIPNumber());
				Log.d(TAG, "Using Tethered USB Host : " + mInetAddress);	
			}
			
			else {
				mInetAddress = InetAddress.getByName(mConfiguration.getHostIPNumber());
				Log.d(TAG, "Using Host : " + mInetAddress);	
			}*/
			
			mInetAddress = InetAddress.getByName(mConfiguration.getHostIPNumber());
			Log.d(TAG, "Using Host : " + mInetAddress);	
			
			mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
			
			mSafetyAppMessages = new HashMap<Long, SafetyAppMessage>();
			
			Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
			mRingtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
			
			//lock down tablet
	    	sanitizeTablet(mConfiguration.getLockdownTablet());
	    	
	    	//remove program icons from homescreen
	    	//mApplicationNames = Arrays.asList("com.android.browser");
	    	//disableLaunchActivityForApplications(false);
	    	
	    	//setup handling of power changes
	    	mPowerChangeReceiver = new RsdPowerChangeReceiver();
	    	registerReceiver(mPowerChangeReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
			
			//this intent will ensure correct activity is on top when displaying messages
			mRsdDviActivityIntent = new Intent();
	    	mRsdDviActivityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	    	mRsdDviActivityIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    	mRsdDviActivityIntent.setAction("android.intent.action.VIEW");
	    	mRsdDviActivityIntent.setComponent(ComponentName.unflattenFromString("server.android.swri/server.android.swri.RsdDviActivity"));
	    	
	    	
	    	if(mConfiguration.getStartOnBoot()) {
	    		startActivity(mRsdDviActivityIntent);
	    	}

		}catch (UnknownHostException e){
			e.printStackTrace();
			Log.d(TAG, "Exception in onCreate(): " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			Log.d(TAG, "Exception in onCreate(): " + e.getMessage());
		}
    }
    
    /* (non-Javadoc)
     * @see android.app.Service#onStartCommand(android.content.Intent, int, int)
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
    	Log.d(TAG, "onStart()");
    	
    	int toReturn = 0;
		try{	
	
			if (mServer == null) {
				mServer = new TCPServer(mInetAddress, mConfiguration.getPort(),
						this, false, mConfiguration.getReconnectNumAttempts(),
						mConfiguration.getReconnectWaitTime(), mConfiguration.getTimeoutInterval());
				//register with TCPServer to receive SocketChanged events
				mServer.addISocketStateListener(this);
				mServer.StartServer("RSDThread");
			}
			toReturn = super.onStartCommand(intent,flags,startId);
		}catch (Exception e){
			e.printStackTrace();
			Log.d(TAG, "Exception in onStartCommand(): " + e.getMessage());
		}
		
		return toReturn;
    }

	/* (non-Javadoc)
	 * @see android.app.Service#onBind(android.content.Intent)
	 */
	@Override
	public IBinder onBind(Intent arg0){
		
		Log.d(TAG, "Starting timers");
		
		setupBroadcastTimer();
		
		Log.d(TAG, "Returning IBinder");
		
		IBinder toReturn = mMessenger.getBinder();
		
		return toReturn;
	}
	
	
	/* (non-Javadoc)
	 * @see server.android.swri.ISocketMessageListener#handleReceived(server.android.swri.ReceivedMessageFromSocket)
	 */
	public void handleReceived(ReceivedMessageFromSocket event){
		//NOTE: bytes in java are signed so need to mask sign bit for full unsigned range, ie 'data[i] & 0xFF'
		try{
			byte[] data = event.Data();
			StringBuilder sb = new StringBuilder();

			//evaluate bytes [0] and [1]  as control bytes			
			if((data[0] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_A && (data[1] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_B){	
				sb.append("Processing Message: ");
				
				for(int i = 0; i < data.length; i++){
					sb.append(String.format("%02X",  data[i]));
				}
				
				Log.d(TAG, sb.toString());

				String classOnTop = getCurrentClassOnTop();
				
				Log.d(TAG, "Activity currently on top: " + classOnTop);
				
				//evaluate bytes [2] and [3] for message type
				switch((data[2] << 8 & 0xFF) + (data[3] & 0xFF)){
					
					case 1: //SYSTEM_STATUS_MESSAGE		
						
							Log.d(TAG, "Processing SYSTEM_STATUS_MESSAGE");		

					    	systemStatusMessage(data);
						
						break;
						
					case 2: //TRAILER_CONFIGURATION_REQUEST
						
						Log.d(TAG, "Processing TRAILER_CONFIGURATION_REQUEST");					
	
					    	trailerConfigurationRequest(data);
					    	
						break;
						
					case 3: //TRAILER_CONFIGURATION_RESPONSE
						
						//This is generated by user and sent to radio so it is not handled here
						break;
						
					case 4: //ADD_SAFETY_APPLICATION_MSG
						
						Log.d(TAG, "Processing ADD_SAFETY_APPLICATION_MSG");
						
						addSafetyAppMessage(data);
							
						break;
						
					case 5: //ACTIVATE_SAFETY_APPLICATION_MESSAGE
						
						Log.d(TAG, "Processing ACTIVATE_SAFETY_APPLICATION_MESSAGE");
						
						activateSafetyAppMessage(data);
						
						break;
						
					case 6: //DEACTIVATE_SAFETY_APPLICATION_MESSAGE
						
						Log.d(TAG, "Processing DEACTIVATE_SAFETY_APPLICATION_MESSAGE");
						
						deactivateSafetyAppMessage(data);
						
						break;
						
					case 7: //REMOVE_SAFETY_APPLICATION_MESSAGE
						
						Log.d(TAG, "Processing REMOVE_SAFETY_APPLICATION_MESSAGE");
						
						removeSafetyAppMessage(data);
						
						break;
						
					case 8: //UPDATE_SAFETY_APPLICATION_MESSAGE
								
						Log.d(TAG, "Processing UPDATE_SAFETY_APPLICATION_MESSAGE");
						
						updateSafetyAppMessage(data);
						
						break;
						
					case 9: //SAFETY_APPLICATION_CACHE_REQUEST					
						
						//This is generated by service on startup and goes to radio so it is not handled here
						break;
						
					case 10: //SHUTDOWN_MESSSAGE
						
						Log.d(TAG, "Processing SHUTDOWN_MESSSAGE");
						initiateShutdown(ShutdownType.SHUTDOWN_MSG, mConfiguration.getDelayUntilRSDInitiatedShutdown());
						
						break;

						
					default:
						
						Log.d(TAG, "Received unknown message type in handleReceived()");
							
						break;
						
				}

			}
			else{
				Log.d(TAG, "Invalid Message Format: ");
			}
		}catch(Exception e){

			StringBuilder log = new StringBuilder();
			log.append("Exception : ");
			log.append(this.getClass());
			log.append(" : ");
			log.append(e.getMessage());
			Log.e(TAG, log.toString());
		}
			
	}
	
	/* (non-Javadoc)
	 * @see server.android.swri.ISocketStateListener#SocketStateChanged(server.android.swri.SocketStateChangeEvent)
	 */
	public void onSocketStateChanged(SocketStateChangeEvent event) {
		
		int RSDStatus = RSDSystem.Status.Unknown;
    	int VehStatus = RSDSystem.Status.Unknown;
    	int GPSStatus = RSDSystem.Status.Unknown;
    	int DASStatus = RSDSystem.Status.Unknown;
    	int DVIStatus = RSDSystem.Status.Active;
    	int NumRemoteVehicles = 0;
    	int Speed = 0;
    	
		switch(event.SocketState()){
		case Connected:
			
			Log.d(TAG, "Connected");
			RSDStatus = RSDSystem.Status.Active;
			
			//send SafetyApplicationCacheRequest to radio
			byte[] toSend = createSafetyApplicationCacheRequest();
			sendMessageToDsrcRadio(toSend);
			
			break;
			
		case NotConnected:
			Log.d(TAG, "NotConnected");	

			RSDStatus = RSDSystem.Status.Error;
			
			//clear current SafetyApplicationCache
			if(mSafetyAppMessages != null) {
				mSafetyAppMessages.clear();
			}
			

			break;
			
		default:
				
			Log.d(TAG, "default");
			break;
		}
		
/*		String classOnTop = getCurrentClassOnTop();
		
		if(classOnTop.equals("server.android.swri.SetSystemConfigurationActivity") && !classOnTop.equals("server.android.swri.RsdDviDemoActivity")) {
			
			//show RsdDviActivity if not already on top unless we are adjusting system settings or looking at demo
	    	startActivity(mRsdDviActivityIntent);	
		}*/
				
		SetStatusMessage toSend = new SetStatusMessage(RSDStatus, VehStatus, GPSStatus, DASStatus, DVIStatus, NumRemoteVehicles, Speed);
		Message msgToDeliver = Message.obtain(null, MessageType.SET_STATUS_MSG, toSend);
		sendMessageToClients(msgToDeliver);
		
	}
	
	//handle data
    /**
	 * Activate safety app message.
	 *
	 * @param pData the data
	 */
	private void activateSafetyAppMessage(byte[] pData) {
		long thisId = getIdFromSafetyAppMessage(pData);
			
    	if(mSafetyAppMessages.containsKey(thisId) && mSafetyAppMessages.get(thisId) != null){
    		mSafetyAppMessages.get(thisId).setIsActivated(true);	  
    		
    		StringBuilder sb = new StringBuilder();
    		sb.append("ACTIVATING MESSAGE ");
    		sb.append(thisId);
    		Log.d(TAG, sb.toString());
    		
    		String classOnTop = getCurrentClassOnTop();
    		
			//show RsdDviActivity if not already on top
			if(!classOnTop.equals("server.android.swri.RsdDviActivity") && !classOnTop.equals("server.android.swri.SetSystemConfigurationActivity")) {
				
		    	startActivity(mRsdDviActivityIntent);	
			}
	    	
	    	//schedule message duration after which message is deactivated
	    	//scheduleMessage(safetyAppMsg.getId(), 3000);
		}
	}
	
	/**
	 * Adds the safety app message.
	 *
	 * @param pData the data
	 */
	private void addSafetyAppMessage(byte[] pData){
		
		//add message to cache 
    	SafetyAppMessage safetyAppMsg = new SafetyAppMessage(pData);
    	
    	if(!mSafetyAppMessages.containsKey(safetyAppMsg.getId())){
    		mSafetyAppMessages.put(safetyAppMsg.getId(), safetyAppMsg);
    		
    		StringBuilder sb = new StringBuilder();
    		sb.append("ADDING MESSAGE ");
    		sb.append(safetyAppMsg.getId());
    		Log.d(TAG, sb.toString());
    	}
    }
    
    /**
     * Deactivate safety app message.
     *
     * @param pData the data
     */
    private void deactivateSafetyAppMessage(byte[] pData){   	
		long thisId = getIdFromSafetyAppMessage(pData);
		
    	if(mSafetyAppMessages.containsKey(thisId) && mSafetyAppMessages.get(thisId) != null){
    		mSafetyAppMessages.get(thisId).setIsActivated(false);
    		
    		StringBuilder sb = new StringBuilder();
    		sb.append("DEACTIVATING MESSAGE ");
    		sb.append(thisId);
    		Log.d(TAG, sb.toString());
	    		   
		}
    }
    
    /**
     * Removes the safety app message.
     *
     * @param pData the data
     */
    private void removeSafetyAppMessage(byte[] pData){
		long thisId = getIdFromSafetyAppMessage(pData);
		
		if(mSafetyAppMessages.containsKey(thisId)) {
    		mSafetyAppMessages.remove(thisId);
    		
    		StringBuilder sb = new StringBuilder();
    		sb.append("REMOVING MESSAGE ");
    		sb.append(thisId);
    		Log.d(TAG, sb.toString());
		}
    }
    
	/**
	 * Creates the safety application cache request.
	 *
	 * @return the byte[]
	 */
	private byte[] createSafetyApplicationCacheRequest() {
		byte[] toReturn = new byte[RsdDviConstants.Header.HEADER_LENGTH];
		
		//Header
		toReturn[0] = (byte) RsdDviConstants.Header.SYNC_FRAME_A;
		toReturn[1] = RsdDviConstants.Header.SYNC_FRAME_B;
		toReturn[2] = 0x00;
		toReturn[3] = RsdDviConstants.MessageType.SAFETY_APP_CACHE_REQ;
		toReturn[4] = 0x00;
		
		//Message Length
		toReturn[5] = (byte) (RsdDviConstants.Header.HEADER_LENGTH);

		return toReturn;
	}
    
    /**
     * System status message.
     *
     * @param pData the data
     */
    private void systemStatusMessage(byte[] pData){
		
    	int RSDStatus = RSDSystem.Status.Unknown;
    	int VehStatus = RSDSystem.Status.Unknown;
    	int GPSStatus = RSDSystem.Status.Unknown;
    	int DASStatus = RSDSystem.Status.Unknown;
    	int DVIStatus = RSDSystem.Status.Active;
    	int NumRemoteVehicles = 0;
    	int Speed = 0;
    	
    	
		int numSystems = pData[Header.HEADER_LENGTH];
		for(int i = RsdDviConstants.Header.HEADER_LENGTH + 1; i < Header.HEADER_LENGTH  + 1 + (numSystems * 2); i+=2) {
			switch(pData[i]){
				case RSDSystem.Component.RSDCore:
					RSDStatus = pData[i+1];
					break;
				
				case RSDSystem.Component.VehicleConnection:
					VehStatus = pData[i+1];
					break;
					
				case RSDSystem.Component.GPS:
					GPSStatus = pData[i+1];
					break;
					
				case RSDSystem.Component.DAS:
					DASStatus = pData[i+1];
					break;
					
				case RSDSystem.Component.DVI:
					DVIStatus = pData[i+1];
					break;
					
			}
		}
		
		
		
		//NOTE: bytes in java are signed so need to mask sign bit for full unsigned range, ie 'data[i] & 0xFF'
		NumRemoteVehicles = pData[Header.HEADER_LENGTH  + 1 + (numSystems * 2)] & 0xFF;

		//NOTE: bytes in java are signed so need to mask sign bit for full unsigned range, ie 'data[i] & 0xFF'
		//Speed = pData[Header.HEADER_LENGTH  + 2 + (numSystems * 2)] & 0xFF;
		
		Speed =  ((pData[Header.HEADER_LENGTH  + 2 + (numSystems * 2)] & 0xFF) * 0xFF00 + (pData[Header.HEADER_LENGTH  + 3 + (numSystems * 2)] & 0xFF)) ;
		
    	
		//cover demo mode if moving
    	String classOnTop = getCurrentClassOnTop();
		if (classOnTop.equals("server.android.swri.RsdDviDemoActivity")) {
			if(Speed > 5) {
				startActivity(mRsdDviActivityIntent);	
			}
		}	
		
		SetStatusMessage toSend = new SetStatusMessage(RSDStatus, VehStatus, GPSStatus, DASStatus, DVIStatus, NumRemoteVehicles, Speed);
		Message msgToDeliver = Message.obtain(null, MessageType.SET_STATUS_MSG, toSend);
		sendMessageToClients(msgToDeliver);
    }
    
    /**
     * Trailer configuration request.
     * This comes from the radio to prompt user for input
     * @param pData the data
     */
    private void trailerConfigurationRequest(byte[] pData) {
    	
    	try {
			int[] dataValues = new int[6];
			
			dataValues[0] = (int) pData[TrailerConfigData.DATA_1_BYTE_INDEX];
			dataValues[1] = (int) pData[TrailerConfigData.DATA_2_BYTE_INDEX];
			dataValues[2] = (int) pData[TrailerConfigData.DATA_3_BYTE_INDEX];
			dataValues[3] = (int) pData[TrailerConfigData.DATA_4_BYTE_INDEX];
			dataValues[4] = (int) pData[TrailerConfigData.DATA_5_BYTE_INDEX];
			dataValues[5] = (int) pData[TrailerConfigData.DATA_6_BYTE_INDEX];

			
			String classOnTop = getCurrentClassOnTop();
			
			//start SetTrailerConfigurationActivity if not already on top
			if(!classOnTop.equals("server.android.swri.SetTrailerConfigurationActivity") && !classOnTop.equals("server.android.swri.SetSystemConfigurationActivity")) {
				//note we are actually starting RsdDviActivity first 
				//and it starts SetTrailerConfigurationActivity via startActivityForResult()
				startActivity(mRsdDviActivityIntent);	
				
				Message msgToDeliver = Message.obtain(null, MessageType.TRAILER_CONFIGURATION_REQ, dataValues);
				sendMessageToClients(msgToDeliver);
			}
		} catch (Exception e) {
			e.printStackTrace();
			
			StringBuilder log = new StringBuilder();
			log.append("Exception : ");
			log.append(this.getClass());
			log.append(" : ");
			log.append(e.getMessage());
			Log.e(TAG, log.toString());
		}
    }
    
    /**
     * Trailer configuration response.
     * This comes back from DVI with user input and is sent to radio
     * @param pValue the value
     */
    private void trailerConfigurationResponse(int pValue) {
    	
    	try {
			byte[] messageToSend = createTrailerConfigResponse(pValue);
			
			sendMessageToDsrcRadio(messageToSend);
		} catch (Exception e) {
			
			e.printStackTrace();
			StringBuilder log = new StringBuilder();
			log.append("Exception : ");
			log.append(this.getClass());
			log.append(" : ");
			log.append(e.getMessage());
			Log.e(TAG, log.toString());
		}
    }
    
	/**
	 * Creates the trailer config response.
	 *
	 * @param pValue the value
	 * @return the byte[]
	 */
	private byte[] createTrailerConfigResponse(int pValue) {
		byte[] toReturn = new byte[RsdDviConstants.Header.HEADER_LENGTH + 1];
		
		//Header
		toReturn[0] = (byte) RsdDviConstants.Header.SYNC_FRAME_A;
		toReturn[1] = RsdDviConstants.Header.SYNC_FRAME_B;
		toReturn[2] = 0x00;
		toReturn[3] = RsdDviConstants.MessageType.TRAILER_CONFIGURATION_RESP;
		toReturn[4] = 0x00;
		
		//Message Length
		toReturn[5] = (byte) (RsdDviConstants.Header.HEADER_LENGTH + 1);
		
		//Value
		toReturn[6] = (byte) pValue;

		return toReturn;
	}
   
    
    /**
     * Update safety app message.
     *
     * @param pData the data
     */
    private void updateSafetyAppMessage(byte[] pData){
    	
		//replace old message with new one
    	SafetyAppMessage safetyAppMsg = new SafetyAppMessage(pData);
    	
    	if(mSafetyAppMessages.containsKey(safetyAppMsg.getId())){
    		mSafetyAppMessages.put(safetyAppMsg.getId(), safetyAppMsg);
    	}
    }
    
	/**
	 * Gets the id from activate safety app message.
	 *
	 * @param pData the data
	 * @return the id text from activate safety app message
	 */
	private long getIdFromSafetyAppMessage(byte[] pData){
		
		
		long toReturn = 0;
		
		//evaluate bytes [0] and [1]  as control bytes
		if((pData[0] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_A && (pData[1] & 0xFF) == RsdDviConstants.Header.SYNC_FRAME_B){			
			
			//id
			try {
				byte[] idBytes = new byte[8];
				System.arraycopy(pData, RsdDviConstants.Header.HEADER_LENGTH, idBytes, 0, 8);

				ByteArrayInputStream bis = new ByteArrayInputStream(idBytes, 0, 8);
				DataInputStream dis = new DataInputStream(bis);
				toReturn = dis.readLong();
			} catch (IOException e) {
				e.printStackTrace();
				Log.d(TAG, "Exception in geIdSafetyAppMessage(): " + e.getMessage());
			}

		}
			
		else{
			Log.d(TAG, "Invalid Data Format");
		}
		return toReturn;
    }
    
    /**
     * Creates the set display message.
     *
     * @param pSafetyAppMessage the safety app message
     * @return the sets the display message
     */
    private SetDisplayMessage createSetDisplayMessage(SafetyAppMessage pSafetyAppMessage){
    	SetDisplayMessage toReturn = null;
    	
    	Configuration currentConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
    	
    	//default icon
    	int icon = R.drawable.travel_advisory;
    	
    	switch(pSafetyAppMessage.getCategory()){
    	
    		case 0:	
    			
    			icon = currentConfiguration.getCAT_0();
    			break;
    			
    		case 1:
    			
    			icon = currentConfiguration.getCAT_1();
    			break;
    			
    		case 2:
    			
    			icon = currentConfiguration.getCAT_2();
    			break;
    			
    		case 3:
    			
    			icon = currentConfiguration.getCAT_3();
    			break;
    			
    		case 4:
    			
    			icon = currentConfiguration.getCAT_4();
    			break;
    			
    		case 5:
    			
    			icon = currentConfiguration.getCAT_5();
    			break;
    			
    		case 6:
    			
    			icon = currentConfiguration.getCAT_6();
    			break;
    			
    		case 7:
    			
    			icon = currentConfiguration.getCAT_7();
    			break;
    			
			default:
    				
    			icon = R.drawable.travel_advisory;
    	}
    	
    	toReturn = new SetDisplayMessage(pSafetyAppMessage.getTitle(), icon);
    	
		return toReturn;
    }
    
    /**
     * Creates the play audio message.
     *
     * @param pSafetyAppMessage the safety app message
     * @return the i audio message
     */
    private IAudioMessage createPlayAudioMessage(SafetyAppMessage pSafetyAppMessage){
    	IAudioMessage toReturn = null;
    	AssetFileDescriptor assetFileDescriptor = null;
    	
    	Configuration currentConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
    	
    	
		try{
	    	switch(pSafetyAppMessage.getAdvisoryType()){
	    		case J2735_TRAVELER_ADVISORY:
	    		
	    			if(currentConfiguration.getSND_J2735_TRAVELER_ADVISORY().equals(RsdDviConstants.RINGTONE_STRING)) {
	    				toReturn = new PlayAudioAlertMessage("J2735_TRAVELER_ADVISORY_ALERT", mRingtone);
	    			}
	    			else {
	    				assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_J2735_TRAVELER_ADVISORY());
						toReturn = new PlayAudioAssetMessage("J2735_TRAVELER_ADVISORY_ALERT", assetFileDescriptor);
	    			}
	    			
	    			break;
	    			
	    		case CURVE_SPEED_WARNING:
	    			
	    			if(currentConfiguration.getSND_CURVE_SPEED_WARNING_ALERT().equals(RsdDviConstants.RINGTONE_STRING)) {
	    				toReturn = new PlayAudioAlertMessage("CURVE_SPEED_WARNING_ALERT", mRingtone);
	    			}
	    			else {
	    				assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_CURVE_SPEED_WARNING_ALERT());
						toReturn = new PlayAudioAssetMessage("CURVE_SPEED_WARNING_ALERT", assetFileDescriptor);
	    			}
	
	    			break;
	    			
	    		case EMERGENCY_ELECTRONIC_BRAKE_LIGHTS:
	    			
	    			if(currentConfiguration.getSND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS().equals(RsdDviConstants.RINGTONE_STRING)) {
	    				toReturn = new PlayAudioAlertMessage("EMERGENCY_ELECTRONIC_BRAKE_LIGHTS_ALERT", mRingtone);
	    			}
	    			else {
	    				assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_EMERGENCY_ELECTRONIC_BRAKE_LIGHTS());
						toReturn = new PlayAudioAssetMessage("EMERGENCY_ELECTRONIC_BRAKE_LIGHTS_ALERT", assetFileDescriptor);
	    			}
	
	    			break;
	    			
	    		case FORWARD_COLLISION_WARNING:
	    			
	    			if(currentConfiguration.getSND_FORWARD_COLLISION_WARNING().equals(RsdDviConstants.RINGTONE_STRING)) {
	    				toReturn = new PlayAudioAlertMessage("FORWARD_COLLISION_WARNING_ALERT", mRingtone);
	    			}
	    			else {
	    				assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_FORWARD_COLLISION_WARNING());
						toReturn = new PlayAudioAssetMessage("FORWARD_COLLISION_WARNING_ALERT", assetFileDescriptor);
	    			}
	
	    			break;
	    			
	    		case WRONG_WAY_DRIVER:
	    			
	    			if(currentConfiguration.getSND_WRONG_WAY_DRIVER().equals(RsdDviConstants.RINGTONE_STRING)) {
	    				toReturn = new PlayAudioAlertMessage("WRONG_WAY_DRIVER_WARNING_ALERT", mRingtone);
	    			}
	    			else {
	    				assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_WRONG_WAY_DRIVER());
						toReturn = new PlayAudioAssetMessage("WRONG_WAY_DRIVER_WARNING_ALERT", assetFileDescriptor);
	    			}
	
	    			break;
	    			
				default:
					
	    			if(currentConfiguration.getSND_DEFAULT().equals(RsdDviConstants.RINGTONE_STRING)) {
	    				toReturn = new PlayAudioAlertMessage("ALERT", mRingtone);
	    			}
	    			else {
	    				assetFileDescriptor = getAssets().openFd(mConfiguration.getSND_DEFAULT());
						toReturn = new PlayAudioAssetMessage("ALERT", assetFileDescriptor);
	    			}
					
					break;
	    	}
		} catch (IOException e){
			e.printStackTrace();
			Log.d(TAG, "Exception in createPlayAudioMessage(): " + e.getMessage());
		}
    	
		return toReturn;
    }
    
	
    //helper methods
    
    /**
     * Gets the current class on top.
     *
     * @return the current class on top
     */
    private String getCurrentClassOnTop() {
    	
		ActivityManager am = (ActivityManager) this.
			    getSystemService(Activity.ACTIVITY_SERVICE);
		String packageName = am.getRunningTasks(1).get(0).topActivity.getPackageName();
		String className = am.getRunningTasks(1).get(0).topActivity.getClassName();
		
		return className;
    }
    
	
	/**
	 * Gets the highest priority active message.
	 *
	 * @return the highest priority active message
	 */
	private SafetyAppMessage getHighestPriorityActiveMessage() {
		SafetyAppMessage toReturn = null;
		
		Iterator<SafetyAppMessage> iterator = mSafetyAppMessages.values().iterator();
		while(iterator.hasNext()) {
			SafetyAppMessage thisMessage = iterator.next();
			if(thisMessage.getIsActivated()) {
				//set return to first active message if not yet set
				if(toReturn == null) {
					toReturn = thisMessage;
				}
				
				//if priority of this message is higher assign it as return message
				else if(thisMessage.getPriority() > toReturn.getPriority()) {
					toReturn = thisMessage;
				}
				
				//if priority of this message is equal assign it if newer
				else if(thisMessage.getPriority() == toReturn.getPriority()) {
					if(thisMessage.getTimeActivated().compareTo(toReturn.getTimeActivated()) > 0) {
						toReturn = thisMessage;
					}
				}
			}
		}	
		return toReturn;
	}
	
	/**
	 * Sanitize tablet.
	 *
	 * @param pLockdownTablet the lockdown tablet
	 */
	private void sanitizeTablet(boolean pLockdownTablet) {
		ApplicationInfo thisInfo;
		PackageManager pm = this.getPackageManager();
		List<ApplicationInfo> installedApps = pm.getInstalledApplications(0);
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < installedApps.size(); i++)
		{
			try {
				thisInfo = installedApps.get(i);
				if(thisInfo.packageName != null) {
					sb.append(thisInfo.packageName);
					sb.append("\r\n");
					
					if (pLockdownTablet) {

						if (thisInfo.packageName.equals("com.android.systemui")) {
							pm.setApplicationEnabledSetting(
									thisInfo.packageName,
									pm.COMPONENT_ENABLED_STATE_DISABLED, 0);
							Log.d(TAG, "Disabled com.android.systemui");
						}
					}
					else {

						if (thisInfo.packageName.equals("com.android.systemui")) {
							pm.setApplicationEnabledSetting(
									thisInfo.packageName,
									pm.COMPONENT_ENABLED_STATE_ENABLED, 0);
							Log.d(TAG, "Enabled com.android.systemui");
						}	
					}
				}

			} catch (Exception e) {
				Log.d(TAG, "Exception sanitizing tablet: ");
			}
		}
	}
	
	private void disableLaunchActivityForApplications(boolean pRemove) {
	
		ApplicationInfo thisInfo;
		PackageManager pm = this.getPackageManager();
		List<ApplicationInfo> installedApps = pm.getInstalledApplications(0);
		StringBuilder sb = new StringBuilder();
		
		for(int i = 0; i < installedApps.size(); i++)
		{
			ComponentName name = null;
			
			try {
					thisInfo = installedApps.get(i);
								
					if(mApplicationNames.size() > 0 && thisInfo.packageName != null) {
						
						if(mApplicationNames.contains(thisInfo.packageName)) {
							
							Intent launchIntent = pm.getLaunchIntentForPackage(thisInfo.packageName);
							
							if(launchIntent != null) {
								
								name = launchIntent.getComponent();			
							}
							//browser has an activity that is not a LaunchActivity
							else {
								name = new ComponentName(thisInfo.packageName, thisInfo.className);
							}
							
							if (name != null) {
								if (pRemove) {
									pm.setComponentEnabledSetting(name,
											pm.COMPONENT_ENABLED_STATE_DISABLED,
											PackageManager.DONT_KILL_APP);
								} else {
									pm.setComponentEnabledSetting(name,
											pm.COMPONENT_ENABLED_STATE_ENABLED,
											PackageManager.DONT_KILL_APP);
								}
							}
						}
				}

			} catch (Exception e) {
				Log.d(TAG, "Exception sanitizing tablet: " + e.getMessage());
			}
		}
		
	}
	
	
	
	/**
	 * Send message to clients.
	 *
	 * @param pResp the resp
	 */
	private void  sendMessageToClients(Message pResp){
    	for(int i = 0; i < mClients.size(); i++){
    		try{
    			if(pResp != null)
    			{
    				Messenger client = mClients.get(i);
    				if(client != null)
    				{
        				mClients.get(i).send(pResp);
    				}
    			}
				
			}catch (RemoteException e){
				e.printStackTrace();
				Log.d(TAG, "Exception in sendMessageToClients: " + e.getMessage());
			}
    	}
	}
	
	/**
	 * Send message to dsrc radio.
	 *
	 * @param pData the data
	 */
	private void sendMessageToDsrcRadio(byte[] pData) {
		mServer.Send(pData);
	}
	
	/**
	 * Configure timers and start broadcasting.
	 */
	private void setupBroadcastTimer() {
		
		try {
			//instantiate timers if needed:
			//this timer fires to periodically send message
			if (mBroadcastTimer == null) {
				mBroadcastTimer = new Timer("mBroadcastTimer");
			}
				
			if(mBroadcastTask == null)
			{
				mBroadcastTask = new BroadcastTask();
			}
			
			//set task (at beginning message will be null and be ignored in BroadcastTask)
			mBroadcastTimer.schedule(mBroadcastTask, 0,
					mConfiguration.getMessageRefreshRateInMilliseconds());
			
		} catch (Exception e) {
			Log.d(TAG, "Exception initializing Broadcast Timer: " + e.getMessage());
		}
	}

		
    /**
     * Shutdown android.
     */
    private void shutdownAndroid() {
    	try{
    		//stop connection to radio
    		mServer.Stop();
    		
	    	Process process = Runtime.getRuntime().exec("su");
	    	DataOutputStream out = new DataOutputStream(
	    	process.getOutputStream());
	    	out.writeBytes("reboot -p\n");
	    	out.flush();
    	}catch (IOException e){
    		Log.d(TAG, "Exception in shutdownAndroid(): " + e.getMessage());
    	}
    }
}
