/*
 * 
 */
package server.android.swri;

import server.android.swri.RsdDviConstants.TrailerConfigData;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;

// TODO: Auto-generated Javadoc
/**
 * The Class SetTrailerConfigurationActivity.
 */
public class SetTrailerConfigurationActivity extends Activity implements OnClickListener {

	/** The TAG. */
	private final String TAG = "SetTrailerConfigurationActivity";
	
	/** The m configuration. */
	Configuration mConfiguration;

    /**
     * Called when the activity is first created.
     *
     * @param savedInstanceState the saved instance state
     */
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        mConfiguration = Configuration.getInstance(this.getApplicationContext(), RsdDviConstants.SHARED_PREF_FILE);
        
        //get data sent for this configuration screen
        Bundle data = this.getIntent().getExtras();
        int data1 =  data.getInt(TrailerConfigData.DATA_1);
        int data2 =  data.getInt(TrailerConfigData.DATA_2);
        int data3 =  data.getInt(TrailerConfigData.DATA_3);
        int data4 =  data.getInt(TrailerConfigData.DATA_4);
        int data5 =  data.getInt(TrailerConfigData.DATA_5);
        int defaultlLength =  data.getInt(TrailerConfigData.DATA_6);

        
        setContentView(R.layout.set_trailer_configuration);
        
        //create ColorFilter to color default button
        ColorFilter cf = new PorterDuffColorFilter(Color.GREEN, Mode.MULTIPLY);
        
        Button btn1 = (Button)findViewById(R.id.imageButton1);
        btn1.setText(Integer.toString(data1) + "'");
        btn1.setId(data1);
        btn1.setOnClickListener(this);
        if(defaultlLength == data1)
        {  	
        	btn1.getBackground().setColorFilter(cf);
        }
        
        Button btn2 = (Button)findViewById(R.id.imageButton2);
        btn2.setText(Integer.toString(data2) + "'");
        btn2.setId(data2);
        btn2.setOnClickListener(this);
        if(defaultlLength == data2)
        {
        	btn2.getBackground().setColorFilter(cf);
        }
        
        Button btn3 = (Button)findViewById(R.id.imageButton3);
        btn3.setText(Integer.toString(data3) + "'");
        btn3.setId(data3);
        btn3.setOnClickListener(this);
        if(defaultlLength == data3)
        {
        	btn3.getBackground().setColorFilter(cf);
        }
        
        Button btn4 = (Button)findViewById(R.id.imageButton4);
        btn4.setText(Integer.toString(data4) + "'");
        btn4.setId(data4);
        btn4.setOnClickListener(this);
        if(defaultlLength == data4)
        {
        	btn4.getBackground().setColorFilter(cf);
        }
        
        Button btn5 = (Button)findViewById(R.id.imageButton5);
        
        //set tandem button if needed
        if(data5 == 56)
        {			
        	btn5.setBackgroundDrawable(getResources().getDrawable(R.drawable.z_truck_double));
        	btn5.setGravity(Gravity.TOP);
        	btn5.setText(" 28'\n\n 28'");
        }
        else
        {
        	btn5.setText(Integer.toString(data5) + "'");
        }
        
        
        btn5.setId(data5);
        btn5.setOnClickListener(this);
        if(defaultlLength == data5)
        {
        	btn5.getBackground().setColorFilter(cf);
        }
       
/*        // Return Intent extra
        TrailerConfigurationData returnData = new TrailerConfigurationData(0, 0, 0, 0);*/
        
        // Set result CANCELED in case the user backs out
        setResult(Activity.RESULT_CANCELED);
    }
    
    /**
     * Send configuration.
     */
    private void setReturnValue(int pValue) {
        
        Intent intent = new Intent();
        intent.putExtra(RsdDviConstants.TrailerConfigData.TRAILER_LENGTH, pValue);

        // Set result
        setResult(Activity.RESULT_OK, intent);
    }

	/* (non-Javadoc)
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	public void onClick(View pView) {
		
		setReturnValue(pView.getId());
        finish();
	}
	
    /* (non-Javadoc)
    * @see android.app.Activity#onAttachedToWindow()
    * enables capture of back and home KeyEvents
    */
   @Override
    public void onAttachedToWindow()
    {  
		this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
 
		super.onAttachedToWindow();
    }
    
   /* (non-Javadoc)
    * @see android.app.Activity#dispatchKeyEvent(android.view.KeyEvent)
    */
   @Override
   public boolean dispatchKeyEvent(KeyEvent event) {
   	
   	boolean toReturn;
   	
   	//if configured to be locked down back and home events will be captured by dispatchKeyEvent
       if (mConfiguration.getLockdownTablet()) {
       	toReturn = true;
		}
       else {
       	toReturn = false;
       }
       return toReturn;
   }
}
