/*
 * 
 */
package server.android.swri;

import server.android.swri.RsdDviConstants.MessageType;

/**
 * The Class SetDisplayMessage.
 */
public class SetDebugDisplayMessage extends SetDisplayMessage{
	
	private int mCount;
	
	/**
	 * Instantiates a new sets the display message.
	 *
	 * @param pMessage the message
	 * @param pImageResId the image res id
	 */
	public SetDebugDisplayMessage(String pMessage, int pImageResId, int pCount){
		super( pMessage, pImageResId, MessageType.SET_DEBUG_DISPLAY_MSG);
		mCount = pCount;
	}

	public int getCount() {
		return mCount;
	}
}