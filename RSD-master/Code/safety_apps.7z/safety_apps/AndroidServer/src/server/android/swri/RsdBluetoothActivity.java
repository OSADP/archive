/*
 * 
 */
package server.android.swri;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.os.Parcelable;
import android.util.Log;
import android.widget.ArrayAdapter;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.UUID;

// TODO: Auto-generated Javadoc
/**
 * The Class RsdBluetoothActivity.
 */
public class RsdBluetoothActivity extends Activity {
	
    /**
     * This thread runs while attempting to make an outgoing connection
     * with a device. It runs straight through; the connection either
     * succeeds or fails.
     */
/*    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private  final BluetoothDevice mmDevice;
        private String mSocketType;
        
        private final UUID MY_UUID_SECURE = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

        public ConnectThread(BluetoothDevice device, boolean secure) {
     
            BluetoothSocket tmp = null;

            // Get a BluetoothSocket for a connection with the
            // given BluetoothDevice
            try {
    
            	tmp = device.createRfcommSocketToServiceRecord(MY_UUID_SECURE);
            }
            catch (IOException e) {
                Log.e(TAG, "Socket Type: " + mSocketType + "create() failed", e);
            }
            mmSocket = tmp;
        }

        public void run() {
            Log.i(TAG, "BEGIN mConnectThread SocketType:" + mSocketType);
            setName("ConnectThread" + mSocketType);

            // Always cancel discovery because it will slow down a connection
            mAdapter.cancelDiscovery();

            // Make a connection to the BluetoothSocket
            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
                mmSocket.connect();
            } catch (IOException e) {
                // Close the socket
                try {
                    mmSocket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "unable to close() " + mSocketType +
                            " socket during connection failure", e2);
                }
                connectionFailed();
                return;
            }

            // Reset the ConnectThread because we're done
            synchronized (RsdBluetoothActivity.this) {
                mConnectThread = null;
            }

            // Start the connected thread
            connected(mmSocket, mmDevice, mSocketType);
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect " + mSocketType + " socket failed", e);
            }
        }
    }*/
	
    // Debugging
    private static final String TAG = "RsdBluetoothActivity";
    
    // Return Intent extra
    /** The EXTR a_ devic e_ address. */
    public static String EXTRA_DEVICE_ADDRESS = "device_address";
    
    // Member fields
    /** The m bt adapter. */
    private BluetoothAdapter mBtAdapter;
    
    /** The m paired devices array adapter. */
    private ArrayAdapter<String> mPairedDevicesArrayAdapter;
    
    /** The m new devices array adapter. */
    private ArrayAdapter<String> mNewDevicesArrayAdapter;
    
    /** The m dsrc bluetooth device. */
    private BluetoothDevice mDsrcBluetoothDevice;
    /*private ConnectThread mConnectThread;*/

    
    /* (non-Javadoc)
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Register for broadcasts when a device is discovered
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.registerReceiver(mReceiver, filter);

        // Register for broadcasts when discovery has finished
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.registerReceiver(mReceiver, filter);
        
        //Register for uuid broadcast
        String action = "android.bleutooth.device.action.UUID";
        IntentFilter uuidFilter = new IntentFilter(action);
        registerReceiver(uuidReciever, uuidFilter);

        // Get the local Bluetooth adapter
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();
        
        // Get a set of currently paired devices
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
        

        doDiscovery();
        }
        
        
        /**
         * Start device discover with the BluetoothAdapter.
         */
        private void doDiscovery() {
        	Log.d(TAG, "Doing Discovery");

            // Indicate scanning in the title
            setProgressBarIndeterminateVisibility(true);
            setTitle("Scanning");//R.string.scanning);
            // Turn on sub-title for new devices
            //findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);

            // If we're already discovering, stop it
            if (mBtAdapter.isDiscovering()) {
                mBtAdapter.cancelDiscovery();
            }

            // Request discover from BluetoothAdapter
            mBtAdapter.startDiscovery();
        }
        
        /**
         * Connect.
         */
        private void connect() {
        	
        	if(mDsrcBluetoothDevice != null)
        	{
        		
        		UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

        		try {
					BluetoothSocket socket = mDsrcBluetoothDevice.createRfcommSocketToServiceRecord(uuid);
					socket.connect();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        		
        	}
        }
        
        // The BroadcastReceiver that listens for discovered devices and
        // changes the title when discovery is finished
        /** The m receiver. */
        private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        	
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();

                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    // If it's already paired, skip it, because it's been listed already
                    if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                        mNewDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                    }
                    if(device.getName().contains("Blue"))
                    {
/*                    	mBtAdapter.cancelDiscovery();*/
                    	
                    	mDsrcBluetoothDevice = device;
/*                    	ArrayList<UUID> uuids = new ArrayList<UUID>();
                    	uuids.add(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"));
                    	uuids.add(UUID.fromString("00000000-0000-0000-0000-0000003E0100"));
                    	uuids.add(UUID.fromString("00000001-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00000003-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00000008-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("0000000C-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00000100-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("0000000F-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001000-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001001-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001002-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001005-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001006-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001115-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001116-0000-1000-8000-00805F9B34FB"));
                    	uuids.add(UUID.fromString("00001117-0000-1000-8000-00805F9B34FB"));

     
                    	for(int i = 0; i < uuids.size(); i++)
                    	{
                        	//try to connect so we will capture the Uuids later in uuidReciever
                        	try {
    							BluetoothSocket socket = mDsrcBluetoothDevice.createRfcommSocketToServiceRecord(uuids.get(i));
    							socket.connect();
    						} catch (IOException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    						}               	
                    	}*/
                    }    
                }
                // When discovery is finished, change the Activity title
                else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                    setProgressBarIndeterminateVisibility(false);
                    setTitle("Finished");
                    if (mNewDevicesArrayAdapter.getCount() == 0) {
                        String noDevices = "None";
                        mNewDevicesArrayAdapter.add(noDevices);
                    }
                    
                    //connect to this device
                    if(mDsrcBluetoothDevice != null)
                    {
                    	connect();
                    }
                }
            }
        };
        
        // The BroadcastReceiver that listens for discovered devices and
        // changes the title when discovery is finished
        /** The uuid reciever. */
        private final BroadcastReceiver uuidReciever = new BroadcastReceiver() {
        	
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                action.charAt(0);
                if(action == "android.bleutooth.device.action.UUID")
                {   
                    BluetoothDevice deviceExtra = intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");  
                    Bundle testBundle = intent.getExtras();
                  
                    Class cl = null;
                    Class[] par = {};
                    ParcelUuid[] retval = null;
                    		
					try {
						cl = Class.forName("android.bluetooth.BluetoothDevice");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

                    Method method = null;
					try {
						method = cl.getMethod("getUuids", par);
					} catch (SecurityException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (NoSuchMethodException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                    Object[] args = {};
                    try {
						retval = (ParcelUuid[])method.invoke(mDsrcBluetoothDevice, args);
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    Object test;
                    Parcelable[] uuidExtra = intent.getParcelableArrayExtra("android.bluetooth.device.extra.UUID");
                    if(uuidExtra != null)
                    {
                        for(int i = 0; i < uuidExtra.length; i++)
                        {
                        	test = uuidExtra[i];
                        }
                    }
                }
            }
        };   
}
