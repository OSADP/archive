package server.android.swri;

import server.android.swri.RsdDviConstants.MessageType;
import server.android.swri.RsdDviConstants.RSDSystem;

public class SetStatusMessage extends ActivityMessage {

	private int mRSDCore;
	
	private int mVehicleConnection;
	
	private int mGPS;
	
	private int mDAS;
	
	private int mDVI;
	
	private int mNumRemoteVehicles;
	
	private int mSpeed;
	
	public SetStatusMessage(int pRSD, int pVEH, int pGPS, int pDAS, int pDVI, int pNumRemoteVehicles, int pSpeed) {
		super(MessageType.SET_STATUS_MSG);
		
		mRSDCore = pRSD;
		mVehicleConnection = pVEH;
		mGPS = pGPS;
		mDAS = pDAS;
		mDVI = pDVI;
		mNumRemoteVehicles = pNumRemoteVehicles;
		mSpeed = pSpeed;
	}

	public int getRSDCore() {
		return mRSDCore;
	}

	public int getVehicleConnection() {
		return mVehicleConnection;
	}

	public int getGPS() {
		return mGPS;
	}

	public int getDAS() {
		return mDAS;
	}

	public int getDVI() {
		return mDVI;
	}
	
	public int getNumRemoteVehicles() {
		return mNumRemoteVehicles;
	}
	
	public int getSpeed() {
		return mSpeed;
	}
}
