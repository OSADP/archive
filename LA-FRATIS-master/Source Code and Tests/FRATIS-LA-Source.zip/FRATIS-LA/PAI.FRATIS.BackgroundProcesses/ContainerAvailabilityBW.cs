﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;

using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.YusenTerminalService;

namespace PAI.FRATIS.BackgroundProcesses
{
    /// <summary>
    /// Checks container availability 
    /// </summary>
    internal class ContainerAvailabilityBW
    {
        #region Constants

        private const int TerminalLocationId = 1270;

        private const int TimerDelayInSeconds = 3600; // 1 hour

        #endregion

        #region Static Fields

        private static BackgroundWorker _backgroundWorker;

        #endregion

        #region Fields

        private readonly IJobService _jobService;

        private readonly IRouteStopService _routeStopService;

        private readonly IYusenService _yusenService;

        private Timer _timer;

        #endregion

        #region Constructors and Destructors

        public ContainerAvailabilityBW(
            IYusenService yusenService, IJobService jobService, IRouteStopService routeStopService)
        {
            this._yusenService = yusenService;
            this._jobService = jobService;
            this._routeStopService = routeStopService;

            this.InitializeBackgroundWorker();
            this.InitializeTimer();
        }

        #endregion

        #region Public Methods and Operators

        public static void TimerTick(Object stateInfo)
        {
            if (!_backgroundWorker.IsBusy)
            {
                _backgroundWorker.RunWorkerAsync();
            }
        }

        #endregion

        #region Methods

        private void BackgroundWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            var locationIds = new List<int?> { TerminalLocationId };

            var notReadyTerminalJobs =
                this._routeStopService.GetJobsWithLocationQueryable(locationIds).Where(
                    p =>
                    !p.IsDeleted && p.CreatedDate.HasValue && p.CreatedDate.Value > new DateTime(2014, 5, 1)
                    && p.JobStatus == JobStatus.Unassigned && (p.IsReady.HasValue == false || p.IsReady.Value == false)
                    && p.AssignedDriverId == null);

            var nowReadyJobs = new List<Job>();
            foreach (Job job in notReadyTerminalJobs)
            {
                bool isAvailable = false;
                if (!string.IsNullOrEmpty(job.ContainerNumber))
                {
                    ContainerAvailabilityResponse response =
                        this._yusenService.GetContainerAvailability(job.ContainerNumber);
                    if (response.IsAvailable)
                    {
                        Console.WriteLine("Found a ready container: {0}", job.ContainerNumber);
                        isAvailable = true;
                    }
                }
                else if (!string.IsNullOrEmpty(job.BillOfLading))
                {
                    ContainerAvailabilityResponse response =
                        this._yusenService.GetContainerAvailabilityByBillOfLading(job.BillOfLading);
                    if (response.IsAvailable)
                    {
                        Console.WriteLine("Found a ready bill of lading: {0}", job.BillOfLading);
                        isAvailable = true;
                    }
                }

                if (isAvailable)
                {
                    nowReadyJobs.Add(job);
                }
            }

            // perform action on jobs that are now ready
            if (nowReadyJobs.Any())
            {
                Console.WriteLine("{0} jobs are now ready...", nowReadyJobs.Count);
                foreach (Job job in nowReadyJobs)
                {
                    job.IsReady = true;
                    this._jobService.Update(job, false);
                    Console.WriteLine("\tSet order {0} (container {1}) as ready", job.OrderNumber, job.ContainerNumber);
                }
                this._jobService.SaveChanges();
            }
            else
            {
                Console.WriteLine("No ready jobs found");
            }
        }

        private void BackgroundWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //var result = (string)e.Result;
        }

        private void InitializeBackgroundWorker()
        {
            _backgroundWorker = new BackgroundWorker();
            _backgroundWorker.DoWork += this.BackgroundWorkerDoWork;
            _backgroundWorker.RunWorkerCompleted += this.BackgroundWorkerRunWorkerCompleted;
        }

        private void InitializeTimer()
        {
            var timerCallback = new TimerCallback(TimerTick);
            this._timer = new Timer(timerCallback, null, 0, TimerDelayInSeconds * 1000);
        }

        #endregion
    }
}