﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;

using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.BackgroundProcesses
{
    /// <summary>
    /// The location distance creator created empty LocationDistance records
    /// based upon origins and destinations entered into the tool
    /// </summary>
    internal class LocationDistanceCreaterBW
    {
        #region Constants

        private const int TimerDelayInSeconds = 10;

        #endregion

        #region Static Fields

        private static BackgroundWorker _backgroundWorker;

        #endregion

        #region Fields

        private readonly IJobService _jobService;

        private readonly ILocationDistanceService _locationDistanceService;

        private Timer _timer;

        #endregion

        #region Constructors and Destructors

        public LocationDistanceCreaterBW(ILocationDistanceService locationDistanceService, IJobService jobService)
        {
            this._locationDistanceService = locationDistanceService;
            this._jobService = jobService;

            this.InitializeBackgroundWorker();
            this.InitializeTimer();
        }

        #endregion

        #region Methods

        private static void TimerTick(Object stateInfo)
        {
            if (!_backgroundWorker.IsBusy)
            {
                _backgroundWorker.RunWorkerAsync();
            }
        }

        private void BackgroundWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            IList<Job> jobs;
            IList<Location> locations;

            this.GetPending(30, out jobs, out locations);

            if (jobs.Count > 0)
            {
                Console.Write("\nCreating records for New Orders... \n");
            }

            foreach (DateTime date in this.GetJobDates(jobs))
            {
                // creates the new records required
                this._locationDistanceService.CreateEmptyRecords(date, locations);
            }

            if (jobs.Count > 0)
            {
                //Console.Write("\nUpdating Jobs... ");
            }

            foreach (Job job in jobs)
            {
                job.LocationDistanceProcessedDate = DateTime.UtcNow;
                this._jobService.Update(job, true);
            }

            this._jobService.SaveChanges();
            return;

            //var records = GetEmptyLocationDistanceRecords();

            //if (records.Count > 0)
            //{
            //    Console.WriteLine(string.Format("Fetching Travel Time Distances for {0} record(s)" + "\n", records.Count));
            //}

            //Action<int> updateRecord = (recordIndex) =>
            //{

            //    try
            //    {
            //        var swatch = new Stopwatch();
            //        swatch.Start();
            //        var record = records[recordIndex];
            //        //Console.WriteLine("\tUpdating record " + record.Id);

            //        var result = _externalDistanceCalculator.Get(record, DateTime.UtcNow.Date);

            //        //Console.WriteLine("Response received");

            //        _locationDistanceService.UpdateAsync(result);

            //        swatch.Stop();
            //        //Console.WriteLine("Item updated in " + swatch.Elapsed.ToString());                    
            //    }
            //    catch (Exception ex)
            //    {
            //        // TODO log error

            //    }
            //};

            //if (false)
            //{
            //    Parallel.For(0, records.Count, updateRecord);
            //}
            //else
            //{
            //    for (int i = 0; i < records.Count; i++)
            //    {
            //        updateRecord(i);
            //    }
            //}

            //if (records.Count > 0)
            //{
            //    Console.WriteLine(string.Format("Finished Fetching Travel Distances" + "\n", records.Count));
            //}
        }

        private void BackgroundWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
        }

        private IEnumerable<DateTime> GetJobDates(IEnumerable<Job> jobs)
        {
            var result = new HashSet<DateTime>();
            foreach (Job job in jobs)
            {
                if (job.DueDate.HasValue)
                {
                    result.Add(job.DueDate.Value);
                }
            }

            return result;
        }

        private void GetPending(int takeCount, out IList<Job> jobs, out IList<Location> locations)
        {
            jobs = new List<Job>();
            locations = new List<Location>();

            try
            {
                jobs =
                    this._jobService.SelectWithAll().Where(
                        p => p.LocationDistanceProcessedDate == null && p.IsValid && p.JobStatus == JobStatus.Unassigned)
                        .Take(takeCount).ToList();

                locations = jobs.SelectMany(pp => pp.RouteStops.Select(p => p.Location)).ToList();

                foreach (Job job in jobs)
                {
                    job.LocationDistanceProcessedDate = DateTime.UtcNow;
                    this._jobService.Update(job, true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void InitializeBackgroundWorker()
        {
            _backgroundWorker = new BackgroundWorker();
            _backgroundWorker.DoWork += this.BackgroundWorkerDoWork;
            _backgroundWorker.RunWorkerCompleted += this.BackgroundWorkerRunWorkerCompleted;
        }

        private void InitializeTimer()
        {
            var timerCallback = new TimerCallback(TimerTick);
            this._timer = new Timer(timerCallback, null, 0, TimerDelayInSeconds * 1000);
        }

        #endregion
    }
}