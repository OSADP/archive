﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Services.ExternalDistanceService;

namespace PAI.FRATIS.BackgroundProcesses
{
    /// <summary>
    /// Wrapper for background process to query an external distance
    /// service and update actual 
    /// </summary>
    internal class LocationDistanceUpdater
    {
        #region Constants

        private const int TimerDelayInSeconds = 10;

        #endregion

        #region Static Fields

        private static BackgroundWorker _backgroundWorker;

        #endregion

        #region Fields

        private readonly IExternalDistanceCalculator _externalDistanceCalculator;

        private readonly ILocationDistanceService _locationDistanceService;

        private Timer _timer;

        #endregion

        #region Constructors and Destructors

        public LocationDistanceUpdater(
            ILocationDistanceService locationDistanceService, IExternalDistanceCalculator externalDistanceCalculator)
        {
            this._locationDistanceService = locationDistanceService;
            this._externalDistanceCalculator = externalDistanceCalculator;

            this.InitializeBackgroundWorker();
            this.InitializeTimer();
        }

        #endregion

        #region Public Methods and Operators

        public static void TimerTick(Object stateInfo)
        {
            if (!_backgroundWorker.IsBusy)
            {
                _backgroundWorker.RunWorkerAsync();
            }
        }

        #endregion

        #region Methods

        private void BackgroundWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            IList<LocationDistance> records = this.GetEmptyLocationDistanceRecords();

            if (records.Count > 0)
            {
                Console.WriteLine(
                    string.Format("Fetching Travel Time Distances for {0} record(s)" + "\n", records.Count));
            }

            Action<int> updateRecord = (recordIndex) =>
                {
                    try
                    {
                        var swatch = new Stopwatch();
                        swatch.Start();
                        LocationDistance record = records[recordIndex];
                        //Console.WriteLine("\tUpdating record " + record.Id);

                        LocationDistance result = this._externalDistanceCalculator.Get(record, DateTime.UtcNow.Date);

                        //Console.WriteLine("Response received");

                        if (result.IsComplete)
                        {
                            this._locationDistanceService.Update(result, false);
                        }
                        swatch.Stop();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                };

            const bool ParallelismEnabled = false;
            if (ParallelismEnabled)
            {
                Parallel.For(0, records.Count, updateRecord);
            }
            else
            {
                for (int i = 0; i < records.Count; i++)
                {
                    updateRecord(i);
                }
            }

            this._locationDistanceService.SaveChanges();
            if (records.Count > 0)
            {
                Console.WriteLine(string.Format("Finished Fetching Travel Distances" + "\n", records.Count));
            }
        }

        private void BackgroundWorkerRunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
        }

        private IList<LocationDistance> GetEmptyLocationDistanceRecords()
        {
            try
            {
                List<LocationDistance> records =
                    this._locationDistanceService.SelectWithAll().Where(
                        p => p.ModifiedDate == null || p.Distance == null).Take(10).ToList();
                return records;
            }
            catch
            {
                return new List<LocationDistance>();
            }
        }

        private void InitializeBackgroundWorker()
        {
            _backgroundWorker = new BackgroundWorker();
            _backgroundWorker.DoWork += this.BackgroundWorkerDoWork;
            _backgroundWorker.RunWorkerCompleted += this.BackgroundWorkerRunWorkerCompleted;
        }

        private void InitializeTimer()
        {
            var timerCallback = new TimerCallback(TimerTick);
            this._timer = new Timer(timerCallback, null, 0, TimerDelayInSeconds * 1000);
        }

        #endregion
    }
}