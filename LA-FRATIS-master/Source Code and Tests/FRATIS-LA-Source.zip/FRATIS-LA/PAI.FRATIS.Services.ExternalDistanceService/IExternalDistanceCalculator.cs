﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Services.ExternalDistanceService
{
    /// <summary>The ExternalDistanceCalculator interface.</summary>
    public interface IExternalDistanceCalculator
    {
        /// <summary>The get.</summary>
        /// <param name="startLocation">The start location.</param>
        /// <param name="endLocation">The end location.</param>
        /// <returns>The <see cref="LocationDistance"/>.</returns>
        LocationDistance Get(Location startLocation, Location endLocation, DateTime departureTime, LocationDistance record = null);

        LocationDistance Get(LocationDistance locationDistance, DateTime departureTime, LocationDistance record = null);
    }



}
