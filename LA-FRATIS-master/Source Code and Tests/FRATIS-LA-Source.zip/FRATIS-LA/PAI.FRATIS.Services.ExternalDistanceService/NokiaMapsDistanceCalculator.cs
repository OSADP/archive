﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Services.ExternalDistanceService
{
    /// <summary>The nokia maps distance calculator.</summary>
    public class NokiaMapsDistanceCalculator : IExternalDistanceCalculator
    {
        private readonly INokiaMapsServiceFactory _nokiaMapsServiceFactory;


        /// <summary>Initializes a new instance of the <see cref="NokiaMapsDistanceCalculator"/> class.</summary>
        /// <param name="nokiaMapsService">The nokia maps service.</param>
        public NokiaMapsDistanceCalculator(INokiaMapsServiceFactory nokiaMapsServiceFactory)
        {
            this._nokiaMapsServiceFactory = nokiaMapsServiceFactory;
        }

        /// <summary>The get.</summary>
        /// <param name="startLocation">The start location.</param>
        /// <param name="endLocation">The end location.</param>
        /// <returns>The <see cref="LocationDistance"/>.</returns>
        public LocationDistance Get(Location startLocation, Location endLocation, DateTime departureDay, LocationDistance record = null)
        {
            if (record == null)
            {
                record = new LocationDistance();
            }

            record.StartLocationId = startLocation.Id;
            record.EndLocationId = endLocation.Id;
            record.DayOfWeek = (int)departureDay.DayOfWeek;
            record.DepartureDay = departureDay;

            var sw = new Stopwatch();
            sw.Start();

            if (startLocation.Longitude.HasValue && startLocation.Latitude.HasValue &&
                endLocation.Longitude.HasValue && endLocation.Latitude.HasValue)
            {
                Parallel.For(
                    0,
                    24,
                    (hourOfDay) =>
                    {
                        if (hourOfDay <= 5 || hourOfDay > 13)       // skipping 11PM - 6AM PST
                        {
                            var svc = this._nokiaMapsServiceFactory.CreateNokiaMapsService();

                            var summary = svc.GetRouteSummary(
                                startLocation.Latitude.Value,
                                startLocation.Longitude.Value,
                                endLocation.Latitude.Value,
                                endLocation.Longitude.Value,
                                departureDay.Date.AddHours(hourOfDay));

                            record.Hours[hourOfDay].TravelTime = (int)summary.TrafficTravelTime.Value.TotalSeconds;
                            if (summary.TravelTime.HasValue)
                            {
                                record.TravelTime = (long?)summary.TravelTime.Value.TotalSeconds;
                            }

                            record.Distance = (decimal?)summary.DistanceMiles;
                        }
                    });

            }

            sw.Stop();

            record.Hour6.TravelTime = record.Hour5.TravelTime;
            record.Hour7.TravelTime = record.Hour6.TravelTime;
            record.Hour8.TravelTime = record.Hour6.TravelTime;
            record.Hour9.TravelTime = record.Hour6.TravelTime;
            record.Hour10.TravelTime = record.Hour6.TravelTime;
            record.Hour11.TravelTime = record.Hour6.TravelTime;
            record.Hour12.TravelTime = record.Hour6.TravelTime;
            record.Hour13.TravelTime = record.Hour6.TravelTime;

            return record;
        }

        public LocationDistance Get(LocationDistance locationDistance, DateTime departureTime, LocationDistance record = null)
        {
            return this.Get(locationDistance.StartLocation, locationDistance.EndLocation, departureTime, locationDistance);
        }
    }
}