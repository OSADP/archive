using PAI.FRATIS.Wrappers.NokiaMaps;

namespace PAI.FRATIS.Services.ExternalDistanceService
{
    public interface INokiaMapsServiceFactory
    {
        INokiaMapsService CreateNokiaMapsService();
    }
}