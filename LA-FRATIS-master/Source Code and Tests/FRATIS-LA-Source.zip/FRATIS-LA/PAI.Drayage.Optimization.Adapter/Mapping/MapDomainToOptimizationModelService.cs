﻿using System;
using System.Collections.Generic;
using System.Linq;

using Omu.ValueInjecter;

using PAI.Drayage.Optimization.Adapter.Services;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.DataServices.Planning;
using PAI.FRATIS.DateTimeService;
using PAI.FRATIS.Domain.Planning;

using IRouteStopService = PAI.FRATIS.DataServices.Orders.IRouteStopService;
using Job = PAI.FRATIS.Domain.Orders.Job;
using Location = PAI.FRATIS.Domain.Geography.Location;
using Plan = PAI.Drayage.Optimization.Model.Planning.Plan;
using PlanConfig = PAI.Drayage.Optimization.Model.Planning.PlanConfig;
using StopAction = PAI.FRATIS.Domain.Orders.StopAction;
using TruckState = PAI.FRATIS.Domain.Planning.TruckState;

namespace PAI.Drayage.Optimization.Adapter.Mapping
{
    public interface IMapperService
    {
        void MapDomainToModel(Job job, Drayage.Optimization.Model.Orders.Job optimizationJob);

        void MapDomainToModel(FRATIS.Domain.Orders.Driver driver, Drayage.Optimization.Model.Orders.Driver optimizationDriver);

        PlanConfig MapDomainToModel(PAI.FRATIS.Domain.Planning.PlanConfig planConfig);

        Plan MapDomainToModel(FRATIS.Domain.Planning.Plan plan);

        void MapDomainToModel(
            PAI.FRATIS.Domain.Geography.LocationQueueDelay delay,
            Drayage.Optimization.Model.LocationQueueDelay modelDelay);

        FRATIS.Domain.Geography.Location MapModelToDomain(Drayage.Optimization.Model.Location locationModel);

        void MapModelToDomain(Plan planModel, FRATIS.Domain.Planning.Plan plan);

        void SetOptimizerLocationQueueDelays(IList<LocationQueueDelay> delays);
    }

    public class MapperService : IMapperService
    {
        private readonly IOptimizationDateTimeHelper _optDateTimeHelper;
        private readonly IRouteSanitizer _routeSanitizer;

        private readonly IRouteStopDelayService _routeStopDelayService;
        private readonly IRouteStopService _routeStopDataService;
        private readonly ILocationService _locationService;

        private readonly ILocationQueueDelayService _locationQueueDelayService;
        private readonly IJobService _jobService;
        private readonly IPlanService _planService;
        private readonly IDriverService _driverService;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly IStopActionService _stopActionService;

        public MapperService(IRouteSanitizer routeSanitizer, IRouteStopService routeStopDataService,
            ILocationService locationService, IJobService jobService, IPlanService planService, 
            IDriverService driverService, IDateTimeHelper dateTimeHelper, IStopActionService stopActionService, 
            ILocationQueueDelayService locationQueueDelayService, IRouteStopDelayService routeStopDelayService, 
            IOptimizationDateTimeHelper optDateTimeHelper)
        {
            this._routeSanitizer = routeSanitizer;
            this._routeStopDataService = routeStopDataService;
            this._locationService = locationService;
            this._jobService = jobService;
            this._planService = planService;
            this._driverService = driverService;
            this._dateTimeHelper = dateTimeHelper;
            this._stopActionService = stopActionService;
            this._locationQueueDelayService = locationQueueDelayService;
            this._routeStopDelayService = routeStopDelayService;
            this._optDateTimeHelper = optDateTimeHelper;
        }

        public void SetOptimizerLocationQueueDelays(IList<LocationQueueDelay> delays)
        {
            _routeStopDelayService.SetLocationQueueDelays(delays);
        }

        public Location MapModelToDomain(Drayage.Optimization.Model.Location locationModel)
        {
            var result = new FRATIS.Domain.Geography.Location();
            result.InjectFrom(locationModel);
            return result;
        }

        public void MapModelToDomain(Plan planModel, FRATIS.Domain.Planning.Plan plan)
        {
            // create map so we have reference to same route stop
            var routeStopMap = new Dictionary<RouteStop, FRATIS.Domain.Orders.RouteStop>();

            foreach (var driverPlanModel in planModel.DriverPlans)
            {
                PlanDriver planDriver = null;

                if (driverPlanModel.Id > 0)
                {
                    planDriver = plan.DriverPlans.FirstOrDefault(f => f.Id == driverPlanModel.Id);
                }

                if (planDriver == null)
                {
                    planDriver = new PlanDriver
                    {
                        DriverId = driverPlanModel.Driver.Id
                    };

                    plan.DriverPlans.Add(planDriver);
                }

                // RouteSegmentMetrics persistance disabled - transaction overhead exceeds realtime computation delay

                // Metrics
                planDriver.RouteSegmentMetrics.Clear();
                int routeSegmentStatIndex = 0;
                foreach (var routeSegmentStatModel in driverPlanModel.RouteSegmentStatistics)
                {
                    var startStop = this.GetOrCreateDomainRouteStop(routeStopMap, routeSegmentStatModel.StartStop);
                    var endStop = this.GetOrCreateDomainRouteStop(routeStopMap, routeSegmentStatModel.EndStop);

                    int? jobId = null;
                    if (startStop.JobId.HasValue && startStop.JobId > 0)
                    {
                        jobId = startStop.JobId;
                    }
                    if (endStop.JobId.HasValue && endStop.JobId > 0)
                    {  
                        jobId = endStop.JobId;  // prefer the job id of the end stop
                    }

                    var routeSegmentMetric = new RouteSegmentMetric()
                    {
                        JobId = jobId,
                        StartStopId = startStop.LocationId,
                        EndStopId = endStop.LocationId,
                        StartStop = startStop,
                        EndStop = endStop,
                        PlanDriver = planDriver,
                        StartTime = routeSegmentStatModel.StartTime.Ticks,
                        TotalExecutionTime = routeSegmentStatModel.Statistics.TotalExecutionTime.Ticks,
                        TotalTravelDistance = routeSegmentStatModel.Statistics.TotalTravelDistance,
                        TotalTravelTime = routeSegmentStatModel.Statistics.TotalTravelTime.Ticks,
                        TotalIdleTime = routeSegmentStatModel.Statistics.TotalIdleTime.Ticks,
                        TotalQueueTime = routeSegmentStatModel.Statistics.TotalQueueTime.Ticks,
                        TruckState = (TruckState)routeSegmentStatModel.TruckState,
                        SortOrder = routeSegmentStatIndex++,
                    };

                    planDriver.RouteSegmentMetrics.Add(routeSegmentMetric);
                }
                
                // Update job plans
                int jobIndex = 0;
                foreach (var jobPlanModel in driverPlanModel.JobPlans)
                {
                    var planDriverJob = planDriver.JobPlans.FirstOrDefault(jp => jp.JobId == jobPlanModel.Job.Id);

                    if (planDriverJob == null)
                    {
                        planDriverJob = new PlanDriverJob()
                            {
                                JobId = jobPlanModel.Job.Id,
                                SortOrder = jobIndex,
                                DepartureTime = jobPlanModel.DepartureTime
                            };

                        planDriver.JobPlans.Add(planDriverJob);
                    }
                    else
                    {
                        if (planDriverJob.SortOrder != jobIndex)
                        {
                            planDriverJob.SortOrder = jobIndex;
                        }
                    }

                    jobIndex++;
                }

                // remove extra job plans
                var jobPlansToRemove = planDriver.JobPlans.Where(jp => driverPlanModel.JobPlans.All(f => f.Id != jp.Id)).ToList();
                foreach (var jp in jobPlansToRemove)
                {
                    planDriver.JobPlans.Remove(jp);
                }
            }

            foreach (var unassignedJob in planModel.UnassignedJobs)
            {
                var job = this._jobService.GetById(unassignedJob.Id);
                plan.UnassignedJobs.Add(job);
            }
        }

        public FRATIS.Domain.Orders.RouteStop GetOrCreateDomainRouteStop(Dictionary<RouteStop, FRATIS.Domain.Orders.RouteStop> map, RouteStop routeStopModel)
        {
            FRATIS.Domain.Orders.RouteStop routeStop = null;
            map.TryGetValue(routeStopModel, out routeStop);
            if (routeStop == null)
            {
                if (routeStopModel.Id > 0)
                {
                    routeStop = this._routeStopDataService.GetById(routeStopModel.Id);
                }

                if (routeStop == null)
                {
                    routeStop = new FRATIS.Domain.Orders.RouteStop
                    {
                        StopActionId = routeStopModel.StopAction.Id,
                        LocationId = routeStopModel.Location.Id,
                    };
                }
                map[routeStopModel] = routeStop;
            }
            return routeStop;
        }

        public PlanConfig MapDomainToModel(PAI.FRATIS.Domain.Planning.PlanConfig planConfig)
        {
            var model = new PlanConfig();

            model.InjectFrom<DomainToModelValueInjection>(planConfig);

            foreach (var job in planConfig.Jobs)
            {
                var modelJob = model.Jobs.FirstOrDefault(f => f.Id == job.Id);
                this.MapDomainToModel(job, modelJob);
            }

            foreach (var driver in planConfig.Drivers)
            {
                var modelDriver = model.Drivers.FirstOrDefault(d => d.Id == driver.Id);
                var domainDriver = driver;
                this.MapDomainToModel(domainDriver, modelDriver);
            }

            return model;
        }

        //public IEnumerable<Optimization.Model.Orders.Job> MapDomainToModel(Order order)
        //{
        //    var jobs = new List<Optimization.Model.Orders.Job>();
        //    foreach (var job in order.Jobs)
        //    {
        //        var optimizationJob = new Optimization.Model.Orders.Job();
        //        MapDomainToModel(job, optimizationJob);
        //        jobs.Add(optimizationJob);
        //    }
        //    return jobs;
        //}


        public void MapDomainToModel(FRATIS.Domain.Orders.Driver driver, Drayage.Optimization.Model.Orders.Driver optimizationDriver)
        {
            optimizationDriver.InjectFrom<DomainToModelValueInjection>(driver);
        }


        public void MapDomainToModel(PAI.FRATIS.Domain.Geography.LocationQueueDelay delay, Drayage.Optimization.Model.LocationQueueDelay modelDelay)
        {
            delay.InjectFrom<DomainToModelValueInjection>(modelDelay);
        }

        public void MapDomainToModel(PAI.FRATIS.Domain.Orders.Job job, Drayage.Optimization.Model.Orders.Job optimizationJob)
        {
            optimizationJob.InjectFrom<DomainToModelValueInjection>(job);

            var equipmentConfiguration = new EquipmentConfiguration();
            equipmentConfiguration.InjectFrom<DomainToModelValueInjection>(job);

            optimizationJob.EquipmentConfiguration = equipmentConfiguration;

            var modelRouteStops = optimizationJob.RouteStops.ToList();
            optimizationJob.RouteStops.Clear();

            if (job.RouteStops != null && optimizationJob.RouteStops != null)
            {
                var routeStopIndex = 0;
                foreach (var routeStop in job.RouteStops)
                {
                    var modelRouteStop = modelRouteStops.FirstOrDefault(f => f.Id == routeStop.Id);
                    if (modelRouteStop != null)
                    {
                        routeStop.SortOrder = routeStopIndex++;

                        if (routeStop.Location != null && routeStop.Location.WaitingTime.HasValue)
                        {
                            modelRouteStop.QueueTime = new TimeSpan(0, routeStop.Location.WaitingTime.Value, 0);
                        }

                        // fixed hotspot
                        if (routeStop.LocationId != null && routeStop.Location == null)
                        {
                            var location = this._locationService.GetById((int)routeStop.LocationId);
                            routeStop.LocationId = location.Id;
                            routeStop.Location = location;
                        }

                        if (routeStop.StopAction != null)
                        {
                            modelRouteStop.StopAction = StopActions.Actions.FirstOrDefault(p => p.ShortName == routeStop.StopAction.ShortName);
                        }

                        if (routeStop.StopDelay.HasValue)
                        {
                            modelRouteStop.ExecutionTime = new TimeSpan(0, Convert.ToInt32(routeStop.StopDelay.Value), 0);
                        }

                        var dueDateLocal = this._dateTimeHelper.ConvertUtcToLocalTime(job.DueDate.Value);


                        modelRouteStop.WindowStart = new TimeSpan(routeStop.WindowStart);
                        modelRouteStop.WindowEnd = new TimeSpan(routeStop.WindowEnd);

                        // map stop action
                        modelRouteStop.StopAction = this.MapDomainToModel(routeStop.StopAction);
                        // Remove Dynamic stops
                        if (routeStop.IsDynamicStop)
                        {
                            optimizationJob.RouteStops.Remove(modelRouteStop);
                        }

                        optimizationJob.RouteStops.Add(modelRouteStop);
                    }
                    else
                    {
                        var nullModelRouteStop = modelRouteStop;
                    }
                }
            }
            
            this._routeSanitizer.PrepareJob(optimizationJob);
        }

        public Drayage.Optimization.Model.Orders.StopAction MapDomainToModel(StopAction stopAction)
        {
            return StopActions.Actions.SingleOrDefault(f => f.ShortName == stopAction.ShortName);
        }

        public Drayage.Optimization.Model.Planning.Plan MapDomainToModel(FRATIS.Domain.Planning.Plan plan)
        {
            var model = new Plan();
            model.InjectFrom<DomainToModelValueInjection>(plan);

            foreach (var driverPlan in plan.DriverPlans)
            {
                var modelDriverPlan = model.DriverPlans.FirstOrDefault(f => f.Id == driverPlan.Id);

                if (modelDriverPlan == null) 
                    continue;
                
                var driver = driverPlan.Driver ?? this._driverService.GetById(driverPlan.DriverId);

                var driverModel = new Drayage.Optimization.Model.Orders.Driver();
                driverModel.InjectFrom<DomainToModelValueInjection>(driver);

                modelDriverPlan.Driver = driverModel.InjectFrom(driver) as Drayage.Optimization.Model.Orders.Driver;


                modelDriverPlan.JobPlans = modelDriverPlan.JobPlans.OrderBy(f => f.SortOrder).ToList();
                foreach (var jobPlan in driverPlan.JobPlans)
                {
                    //var driverPlanJob = _planService.GetPlanDriverJobsById(jobPlan.Id);

                    var modelJobPlan = modelDriverPlan.JobPlans.FirstOrDefault(f => f.Id == jobPlan.Id);
                    modelJobPlan.Job = modelJobPlan.Job ?? new Drayage.Optimization.Model.Orders.Job();

                    this.MapDomainToModel(jobPlan.Job, modelJobPlan.Job);
                }
            }

            return model;
        }

    }
}
