﻿using System.Collections.Generic;

using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Planning;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public interface IPlanGeneratorInitializer
    {
        void Initialize(IList<Job> jobs, IList<Driver> drivers);

        void Initialize(IList<Location> locations, IList<LocationDistance> locationDistances);

        
    }
}