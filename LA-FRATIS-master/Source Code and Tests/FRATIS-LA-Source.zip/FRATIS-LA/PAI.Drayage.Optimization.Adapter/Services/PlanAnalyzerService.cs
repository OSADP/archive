﻿using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.FRATIS.DateTimeService;
using PAI.FRATIS.Domain.Planning;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public struct TerminalJobs
    {
        private IEnumerable<TerminalJob> Jobs { get; set; }
    }

    public struct TerminalJob
    {
        public int? TerminalLocationId { get; set; }

        public int? JobId { get; set; }

        public int? RouteStopId { get; set; }

        public DateTime? ETA { get; set; }
    }

    public interface IPlanAnalyzerService
    {
        ICollection<TerminalArrivalEstimation> GetArrivalEstimations(
            Solution plan,
            DateTime planningDate,
            IList<int> locationIds,
            bool recalculateStatistics = true,
            PlanAnalyzerService.TimeZonePreference timeZone = PlanAnalyzerService.TimeZonePreference.Utc);
    }
    
    public struct TerminalArrivalEstimation
    {
        public int? JobId { get; set; }

        public int? RouteStopId { get; set; }

        public int? StartLocationId { get; set; }

        public int? EndLocationId { get; set; }

        public DateTime? ArrivalTime { get; set; }

        public int DriverId { get; set; }
    }

    public class PlanAnalyzerService : IPlanAnalyzerService
    {
        private readonly IPlanGenerator _planGenerator;

        private readonly IReportingService _reportingService;
 
        private readonly IDateTimeHelper _dateTimeHelper;

        public PlanAnalyzerService(IPlanGenerator planGenerator, IDateTimeHelper dateTimeHelper, IReportingService reportingService)
        {
            this._planGenerator = planGenerator;
            this._dateTimeHelper = dateTimeHelper;
            _reportingService = reportingService;
        }

        public enum TimeZonePreference
        {
            Local,
            Utc
        }

        public ICollection<TerminalArrivalEstimation> GetArrivalEstimations(Solution plan, DateTime planningDate, IList<int> locationIds, bool recalculateStatistics = true, TimeZonePreference timeZone = TimeZonePreference.Utc)
        {
            var result = new List<TerminalArrivalEstimation>();
            var solutionPerformance = _reportingService.GetSolutionPerformanceStatistics(plan);


            foreach (var routeSolution in plan.RouteSolutions)
            {
                var currentStop = 1; 
                var driverStatistics = solutionPerformance.TruckStatistics.FirstOrDefault(p => p.Key.DriverNode.Driver.Id == routeSolution.DriverNode.Driver.Id).Value;
                var startStatistics = driverStatistics.RouteSegmentStatistics[0];


                int currentStopLocationId = 0;
                int lastStopLocationId = 0;

                foreach (var node in routeSolution.Nodes)
                {
                    
                    foreach (var rs in node.RouteStops)
                    {
                        currentStopLocationId = rs.Location.Id;

                        if (rs.Location != null && locationIds.Contains(rs.Location.Id))
                        {
                            var segmentStatistics = driverStatistics.RouteSegmentStatistics[currentStop-1];
                            var leavePreviousStopTime = segmentStatistics.StartTime;
                            var arrivalTime = segmentStatistics.StartTime.Add(segmentStatistics.Statistics.TotalTravelTime).Add(segmentStatistics.Statistics.TotalWaitTime);

                            var jobId = 0;
                            if (node is JobNode)
                            {
                                var jn = node as JobNode;
                                jobId = jn.Job.Id;
                            }


                            result.Add(new TerminalArrivalEstimation()
                                {
                                    ArrivalTime = planningDate.AddTicks(arrivalTime.Ticks),
                                    DriverId = routeSolution.DriverNode.Driver.Id,
                                    RouteStopId = rs.Id,
                                    StartLocationId = lastStopLocationId,
                                    EndLocationId = currentStopLocationId,
                                    JobId = jobId,
                                });
                        }

                        currentStop++;
                        lastStopLocationId = currentStopLocationId;
                    }
                }
            }

            return result;
        }
    }
}
