﻿using System;
using System.Collections.Generic;
using System.Linq;

using Omu.ValueInjecter;

using PAI.Drayage.Optimization.Adapter.Mapping;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Reporting.Model;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;
using PAI.FRATIS.DataServices.Configuration;
using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.DataServices.Planning;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Planning;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public class PlanGenerator : IPlanGenerator
    {
        private readonly IPlanService _planService;
        private readonly IReportingService _reportingService;
        private readonly IDriverService _driverService;
        private readonly IMapperService _mapperService;

        private readonly ILocationService _locationService;
        private readonly ILocationDistanceService _locationDistanceService;
        private readonly ISuperDistanceServiceInitializer _superDistanceServiceInitializer;
        private readonly IDrayageOptimizer _drayageOptimizer;

        public PlanGenerator(
            IPlanService planService,
            IDriverService driverService, 
            IMapperService mapperService,  
            IReportingService reportingService, 
            IDrayageOptimizer drayageOptimizer, ISuperDistanceServiceInitializer superDistanceServiceInitializer, ISuperDistanceServiceInitializer superDistanceService, ILocationDistanceService locationDistanceService, ILocationService locationService)
        {
            this._planService = planService;
            this._driverService = driverService;
            this._mapperService = mapperService;
            this._reportingService = reportingService;
            
            _drayageOptimizer = drayageOptimizer;
            _superDistanceServiceInitializer = superDistanceServiceInitializer;
            _locationDistanceService = locationDistanceService;
            _locationService = locationService;
        }

        private void MapDomainToOptimizationModel(
            IEnumerable<Driver> drivers, 
            IEnumerable<Job> jobs, 
            IEnumerable<LocationQueueDelay> delays, 
            out IList<Model.Orders.Driver> modelDrivers, 
            out IList<Model.Orders.Job> modelJobs, 
            out IList<Model.LocationQueueDelay> modelDelays)
        {
            modelDrivers = new List<Model.Orders.Driver>();
            modelJobs = new List<Model.Orders.Job>();
            modelDelays = new List<Model.LocationQueueDelay>();

            foreach (var driver in drivers)
            {
                var result = new Model.Orders.Driver();
                _mapperService.MapDomainToModel(driver, result);
                modelDrivers.Add(result);
            }

            foreach (var job in jobs)
            {
                var result = new Model.Orders.Job();
                _mapperService.MapDomainToModel(job, result);
                modelJobs.Add(result);
            }

            foreach (var delay in delays)
            {
                var result = new Model.LocationQueueDelay();
                _mapperService.MapDomainToModel(delay, result);
                modelDelays.Add(result);
            }
        }

        public Solution GeneratePlan(IList<Driver> drivers, IList<Job> jobs, DayOfWeek dayOfWeek, IList<LocationQueueDelay> delays = null, IList<LocationDistance> locationDistances = null)
        {
            IList<Model.Orders.Driver> modelDrivers;
            IList<Model.Orders.Job> modelJobs;
            IList<Model.LocationQueueDelay> modelDelays;
            var isSuperDistanceServiceInitialized = false;

            this.MapDomainToOptimizationModel(drivers, jobs, delays, out modelDrivers, out modelJobs, out modelDelays);

            if (locationDistances == null || !locationDistances.Any())
            {
                // fetch from dataservices
                _superDistanceServiceInitializer.Initialize(jobs, drivers);
            }
            else
            {
                var locations = _superDistanceServiceInitializer.GetLocations(jobs, drivers);
                _superDistanceServiceInitializer.Initialize(locations, locationDistances);
            }

            return GeneratePlan(modelDrivers, modelJobs, dayOfWeek, modelDelays, locationDistances, true);
        }

        public Solution GeneratePlan(IList<Model.Orders.Driver> drivers, IList<Model.Orders.Job> jobs, DayOfWeek dayOfWeek, 
            IList<Model.LocationQueueDelay> delays, IList<LocationDistance> locationDistances = null, bool isSuperDistanceServiceInitialized = false )
        {
            _mapperService.SetOptimizerLocationQueueDelays(delays);
            _drayageOptimizer.Initialize();

            if (!isSuperDistanceServiceInitialized && locationDistances != null && locationDistances.Any())
            {
                _locationDistanceService.SetInCache(locationDistances);
            }

            var defaultDriver = drivers.First();
            return _drayageOptimizer.BuildSolution(drivers, defaultDriver, jobs);
        }
    }
}