﻿using System.Collections.Generic;
using System.Linq;

using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Planning;
using PAI.FRATIS.Domain.Orders;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public class SuperDistanceServiceInitializer : IPlanGeneratorInitializer, ISuperDistanceServiceInitializer
    {
        private readonly ILocationDistanceService _locationDistanceService;

        public SuperDistanceServiceInitializer(ILocationDistanceService locationDistanceService)
        {
            this._locationDistanceService = locationDistanceService;
        }

        public IList<Location> GetLocations(IList<Job> jobs, IList<Driver> drivers)
        {
            var locationsSet = new HashSet<Location>();
            var routeStops = jobs.Select(p => p.RouteStops).ToList();
            
            foreach (var routeStopList in routeStops.ToList())
            {
                foreach (var rs in routeStopList)
                {
                    locationsSet.Add(rs.Location);
                }
            }

            foreach (var driver in drivers)
            {
                if (driver.StartingLocation != null)
                {
                    locationsSet.Add(driver.StartingLocation);
                }
            }

            return locationsSet.ToList();
        }

        public void Initialize(IList<Job> jobs, IList<Driver> drivers)
        {
            var locationsSet = this.GetLocations(jobs, drivers);
            _locationDistanceService.Prefetch(locationsSet.ToList());
        }

        public void Initialize(IList<Location> locations, IList<LocationDistance> locationDistances)
        {
            _locationDistanceService.Prefetch(locations, locationDistances);
        }
    }
}