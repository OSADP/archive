﻿using System;

using PAI.Drayage.Optimization.Adapter.Mapping;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.FRATIS.DataServices.Geography;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public class SuperDistanceService : IDistanceService
    {
        private readonly IDistanceService _fallbackDistanceService;
        private readonly IMapperService _mapperService;
        private readonly ILocationDistanceService _locationDistanceService;

        public SuperDistanceService(IMapperService mapperService, ILocationDistanceService locationDistanceService, 
            IDistanceService fallbackDistanceService)
        {
            this._mapperService = mapperService;
            this._locationDistanceService = locationDistanceService;
            this._fallbackDistanceService = fallbackDistanceService;
        }

        public TripLength CalculateDistance(Location startLocation, Location endLocation)
        {
            return this.CalculateDistance(startLocation, endLocation, TimeSpan.Zero);
        }

        public TripLength CalculateDistance(Location startLocation, Location endLocation, TimeSpan startTime)
        {
            var startLocationDomain = this._mapperService.MapModelToDomain(startLocation);
            var endLocationDomain = this._mapperService.MapModelToDomain(endLocation);
            
            var locationDistance = this._locationDistanceService.Get(startLocationDomain, endLocationDomain);

            TripLength result;

            if (locationDistance != null)
            {
                var hourIndex = (int)startTime.TotalHours;

                while (hourIndex >= 24)
                {
                    hourIndex = hourIndex - 24;
                }

                long travelTime = locationDistance.Hours[hourIndex].TravelTime.Value;
                if (travelTime == 0 && locationDistance.TravelTime.HasValue)
                {
                    travelTime = locationDistance.TravelTime.Value;
                }

                long distance = 0;
                if (locationDistance.Distance.HasValue)
                    distance = (long)locationDistance.Distance.Value;

                result = new TripLength(distance, TimeSpan.FromSeconds(travelTime));
            }
            else
            {
                // Use fallback service
                result = this._fallbackDistanceService.CalculateDistance(startLocation, endLocation, startTime);
            }

            return result;
        }
    }
}