﻿using System;
using System.Collections.Generic;

using PAI.Drayage.Optimization.Model.Node;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Geography;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    /// <summary>
    /// The Plan Generator interface
    /// </summary>
    public interface IPlanGenerator
    {
        Solution GeneratePlan(
            IList<Driver> drivers, 
            IList<Job> jobs, 
            DayOfWeek dayOfWeek, 
            IList<LocationQueueDelay> delays = null,
            IList<LocationDistance> locationDistances = null);

        Solution GeneratePlan(
            IList<Model.Orders.Driver> drivers,
            IList<Model.Orders.Job> jobs,
            DayOfWeek dayOfWeek,
            IList<Model.LocationQueueDelay> delays,
            IList<LocationDistance> locationDistances = null,
            bool isSuperDistanceServiceInitialized = false);
    }
}