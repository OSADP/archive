using System.Collections.Generic;

using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public interface ISuperDistanceServiceInitializer
    {
        IList<Location> GetLocations(IList<Job> jobs, IList<Driver> drivers);

        void Initialize(IList<Job> jobs, IList<Driver> drivers);

        void Initialize(IList<Location> locations, IList<LocationDistance> locationDistances);
    }
}