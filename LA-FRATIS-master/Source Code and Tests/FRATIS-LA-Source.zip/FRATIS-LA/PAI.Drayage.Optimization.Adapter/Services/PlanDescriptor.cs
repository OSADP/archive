﻿using System;
using System.Collections.Generic;
using System.Linq;

using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Planning;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    public interface IPlanDescriptor
    {
        Dictionary<int, List<string>> GetDriverPlanVerboseRoutes(Plan plan);
    }

    public class PlanDescriptor : IPlanDescriptor
    {
        private readonly ILocationService _locationService;

        private readonly IStopActionService _stopActionService;

        private readonly IDriverService _driverService;

        private readonly ICollection<StopAction> _stopActions;

        private IList<Driver> _drivers = null; 

        public PlanDescriptor(ILocationService locationService, IStopActionService stopActionService, IDriverService driverService)
        {
            this._locationService = locationService;
            this._stopActionService = stopActionService;
            this._driverService = driverService;
            this._stopActions = this._stopActionService.GetStopActions();
        }

        private string GetStopAction(int id)
        {
            var sa = this._stopActions.FirstOrDefault(p => p.Id == id);
            return sa != null ? sa.ShortName : string.Empty;
        }

        private string GetDriverName(int id)
        {
            if (this._drivers == null)
            {
                this._drivers = this._driverService.Select().ToList();
            }

            var result = this._drivers.FirstOrDefault(p => p.Id == id);
            return result != null ? result.DisplayName : string.Empty;
        }

        private readonly Dictionary<int, string> _locationNamesById = new Dictionary<int, string>();
        private string GetLocationName(int id)
        {
            string result;
            try
            {
                if (!this._locationNamesById.TryGetValue(id, out result))
                {
                    var entity = this._locationService.GetById(id);
                    if (entity != null)
                    {
                        result = entity.DisplayName;
                        this._locationNamesById[id] = result;
                    }
                }
            }
            catch (Exception e)
            {
                result = string.Format("LocationId {0}", id);
            }

            return result;
        }

        public Dictionary<int, List<string>> GetDriverPlanVerboseRoutes(Plan plan)
         {
             var result = new Dictionary<int, List<string>>();

             foreach (var dp in plan.DriverPlans)
             {
                var sequence = new List<string>();
                 RouteSegmentMetric prevRsm = null;
                 for (int i=0; i<dp.RouteSegmentMetrics.Count;i++)
                 {
                     var rsm = dp.RouteSegmentMetrics[i];

                     if (i == 0)
                     {
                         sequence.Add(string.Format("Starting from {0} at {1} going to {2} ({3}) - (waited {4}) Travelling {5}mi in {6} | queue {7}", 
                             dp.Driver.StartingLocation.DisplayName.ToUpper(), 
                             DateTime.Now.Date.Add(rsm.DepartureTimeSpan).ToShortTimeString(),
                             this.GetLocationName(rsm.EndStop.LocationId.Value),
                             this.GetStopAction(rsm.EndStop.StopActionId.Value),
                             string.Format("{0}hrs {1}mi", rsm.TotalIdleTimeSpan.Hours, rsm.TotalIdleTimeSpan.Minutes),
                             (int)rsm.TotalTravelDistance,
                             string.Format("{0}hrs {1}min", rsm.TotalTravelTimeSpan.Hours, rsm.TotalTravelTimeSpan.Minutes),
                             string.Format("{0}hrs {1}min", rsm.TotalQueueTimeSpan.Hours, rsm.TotalQueueTimeSpan.Minutes)));
                     }
                     else if (i != dp.RouteSegmentMetrics.Count - 1)
                     {
                         sequence.Add(
                             string.Format(
                                 "Next stop @ {0} ({1}) departing prev stop @ {2}, arriving @ {3} - travelling {4}mi in {5} | queue {6}",
                                 this.GetLocationName(rsm.EndStop.LocationId.Value),
                                 this.GetStopAction(rsm.EndStop.StopActionId.Value),
                                 new TimeSpan(prevRsm.TotalTravelTime + prevRsm.StartTimeSpan.Ticks + prevRsm.TotalExecutionTime + prevRsm.TotalQueueTime + prevRsm.TotalIdleTime).ToString(@"hh\:mm"),
                                 new TimeSpan(prevRsm.TotalTravelTime + prevRsm.StartTimeSpan.Ticks + prevRsm.TotalExecutionTime + prevRsm.TotalQueueTime + prevRsm.TotalIdleTime + rsm.TotalTravelTime + rsm.TotalIdleTime + rsm.TotalQueueTime).ToString(@"hh\:mm"),
                                 (int)rsm.TotalTravelDistance,
                                 string.Format("{0}hrs {1}min", rsm.TotalTravelTimeSpan.Hours, rsm.TotalTravelTimeSpan.Minutes),
                                 string.Format("{0}hrs {1}min", rsm.TotalQueueTimeSpan.Hours, rsm.TotalQueueTimeSpan.Minutes)));
                     }
                     else
                     {
                         sequence.Add(
                             string.Format(
                                 "Return HOME, leaving prev stop at {0} and arriving at {1} ({2} miles).",
                                 new TimeSpan(
                                     prevRsm.TotalTravelTime + prevRsm.StartTimeSpan.Ticks + prevRsm.TotalExecutionTime
                                     + prevRsm.TotalQueueTime + prevRsm.TotalIdleTime).ToString(@"hh\:mm"),
                                 new TimeSpan(
                                     prevRsm.TotalTravelTime + prevRsm.StartTimeSpan.Ticks + prevRsm.TotalExecutionTime
                                     + prevRsm.TotalQueueTime + prevRsm.TotalIdleTime + rsm.TotalTravelTime
                                     + rsm.TotalIdleTime + rsm.TotalQueueTime + rsm.TotalExecutionTime).ToString(
                                         @"hh\:mm"),
                                 (int)rsm.TotalTravelDistance));
                     }
                                          
                     prevRsm = rsm;
                 }

                 result[dp.Id] = sequence;
             }

             return result;
         }
    }
}