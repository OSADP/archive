﻿using System.Collections.Generic;

namespace PAI.Drayage.Optimization.Adapter.Services
{
    /// <summary>
    /// A plan generator result
    /// </summary>
    public class PlanGenerationResult
    {
        public bool Success { get; set; }

        public IEnumerable<string> Errors { get; set; }

        public Optimization.Model.Node.Solution Solution { get; set; }
        
        // public FRATIS.Domain.Planning.Plan Plan { get; set; }
    }
}