using System;
using System.Threading;

namespace PAI.FRATIS.Infrastructure.Threading
{
    /// <summary>
    /// Utility class used to provide Read locked access to resources. 
    /// </summary>
    public class ReadLockDisposable : IDisposable
    {
        private readonly ReaderWriterLockSlim _rwLock;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReadLockDisposable"/> class.
        /// </summary>
        /// <param name="rwLock">The ReaderWriterLockSlim lock.</param>
        public ReadLockDisposable(ReaderWriterLockSlim rwLock)
        {
            _rwLock = rwLock;
            _rwLock.EnterReadLock();
        }

        void IDisposable.Dispose()
        {
            _rwLock.ExitReadLock();
        }
    }
}