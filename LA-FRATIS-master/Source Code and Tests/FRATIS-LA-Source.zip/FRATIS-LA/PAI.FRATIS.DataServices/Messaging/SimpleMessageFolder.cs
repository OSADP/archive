﻿namespace PAI.FRATIS.DataServices.Messaging
{
    public enum SimpleMessageFolder
    {
        Inbox = 0,
        Sent = 1
    }
}