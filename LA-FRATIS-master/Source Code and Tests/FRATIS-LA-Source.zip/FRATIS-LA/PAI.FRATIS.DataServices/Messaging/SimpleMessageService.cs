﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Domain.Messaging;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Users;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Messaging
{
    public interface ISimpleMessageService : IEntityServiceBase<SimpleMessage>
    {
        IQueryable<SimpleMessage> SelectWithAll();

        ICollection<SimpleMessage> GetMessagesInFolder(User user, SimpleMessageFolder folder);

        IQueryable<SimpleMessage> GetSentMessages(User user, bool? isAlert = null, bool isUserSentOnly = true);

        SimpleMessage GetByIdWithAll(int id);

        IQueryable<SimpleMessage> GetTerminalMessages(int terminalOrganizationId, bool showFromTerminalOnly = false, bool showToTerminalOnly = false);

        int GetTerminalMessageUnreadCount(int terminalOrganizationId);

        void AcknowledgeTerminalMessages(int terminalOrganizationId);

        SimpleMessage SendMessage(
            User fromUser,
            string to,
            string subject,
            string body,
            int? toDriverId,
            int? toVehicleId,
            int? toOrganizationId = null,
            int? alertId = null,
            bool saveNow = true,
            bool doWork = true);
    }

    public class SimpleMessageService : EntityServiceBase<SimpleMessage>, ISimpleMessageService
    {
        private readonly IWebFleetMessagesService _webFleetMessagesService;

        private readonly IVehicleService _vehicleService;
 
        public SimpleMessageService(IRepository<SimpleMessage> repository, ICacheManager cacheManager, IWebFleetMessagesService webFleetMessagesService, IVehicleService vehicleService)
            : base(repository, cacheManager)
        {
            _webFleetMessagesService = webFleetMessagesService;
            _vehicleService = vehicleService;
        }

        public IQueryable<SimpleMessage> SelectWithAll()
        {
            return _repository.SelectWith(
                "ToDriver",
                "FromDriver",
                "ToVehicle",
                "ToUser", 
                "FromUser", 
                "ToOrganization",
                "FromOrganization");
        }

        public ICollection<SimpleMessage> GetMessagesInFolder(User user, SimpleMessageFolder folder)
        {
            var result = new List<SimpleMessage>();
            if (user != null)
            {    
                switch (folder)
                {
                    case SimpleMessageFolder.Sent:
                        if (user.SentMessages != null)
                        {
                            result = user.SentMessages.ToList();
                        }

                        break;
                    case SimpleMessageFolder.Inbox:
                        if (user.ReceivedMessages != null)
                        {
                            result = user.ReceivedMessages.ToList();
                        }

                        break;
                }
            }

            return result;
        }

        public IQueryable<SimpleMessage> GetSentMessages(User user, bool? isAlert = false, bool isUserSentOnly = true)
        {
            if (isUserSentOnly)
            {
                var query = SelectWithAll().Where(p => p.FromUserId == user.Id);
                if (isAlert.HasValue) query = query.Where(p => p.AlertId.HasValue == isAlert);
                return query;
            }

            if (user.OrganizationId.HasValue)
            {
                var query2 =
                    SelectWithAll().Where(p => (p.FromUserId == user.Id || p.FromOrganizationId == user.OrganizationId));
                if (isAlert.HasValue)
                {
                    query2 = query2.Where(p => p.AlertId.HasValue == isAlert);
                }
                return query2;
            }

            // todo refactor
            var query3 = SelectWithAll().Where(p => (p.FromUserId == user.Id));
            if (isAlert.HasValue)
            {
                query3 = query3.Where(p => p.AlertId.HasValue == isAlert);
            }
            return query3;

        }

        SimpleMessage ISimpleMessageService.GetByIdWithAll(int id)
        {
            return SelectWithAll().FirstOrDefault(p => p.Id == id);
        }

        public IQueryable<SimpleMessage> GetTerminalMessages(int terminalOrganizationId, bool showFromTerminalOnly = false, bool showToTerminalOnly = false)
        {
            if (!showFromTerminalOnly && !showToTerminalOnly)
            {
                return this.SelectWithAll().Where(p => p.FromOrganizationId == terminalOrganizationId
                        || p.ToOrganizationId == terminalOrganizationId);                
            }
            
            if (showFromTerminalOnly)
            {
                return this.SelectWithAll().Where(p => p.FromOrganizationId == terminalOrganizationId);
            }

            return this.SelectWithAll().Where(p => p.ToOrganizationId == terminalOrganizationId);
        }

        public int GetTerminalMessageUnreadCount(int terminalOrganizationId)
        {
            var messages = this.GetTerminalMessages(terminalOrganizationId, true);
            return messages != null && messages.Any() ? messages.Count() : 0;
        }

        public void AcknowledgeTerminalMessages(int terminalOrganizationId)
        {
            foreach (var message in GetTerminalMessages(terminalOrganizationId, true))
            {
                message.IsAcknowledged = true;
                this.Update(message, false);
            }

            SaveChanges();
        }

        public SimpleMessage SendMessage(User fromUser, string to, string subject, string body, int? toDriverId, int? toVehicleId, int? toOrganizationId = null, int? alertId = null, bool saveNow = true, bool doWork = true)
        {
            var message = new SimpleMessage
                {
                    CreatedDate = DateTime.UtcNow,
                    TimeStamp = DateTime.UtcNow,
                    From = fromUser.Username,
                    FromUserId = fromUser.Id,
                    FromOrganizationId = fromUser.OrganizationId,
                    To = to,
                    AlertId = alertId,
                    ToVehicleId = toVehicleId,
                    ToDriverId = toDriverId,
                    ToOrganizationId = toOrganizationId,
                    Subject = subject,
                    MessageBody = body
                };

            Insert(message, saveNow);

            if (doWork)
            {
                // send that message using external services now
                if (toVehicleId.HasValue)
                {
                    var vehicle = _vehicleService.GetById(toVehicleId.Value);
                    if (vehicle != null && !string.IsNullOrEmpty(vehicle.LegacyId))
                    {
                        _webFleetMessagesService.SendMessage(vehicle.LegacyId, body);
                    }
                }                
            }
            return message;
        }
    }
}
