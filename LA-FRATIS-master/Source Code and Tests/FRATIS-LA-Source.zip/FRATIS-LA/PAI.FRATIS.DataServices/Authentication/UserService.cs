﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Security;
using PAI.FRATIS.Domain.Users;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Authentication
{
    /// <summary>
    /// The user service.
    /// </summary>
    public class UserService : EntityServiceBase<User>, IUserService
    {
        #region Fields

        /// <summary>
        /// The encryption service.
        /// </summary>
        private readonly IEncryptionService _encryptionService;

        /// <summary>
        /// The password generator.
        /// </summary>
        private readonly IPasswordGenerator _passwordGenerator;

        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="UserService"/> class.
        /// </summary>
        /// <param name="repository">
        /// The repository.
        /// </param>
        /// <param name="cacheManager">
        /// The cache manager.
        /// </param>
        /// <param name="encryptionService">
        /// The encryption service.
        /// </param>
        /// <param name="passwordGenerator">
        /// The password generator.
        /// </param>
        public UserService(
            IRepository<User> repository,
            ICacheManager cacheManager,
            IEncryptionService encryptionService,
            IPasswordGenerator passwordGenerator)
            : base(repository, cacheManager)
        {
            this._encryptionService = encryptionService;
            this._passwordGenerator = passwordGenerator;
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Resets the user's password and email's them a new password
        /// </summary>
        /// <param name="email">email address</param>
        public void ForgotPassword(string email)
        {
            User user = this.GetUserByEmail(email);
            if (user == null || user.Deleted || !user.Active)
            {
                return;
            }

            string password = this._passwordGenerator.GeneratePassword(10);

            this.SetUserPassword(user, user.PasswordFormat, password);
        }

        /// <summary>
        /// The get user by email.
        /// </summary>
        /// <param name="email">
        /// The email address.
        /// </param>
        /// <returns>
        /// The <see cref="User"/>.
        /// </returns>
        public User GetUserByEmail(string email)
        {
            return this.InternalSelect().FirstOrDefault(u => u.Username == email);
        }

        public void Install(bool resetAdminCredentials = false)
        {
            User user = this.GetUserByEmail("admin");

            if (user != null && resetAdminCredentials == false)
            {
                return; // nothing to do
            }

            if (user == null)
            {
                user = new User { Username = "admin", UserType = UserType.Unspecified };
            }

            this.SetUserPassword(user, PasswordFormat.Hashed, "admin");
            InsertOrUpdate(user);
        }

        public void Install()
        {
            this.Install(false);
        }

        /// <summary>
        /// The is email unique.
        /// </summary>
        /// <param name="email">
        /// The email.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public bool IsEmailUnique(string email)
        {
            return !this.InternalSelect().Any(u => u.Username == email);
        }

        public IQueryable<User> SelectWithAll()
        {
            return this.InternalSelect();
        }

        /// <summary>
        /// The set user password.
        /// </summary>
        /// <param name="user">
        /// The user.
        /// </param>
        /// <param name="passwordFormat">
        /// The password format.
        /// </param>
        /// <param name="password">
        /// The password.
        /// </param>
        public void SetUserPassword(User user, PasswordFormat passwordFormat, string password)
        {
            user.PasswordFormat = passwordFormat;

            switch (user.PasswordFormat)
            {
                case PasswordFormat.Clear:
                    {
                        user.Password = password;
                    }

                    break;

                case PasswordFormat.Encrypted:
                    {
                        user.Password = this._encryptionService.EncryptText(password);
                    }

                    break;

                case PasswordFormat.Hashed:
                    {
                        string saltKey = this._encryptionService.CreateSaltKey(5);
                        user.PasswordSalt = saltKey;
                        user.Password = this._encryptionService.CreatePasswordHash(password, saltKey);
                    }

                    break;
            }
        }

        /// <summary>
        /// The validate customer.
        /// </summary>
        /// <param name="email">
        /// The email.
        /// </param>
        /// <param name="password">
        /// The password.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public virtual bool ValidateCustomer(string email, string password)
        {
            User user = this.GetUserByEmail(email);

            if (user == null || user.Deleted)
            {
                return false;
            }

            bool isValid = false;

            switch (user.PasswordFormat)
            {
                case PasswordFormat.Clear:
                    isValid = password == user.Password;
                    break;

                case PasswordFormat.Encrypted:
                    string pwd = this._encryptionService.EncryptText(password);

                    isValid = pwd == user.Password;
                    break;

                case PasswordFormat.Hashed:
                    string pwdhash = this._encryptionService.CreatePasswordHash(password, user.PasswordSalt);
                    isValid = pwdhash == user.Password;
                    break;
            }

            // save last login date
            if (isValid)
            {
                user.LastLoginDate = DateTime.UtcNow;
                this.Update(user);
            }

            return isValid;
        }

        #endregion
    }
}