﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain.Configuration;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Configuration
{
    /// <summary>The PreferenceService interface.</summary>
    public interface IPreferenceService : IEntityServiceBase<Preference>
    {
        #region Public Methods and Operators

        /// <summary>The get default location ids.</summary>
        /// <param name="defaultHomeLocationId">The default home location id.</param>
        /// <param name="defaultYardLocationId">The default yard location id.</param>
        /// <param name="defaultTerminalLocationId">The default terminal location id.</param>
        void GetDefaultLocationIds(
            out int? defaultHomeLocationId, out int? defaultYardLocationId, out int? defaultTerminalLocationId);

        /// <summary>The get preferences.</summary>
        /// <returns>The <see cref="Preference"/>.</returns>
        Preference GetPreferences();

        #endregion
    }

    /// <summary>The preference service.</summary>
    public class PreferenceService : EntityServiceBase<Preference>, IPreferenceService
    {
        #region Constructors and Destructors

        /// <summary>Initializes a new instance of the <see cref="PreferenceService"/> class.</summary>
        /// <param name="repository">The repository.</param>
        /// <param name="cacheManager">The cache manager.</param>
        public PreferenceService(IRepository<Preference> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>The get default location ids.</summary>
        /// <param name="defaultHomeLocationId">The default home location id.</param>
        /// <param name="defaultYardLocationId">The default yard location id.</param>
        /// <param name="defaultTerminalLocationId">The default terminal location id.</param>
        public void GetDefaultLocationIds(
            out int? defaultHomeLocationId, out int? defaultYardLocationId, out int? defaultTerminalLocationId)
        {
            Preference preference = this.GetPreferences();
            defaultHomeLocationId = preference.DefaultHomeLocationId;
            defaultYardLocationId = preference.DefaultYardLocationId;
            defaultTerminalLocationId = preference.DefaultTerminalLocationId;
        }

        /// <summary>The get preferences.</summary>
        /// <returns>The <see cref="Preference"/>.</returns>
        public Preference GetPreferences()
        {
            return this.Select().OrderByDescending(p => p.Id).Take(1).FirstOrDefault() ?? new Preference();
        }

        #endregion
    }
}