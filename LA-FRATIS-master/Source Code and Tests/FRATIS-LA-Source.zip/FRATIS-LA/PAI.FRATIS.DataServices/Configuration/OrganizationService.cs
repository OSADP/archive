﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Users;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Configuration
{
    public interface IOrganizationService : IEntityServiceBase<Organization>, IInstallableEntity
    {
        #region Public Methods and Operators

        Organization GetTerminal();

        #endregion
    }

    public class OrganizationService : EntityServiceBase<Organization>, IOrganizationService
    {
        #region Fields

        private readonly ILocationService _locationService;

        #endregion

        #region Constructors and Destructors

        public OrganizationService(
            IRepository<Organization> repository, ICacheManager cacheManager, ILocationService locationService)
            : base(repository, cacheManager)
        {
            this._locationService = locationService;
        }

        #endregion

        #region Public Methods and Operators

        public Organization GetTerminal()
        {
            return this.Select().FirstOrDefault(p => p.IsTerminal);
        }

        public void Install()
        {
            Location terminalLocation =
                this._locationService.Select().FirstOrDefault(p => p.DisplayName.StartsWith("Yusen"));
            if (terminalLocation != null)
            {
                Organization org = this.GetTerminal();
                if (org == null)
                {
                    org = new Organization { IsTerminal = true, LocationId = terminalLocation.Id };
                }
                else if (org.LocationId != terminalLocation.Id)
                {
                    org.LocationId = terminalLocation.Id;
                }

                InsertOrUpdate(org);
            }
        }

        #endregion
    }
}