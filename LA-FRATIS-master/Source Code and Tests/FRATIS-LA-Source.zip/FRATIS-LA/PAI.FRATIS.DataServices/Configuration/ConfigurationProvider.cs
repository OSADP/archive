﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using PAI.FRATIS.Infrastructure;

namespace PAI.FRATIS.DataServices.Configuration
{
    public class ConfigurationProvider<TSettings> : IConfigurationProvider<TSettings>
        where TSettings : class, new()
    {
        #region Fields

        private readonly ISettingService _settingService;

        #endregion

        #region Constructors and Destructors

        public ConfigurationProvider(ISettingService settingService)
        {
            this._settingService = settingService;
            this.BuildConfiguration();
        }

        #endregion

        #region Public Properties

        public TSettings Settings { get; protected set; }

        #endregion

        #region Public Methods and Operators

        public void BuildConfiguration()
        {
            this.Settings = Activator.CreateInstance<TSettings>();

            // get properties we can write to
            var properties = from prop in typeof(TSettings).GetProperties()
                             where prop.CanWrite && prop.CanRead
                             let setting =
                                 this._settingService.GetSettingByKey<string>(
                                     typeof(TSettings).Name + "." + prop.Name, this.IsPropertyEncrypted(prop))
                             where setting != null
                             where CommonHelper.GetCustomTypeConverter(prop.PropertyType).CanConvertFrom(typeof(string))
                             where CommonHelper.GetCustomTypeConverter(prop.PropertyType).IsValid(setting)
                             let value =
                                 CommonHelper.GetCustomTypeConverter(prop.PropertyType).ConvertFromInvariantString(
                                     setting)
                             select new { prop, value };

            foreach (var property in properties)
            {
                property.prop.SetValue(this.Settings, property.value, null);
            }
        }

        public bool IsPropertyEncrypted(PropertyInfo propertyInfo)
        {
            return propertyInfo.GetCustomAttributes(typeof(EncryptedSettingAttribute), false).FirstOrDefault() != null;
        }

        public void SaveSettings(TSettings settings)
        {
            IEnumerable<PropertyInfo> properties = from prop in typeof(TSettings).GetProperties()
                                                   where prop.CanWrite && prop.CanRead
                                                   where
                                                       CommonHelper.GetCustomTypeConverter(prop.PropertyType).
                                                       CanConvertFrom(typeof(string))
                                                   select prop;

            foreach (PropertyInfo prop in properties)
            {
                string key = typeof(TSettings).Name + "." + prop.Name;
                dynamic value = prop.GetValue(settings, null);

                this._settingService.SetSetting(key, value ?? "", this.IsPropertyEncrypted(prop), false);
            }

            this._settingService.ClearCache();

            this.Settings = settings;
        }

        #endregion
    }
}