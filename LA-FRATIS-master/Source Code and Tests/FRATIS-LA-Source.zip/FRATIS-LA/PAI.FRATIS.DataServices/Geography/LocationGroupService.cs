﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Geography
{
    /// <summary>The LocationGroupService interface.</summary>
    public interface ILocationGroupService : IEntityServiceBase<LocationGroup>, IInstallableEntity
    {
        #region Public Methods and Operators

        ICollection<LocationGroup> GetByIds(IEnumerable<int> ids);

        IQueryable<LocationGroup> GetByName(IEnumerable<string> names);

        ICollection<LocationGroup> GetHomeGroups();

        ICollection<LocationGroup> GetLocationGroups();

        ICollection<LocationGroup> GetLocationGroupsByParentId(int parentId);

        int GetTerminalLocationGroupId();

        #endregion
    }

    /// <summary>The location group service.</summary>
    public class LocationGroupService : EntityServiceBase<LocationGroup>, ILocationGroupService, IInstallableEntity
    {
        #region Constructors and Destructors

        /// <summary>Initializes a new instance of the <see cref="LocationGroupService"/> class.</summary>
        /// <param name="repository">The repository.</param>
        /// <param name="cacheManager">The cache manager.</param>
        public LocationGroupService(IRepository<LocationGroup> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        public ICollection<LocationGroup> GetByIds(IEnumerable<int> ids)
        {
            return this.Select().Where(m => ids.Contains(m.Id)).ToList();
        }

        public IQueryable<LocationGroup> GetByName(IEnumerable<string> names)
        {
            return this.Select().Where(p => names.Contains(p.Name));
        }

        public ICollection<LocationGroup> GetHomeGroups()
        {
            return this.Select().Where(p => p.IsHomeLocation).OrderBy(p => p.Name).Take(100).ToList();
        }

        /// <summary>The get location groups.</summary>
        /// <returns>The <see cref="ICollection"/>.</returns>
        public ICollection<LocationGroup> GetLocationGroups()
        {
            return this.Select().Take(100).ToList();
        }

        public ICollection<LocationGroup> GetLocationGroupsByParentId(int parentId)
        {
            return this.Select().Where(p => p.ParentId == parentId).ToList();
        }

        public int GetTerminalLocationGroupId()
        {
            return this.GetByName(new[] { "Terminal", "Marine Terminal" }).Select(p => p.Id).FirstOrDefault();
        }

        public void Install()
        {
            ICollection<LocationGroup> existingLocationGroups = this.GetLocationGroups();
            bool isChanged = false;

            foreach (LocationGroup lg in this.GetInternalLocationGroups())
            {
                LocationGroup x = existingLocationGroups.FirstOrDefault(p => p.Name.ToLower() == lg.Name.ToLower());
                if (x == null || x.Id == 0)
                {
                    // add new record
                    isChanged = true;
                    this.Insert(lg, false);
                }
            }

            if (isChanged)
            {
                this._repository.SaveChanges();
            }
        }

        #endregion

        #region Methods

        private IEnumerable<LocationGroup> GetInternalLocationGroups()
        {
            var locationGroups = new List<LocationGroup>
                {
                    new LocationGroup { Name = "Home", IsHomeLocation = true },
                    new LocationGroup { Name = "Yard", IsHomeLocation = true },
                    new LocationGroup { Name = "Customer", IsHomeLocation = false },
                    new LocationGroup { Name = "Terminal", IsHomeLocation = false },
                };

            return locationGroups;
        }

        #endregion
    }
}