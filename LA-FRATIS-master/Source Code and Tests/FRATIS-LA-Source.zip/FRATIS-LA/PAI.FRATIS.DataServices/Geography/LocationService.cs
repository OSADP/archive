﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.FRATIS.Wrappers.WebFleet.Model;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Geography
{
    public interface ILocationService : IEntityServiceBase<Location>, IInstallableEntity
    {
        #region Public Methods and Operators

        Location GetByDisplayName(string name);

        Location GetByIdWithAll(int id);

        IQueryable<Location> GetByLocationGroups(IEnumerable<int> allowedLocationGroupIds);

        Location GetByWebFleetId(string id);

        IEnumerable<Location> GetByWebFleetId(IEnumerable<string> ids);

        Location GetDefaultLocation(int locationGroupId);

        void Install(LocationGroup homeLocationGroup = null);

        IQueryable<Location> SelectWithAll();

        void SetLocationsInGroup(
            IEnumerable<Location> locations, LocationGroup group, bool removeExistingGroups = false);

        void SyncByWebFleetLocationId(string webFleetLocationId);

        #endregion
    }

    public class LocationService : EntityServiceBase<Location>, ILocationService, IInstallableEntity
    {
        #region Fields

        private readonly ILocationGroupService _locationGroupService;

        private readonly IWebFleetAddressService _webFleetAddressService;

        #endregion

        #region Constructors and Destructors

        public LocationService(
            IRepository<Location> repository,
            ICacheManager cacheManager,
            ILocationGroupService locationGroupService,
            IWebFleetAddressService webFleetAddressService)
            : base(repository, cacheManager)
        {
            this._locationGroupService = locationGroupService;
            this._webFleetAddressService = webFleetAddressService;
        }

        #endregion

        #region Public Methods and Operators

        public Location GetByDisplayName(string name)
        {
            return this.SelectWithAll().FirstOrDefault(f => f.DisplayName == name && f.IsDeleted == false);
        }

        public Location GetByIdWithAll(int id)
        {
            //var key = GetCacheKey(id);
            //if (_cacheManager.IsSet(key))
            //{
            //    return _cacheManager.Get<Location>(key);
            //}

            Location item = this.SelectWithAll().FirstOrDefault(m => m.Id == id);
            //_cacheManager.Set(key, item, 120);
            return item;
        }

        public IQueryable<Location> GetByLocationGroups(IEnumerable<int> allowedLocationGroupIds)
        {
            IQueryable<Location> result = from l in this._repository.SelectWith("LocationGroups", "HoursOfOperation")
                                          where
                                              (from lg in l.LocationGroups
                                               where l.IsDeleted == false && allowedLocationGroupIds.Contains(lg.Id)
                                               select lg).Any()
                                          select l;
            result = result.OrderBy(p => p.DisplayName);

            return result;
        }

        public Location GetByWebFleetId(string id)
        {
            return this.Select().FirstOrDefault(f => f.WebFleetId == id);
        }

        public IEnumerable<Location> GetByWebFleetId(IEnumerable<string> ids)
        {
            return this.SelectWithAll().Where(p => ids.Contains(p.WebFleetId));
        }

        public string GetCacheKey(int id)
        {
            return string.Format("loc-{0}", id);
        }

        /// <summary>
        /// Gets the First Location provided for the specified Home Location Group Id
        /// Does not work for non-home LocationGroups
        /// </summary>
        /// <param name="locationGroupId">Id for IsHome location group</param>
        /// <returns>Default Location if found, Null if not found or invalid</returns>
        public Location GetDefaultLocation(int locationGroupId)
        {
            Location result = null;
            LocationGroup lg = this._locationGroupService.GetById(locationGroupId);
            if (lg != null && lg.IsHomeLocation)
            {
                result = this.GetByLocationGroups(new[] { locationGroupId }).Take(1).OrderBy(p => p.Id).FirstOrDefault();
            }
            return result;
        }

        public void Install()
        {
            LocationGroup homeLocationGroup = this._locationGroupService.Select().FirstOrDefault(p => p.Name == "Home");
            if (homeLocationGroup == null)
            {
                this._locationGroupService.Install();
                homeLocationGroup = this._locationGroupService.Select().FirstOrDefault(p => p.Name == "Home");
            }

            this.Install(homeLocationGroup);
        }

        public void Install(LocationGroup homeLocationGroup = null)
        {
            Location homeLocation = this.Select().FirstOrDefault(p => p.DisplayName == "Home");
            if (homeLocation == null || !homeLocation.Latitude.HasValue || !homeLocation.Longitude.HasValue
                || (homeLocation.Longitude == 0 && homeLocation.Latitude == 0))
            {
                var defaultLocation = new Location
                    {
                        DisplayName = "Home",
                        City = "City of Industry",
                        State = "Florida",
                        StreetNumber = string.Empty,
                        Street = string.Empty,
                        Latitude = 34.0167,
                        Longitude = -117.9500,
                        Email = string.Empty,
                        Phone = string.Empty,
                        LocationGroups = new Collection<LocationGroup> { homeLocationGroup }
                    };

                this.Insert(defaultLocation, true);
            }
        }

        public IQueryable<Location> SelectWithAll()
        {
            return this._repository.SelectWith("LocationGroups", "HoursOfOperation").Where(p => p.IsDeleted == false);
        }

        public void SetLocationsInGroup(
            IEnumerable<Location> locations, LocationGroup group, bool removeExistingGroups = false)
        {
            foreach (Location location in locations)
            {
                if (location.LocationGroups == null)
                {
                    location.LocationGroups = new Collection<LocationGroup>();
                }

                if (removeExistingGroups)
                {
                    location.LocationGroups.Clear();
                }

                if (location.LocationGroups.FirstOrDefault(p => p.Id == group.Id) == null)
                {
                    location.LocationGroups.Add(group);
                    this.Update(location, false);
                }
            }

            this.SaveChanges();
        }

        /// <summary>
        /// Gets the Location with the provided WebFleetLocationId
        /// from WebFleet and updates or creates the Location
        /// record on the local repository
        /// </summary>
        /// <param name="webFleetLocationId"></param>
        public void SyncByWebFleetLocationId(string webFleetLocationId)
        {
            IDictionaryEnumerator enumerator = HttpContext.Current.Cache.GetEnumerator();
            while (enumerator.MoveNext())
            {
                HttpContext.Current.Cache.Remove(enumerator.Key.ToString());
            }

            WebFleetAddress address =
                this._webFleetAddressService.GetAddresses(webFleetLocationId).FirstOrDefault(
                    p => p.WebFleetId == webFleetLocationId);
            Location localAddress = this.Select().FirstOrDefault(p => p.WebFleetId == webFleetLocationId);

            if (address != null && address.WebFleetId.Length > 0)
            {
                if (address.StreetAddress != null && address.StreetNumber != null)
                {
                    if (address.StreetAddress.StartsWith(address.StreetNumber + " "))
                    {
                        address.StreetAddress =
                            address.StreetAddress.Substring(address.StreetNumber.ToString().Length + 1);
                    }
                }

                if (localAddress != null)
                {
                    localAddress.DisplayName = address.DisplayName;
                    localAddress.Longitude = address.Longitude;
                    localAddress.Latitude = address.Latitude;
                    localAddress.City = address.City;
                    localAddress.State = address.State;
                    localAddress.Zip = address.Zip;
                    localAddress.StreetAddress = address.StreetAddress;
                    localAddress.StreetNumber = address.StreetNumber.ToString(CultureInfo.InvariantCulture);
                    localAddress.Latitude = address.Latitude;
                    localAddress.Longitude = address.Longitude;
                    localAddress.Phone = address.Phone;
                    localAddress.Email = address.Email;
                    localAddress.LegacyId = address.WebFleetId;
                    localAddress.WebFleetId = address.WebFleetId;
                    localAddress.IsDeleted = false;

                    this.Update(localAddress, false);
                }
                else if (address.Latitude.HasValue && address.Longitude.HasValue)
                {
                    if (address.StreetAddress != null && address.StreetNumber != null)
                    {
                        if (address.StreetAddress.StartsWith(address.StreetNumber + " "))
                        {
                            address.StreetAddress =
                                address.StreetAddress.Substring(address.StreetNumber.ToString().Length + 1);
                        }
                    }

                    localAddress = new Location
                        {
                            DisplayName = address.DisplayName,
                            City = address.City,
                            State = address.State,
                            Zip = address.Zip,
                            StreetAddress = address.StreetAddress,
                            StreetNumber = address.StreetNumber.ToString(CultureInfo.InvariantCulture),
                            Latitude = address.Latitude,
                            Longitude = address.Longitude,
                            Phone = address.Phone,
                            Email = address.Email,
                            LegacyId = address.WebFleetId,
                            WebFleetId = address.WebFleetId
                        };

                    this.Insert(localAddress, false);
                }
            }

            this.SaveChanges();
        }

        public override void Update(Location entity, bool saveChanges = true)
        {
            base.Update(entity, saveChanges);

            string key = this.GetCacheKey(entity.Id);
            this._cacheManager.Set(key, entity, 900);
        }

        #endregion

        #region Methods

        protected override IQueryable<Location> InternalSelect()
        {
            return this._repository.Select();
        }

        private string GetCsvString(IEnumerable<int> values)
        {
            var sb = new StringBuilder();
            foreach (int i in values)
            {
                sb.Append(string.Format("{0},", i));
            }
            return sb.ToString();
        }

        #endregion
    }
}