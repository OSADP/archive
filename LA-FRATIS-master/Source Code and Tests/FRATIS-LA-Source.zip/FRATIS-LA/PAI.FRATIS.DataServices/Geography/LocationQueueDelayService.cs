﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Geography
{
    /// <summary>The LocationQueueDelayService interface.</summary>
    public interface ILocationQueueDelayService : IEntityServiceBase<LocationQueueDelay>
    {
        #region Public Methods and Operators

        IQueryable<LocationQueueDelay> GetByLocationId(int locationId);

        IQueryable<LocationQueueDelay> GetByLocationIds(IEnumerable<int> locationIds);

        IQueryable<LocationQueueDelay> SelectWithAll();

        void Update(DayOfWeek dayOfWeek, DateTime startTime, DateTime endTime, int delay);

        void UpdateIfExists(LocationQueueDelay entity);

        bool Validate(LocationQueueDelay entity);

        #endregion
    }

    /// <summary>The location group service.</summary>
    public class LocationQueueDelayService : EntityServiceBase<LocationQueueDelay>, ILocationQueueDelayService
    {
        #region Constructors and Destructors

        /// <summary>Initializes a new instance of the <see cref="LocationQueueDelayService"/> class.</summary>
        /// <param name="repository">The repository.</param>
        /// <param name="cacheManager">The cache manager.</param>
        public LocationQueueDelayService(IRepository<LocationQueueDelay> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        public IQueryable<LocationQueueDelay> GetByLocationId(int locationId)
        {
            return this.SelectWithAll().Where(p => p.LocationId == locationId);
        }

        public IQueryable<LocationQueueDelay> GetByLocationIds(IEnumerable<int> locationIds)
        {
            return this.SelectWithAll().Where(p => locationIds.Contains(p.LocationId.Value));
        }

        public IQueryable<LocationQueueDelay> SelectWithAll()
        {
            return this._repository.SelectWith(new[] { "Location" });
        }

        public void Update(DayOfWeek dayOfWeek, DateTime startTime, DateTime endTime, int delay)
        {
            LocationQueueDelay item =
                this.Select().FirstOrDefault(
                    p =>
                    p.DayOfWeek == (int)dayOfWeek
                    && (startTime.Ticks >= p.DelayStartTime && endTime.Ticks <= p.DelayEndTime))
                ?? new LocationQueueDelay();

            item.DayOfWeek = (int)dayOfWeek;
            item.DelayStartTime = startTime.Ticks;
            item.DelayEndTime = endTime.Ticks;
            item.QueueDelay = delay;

            InsertOrUpdate(item);
        }

        public void UpdateIfExists(LocationQueueDelay entity)
        {
        }

        public bool Validate(LocationQueueDelay entity)
        {
            bool result = true;
            if (entity != null && entity.LocationId.HasValue)
            {
                IQueryable<LocationQueueDelay> existingRecords = this.GetByLocationId(entity.LocationId.Value);
                foreach (LocationQueueDelay entry in existingRecords)
                {
                    if (entity.DelayStartTime >= entry.DelayStartTime && entity.DelayEndTime <= entry.DelayEndTime)
                    {
                        result = false;
                        break;
                    }
                }
            }
            return result;
        }

        #endregion
    }
}