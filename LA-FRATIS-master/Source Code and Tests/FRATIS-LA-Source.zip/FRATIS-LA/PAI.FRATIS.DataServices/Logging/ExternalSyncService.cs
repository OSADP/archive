﻿using System;
using System.Collections.Generic;
using System.Linq;

using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain.Logging;
using PAI.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Logging
{
    public interface IExternalSyncService : IEntityServiceBase<ExternalSync>
    {
        DateTime? GetLastSync(int organizationId);
        void SetLastSync(int id, DateTime? dt);
    }

    public class ExternalSyncService : EntityServiceBase<ExternalSync>, IExternalSyncService
    {
        /// <summary>
        /// Dictionary representing the cache for persisted entries
        /// </summary>
        private readonly Dictionary<int, DateTime?> _dict = new Dictionary<int, DateTime?>();

        public ExternalSyncService(IRepository<ExternalSync> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        public DateTime? GetLastSync(int id)
        {
            DateTime? result;
            if (!_dict.TryGetValue(id, out result))
            {
                var fetchedValue = GetPersistedTimeIfExists(id);
                _dict[id] = fetchedValue;
                result = fetchedValue;
            }
            return result;
        }


        /// <summary>
        /// Sets the TimeStamp for the provided organization
        /// Updates both cache and persisted object
        /// </summary>
        /// <param name="organizationName"></param>
        /// <param name="dt"></param>
        public void SetLastSync(int id, DateTime? dt)
        {
            var item = this.GetPersistedIfExists(id)
                       ?? new ExternalSync() { OrganizationId = id };
            
            item.TimeStamp = dt;
            InsertOrUpdate(item);
            _dict[id] = dt;
        }

        /// <summary>
        /// Gets the TimeStamp for the provided organization from the information store
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private DateTime? GetPersistedTimeIfExists(int id)
        {
            var item = this.GetPersistedIfExists(id);
            return item != null ? item.TimeStamp : null;
        }

        /// <summary>
        /// Gets the ExternalSync object, if it exists, for the provided
        /// organization name from the information store
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private ExternalSync GetPersistedIfExists(int id)
        {
            return Select().FirstOrDefault(p => p.OrganizationId == id);
        }
    }
}