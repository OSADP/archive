//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.Domain.Logging;
using PAI.FRATIS.Domain.Users;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Logging
{
    public class LogService : ILogService
    {
        #region Fields

        protected readonly IRepository<LogEntry> _repository;

        #endregion

        #region Constructors and Destructors

        public LogService(IRepository<LogEntry> repository)
        {
            this._repository = repository;
        }

        #endregion

        #region Public Methods and Operators

        public void Delete(LogEntry entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            this._repository.Delete(entity);
        }

        public IQueryable<LogEntry> GetAll()
        {
            return this._repository.Select();
        }

        public LogEntry GetById(int entityId)
        {
            return this._repository.GetById(entityId);
        }

        public void Insert(LogEntry entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            this._repository.Insert(entity);
        }

        public void InsertLog(LogLevel level, string message, string fullMessage, User user)
        {
            var logEntry = new LogEntry
                {
                    LogLevel = level,
                    Message = message,
                    FullMessage = fullMessage,
                    User = user,
                    AuditDate = DateTime.UtcNow
                };

            this.Insert(logEntry);
        }

        public bool IsEnabled(LogLevel level)
        {
            return true;
        }

        public void Update(LogEntry entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            this._repository.Update(entity);
        }

        #endregion
    }
}