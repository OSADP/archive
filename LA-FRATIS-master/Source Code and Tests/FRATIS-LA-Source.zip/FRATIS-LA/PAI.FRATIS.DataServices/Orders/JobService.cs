﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Common;
using System.Data.Objects;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.DateTimeService;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.FRATIS.Wrappers.WebFleet.Model;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Orders
{
    /// <summary>The JobService interface.</summary>
    public interface IJobService : IEntityServiceBase<Job>
    {
        #region Public Methods and Operators

        /// <summary>
        /// Adjusts a job for the provided shfit based upon predefined windows
        /// </summary>
        /// <param name="job"></param>
        /// <param name="shiftName"></param>
        /// <param name="saveNow"></param>
        void AdjustJobForShift(Job job, string shiftName, bool saveNow = true);

        /// <summary>
        /// Adjusts the route stop for the provided shift name based upon predefined windows
        /// </summary>
        /// <param name="rs"></param>
        /// <param name="shiftName"></param>
        /// <param name="saveNow"></param>
        void AdjustRouteStopForShift(RouteStop rs, string shiftName, bool saveNow = true);

        /// <summary>Manually assigns a job to the provided driver.</summary>
        /// <param name="jobId">The job id.</param>
        /// <param name="assignedDriverId">The assigned driver id.</param>
        /// <param name="assignedUserId">The assigned user id.</param>
        /// <param name="isJobPairAssignment">The is job pair assignment.</param>
        /// <param name="driverJobIdSequence">The driver job id sequence.</param>
        void Assign(
            int jobId,
            int? assignedDriverId,
            int assignedUserId,
            bool isJobPairAssignment = false,
            IList<int> driverJobIdSequence = null);

        /// <summary>The clear job.</summary>
        /// <param name="jobId">The job id.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        bool ClearJob(int jobId);

        /// <summary>
        /// Clones a job
        /// </summary>
        /// <param name="job"></param>
        /// <param name="dueDate"></param>
        /// <param name="cloneRouteStops"></param>
        /// <param name="orderNumber"></param>
        /// <param name="copyJobPairId"></param>
        /// <param name="jobGroupIdOverride"></param>
        /// <param name="templateType"></param>
        /// <param name="copyDriverAssignment"></param>
        /// <param name="copyPickNumber"></param>
        /// <param name="copyBookingNumber"></param>
        /// <param name="copyOrderNumber"></param>
        /// <returns></returns>
        Job Clone(
            Job job,
            DateTime? dueDate,
            bool cloneRouteStops = true,
            string orderNumber = "",
            bool copyJobPairId = false,
            int? jobGroupIdOverride = null,
            JobTemplateType templateType = JobTemplateType.Unspecified,
            bool copyDriverAssignment = true,
            bool copyPickNumber = true,
            bool copyBookingNumber = true,
            bool copyOrderNumber = true);

        /// <summary>The create default route stops.</summary>
        /// <param name="job">The job.</param>
        /// <param name="orderType">The order type.</param>
        /// <param name="clearPreviousRouteStops">The clear previous route stops.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        bool CreateDefaultRouteStops(
            Job job,
            int? shipperLocationId,
            int? consigneeLocationId,
            JobTemplateType orderType,
            bool clearPreviousRouteStops = false);

        /// <summary>
        /// Creates a job from template
        /// </summary>
        /// <param name="job"></param>
        /// <param name="type"></param>
        /// <param name="shipperLocationId"></param>
        /// <param name="consigneeLocationId"></param>
        /// <param name="containerNumber"></param>
        /// <param name="yardPull"></param>
        /// <param name="emptyMove"></param>
        /// <param name="homeLocationId"></param>
        /// <param name="yardLocationId"></param>
        /// <param name="terminalLocationId"></param>
        /// <returns></returns>
        ICollection<Job> CreateJobsTemplate(
            Job job,
            JobTemplateType type,
            int? shipperLocationId,
            int? consigneeLocationId,
            string containerNumber,
            bool yardPull,
            bool emptyMove,
            int? homeLocationId = null,
            int? yardLocationId = null,
            int? terminalLocationId = null);

        /// <summary>
        /// Permanently deletes the provided Job ignoring the IsDeleted property
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="saveChanges"></param>
        void DeletePermanently(Job entity, bool saveChanges);

        HashSet<int> GetAssignedDriverIds(DateTime? dueDate, int jobGroupId);

        /// <summary>The get by id with all.</summary>
        /// <param name="entityId">The entity id.</param>
        /// <returns>The <see cref="Job"/>.</returns>
        Job GetByIdWithAll(int entityId);

        /// <summary>The get by job pair id.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="ICollection"/>.</returns>
        ICollection<Job> GetByJobPairId(int id);

        /// <summary>
        /// Gets a job by order numeber
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <returns></returns>
        Job GetByOrderNumber(string orderNumber);

        /// <summary>
        /// Gets jobs assigned to a driver
        /// </summary>
        /// <param name="driverId"></param>
        /// <param name="dueDate"></param>
        /// <param name="jobGroupId"></param>
        /// <returns></returns>
        IEnumerable<Job> GetDriverJobs(int driverId, DateTime? dueDate, int? jobGroupId);

        /// <summary>
        /// Gets all locations specified within the provided job's route stops
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        ICollection<Location> GetJobLocations(Job job);

        /// <summary>
        /// Gets enum representation of the status provided as string
        /// </summary>
        /// <param name="statusString"></param>
        /// <returns></returns>
        JobStatus GetJobStatus(string statusString);

        /// <summary>The get job template type.</summary>
        /// <param name="name">The name.</param>
        /// <returns>The <see cref="JobTemplateType"/>.</returns>
        JobTemplateType GetJobTemplateType(string name);

        /// <summary>Gets a collection of jobs based on the specified ids.</summary>
        /// <param name="ids">The ids of the jobs to be fetched.</param>
        /// <returns>The <see cref="ICollection"/>.</returns>
        ICollection<Job> GetJobs(IEnumerable<int> ids);

        /// <summary>The get order type.</summary>
        /// <param name="orderTypString">The order type string.</param>
        /// <returns>The <see cref="NewOrderType"/>.</returns>
        NewOrderType GetOrderType(string orderTypString);

        /// <summary>The get orders.</summary>
        /// <param name="startDateRange">The start date range.</param>
        /// <param name="endDateRange">The end date range.</param>
        /// <param name="jobGroupId">The job group id.</param>
        /// <param name="showUnassignedOrders">The show unassigned orders.</param>
        /// <param name="showAssignedOrders">The show assigned orders.</param>
        /// <returns>The <see cref="IQueryable"/>.</returns>
        IQueryable<Job> GetOrders(
            DateTime? startDateRange,
            DateTime? endDateRange,
            int? jobGroupId = 0,
            bool showUnassignedOrders = true,
            bool showAssignedOrders = true);

        /// <summary>The get preparatory orders.</summary>
        /// <returns>The <see cref="ICollection"/>.</returns>
        ICollection<Job> GetPreparatoryOrders();

        void InsertOrUpdateRouteStop(RouteStop entity, bool saveChanges = true);

        /// <summary>
        /// Determines if the provided order number is unique
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        bool IsOrderNumberUnique(string orderNumber, bool? isDeleted = null);

        /// <summary>
        /// Marks the provided job as completed
        /// </summary>
        /// <param name="job"></param>
        /// <param name="userId"></param>
        /// <param name="completedDate"></param>
        /// <param name="saveNow"></param>
        void MarkCompleted(Job job, int userId, DateTime? completedDate, bool saveNow = true);

        /// <summary>
        /// Marks the provided job as IsTransmitted
        /// </summary>
        /// <param name="job"></param>
        void MarkTransmitted(Job job);

        /// <summary>The reorder stops.</summary>
        /// <param name="job">The job.</param>
        /// <param name="saveNow">The save now.</param>
        void ReorderStops(Job job, bool saveNow = false);

        /// <summary>The select with all.</summary>
        /// <returns>The <see cref="IQueryable"/>.</returns>
        IQueryable<Job> SelectWithAll();

        void SetIsTerminalJob(int jobId);

        /// <summary>
        /// Set the validity status of a job
        /// </summary>
        /// <param name="job"></param>
        /// <param name="value"></param>
        /// <param name="saveNow"></param>
        void SetIsValid(Job job, bool value, bool saveNow = true);

        /// <summary>The update job pair details.</summary>
        /// <param name="jobPairId">The job pair id.</param>
        /// <param name="containerOwnerId">The container owner id.</param>
        /// <param name="containerId">The container id.</param>
        /// <param name="chassisId">The chassis id.</param>
        void UpdateJobPairDetails(
            int jobPairId,
            int? containerOwnerId,
            int? containerId,
            int? chassisId,
            string pickupNumber,
            string bookingNumber,
            string containerNumber,
            string billOfLading);

        /// <summary>
        /// Update job status
        /// </summary>
        /// <param name="job"></param>
        /// <param name="status"></param>
        /// <param name="saveNow"></param>
        void UpdateJobStatus(Job job, JobStatus status, bool saveNow = true);

        void UpdateWeeklyOrderStatus();

        #endregion
    }

    /// <summary>The job service.</summary>
    public class JobService : EntityServiceBase<Job>, IJobService
    {
        #region Fields

        private readonly IDateTimeHelper _dateTimeHelper;

        private readonly IJobDataCollectionService _jobDataCollectionService;

        private readonly IJobGroupService _jobGroupService;

        private readonly ILocationDistanceService _locationDistanceService;

        private readonly ILocationGroupService _locationGroupService;

        /// <summary>The location service.</summary>
        private readonly ILocationService _locationService;

        /// <summary>The route stop service.</summary>
        private readonly IRouteStopService _routeStopService;

        /// <summary>The stop action service.</summary>
        private readonly IStopActionService _stopActionService;

        private readonly IWebFleetOrderService _webFleetOrderService;

        #endregion

        #region Constructors and Destructors

        /// <summary>Initializes a new instance of the <see cref="JobService"/> class.</summary>
        /// <param name="repository">The repository.</param>
        /// <param name="cacheManager">The cache manager.</param>
        /// <param name="routeStopService">The route stop service.</param>
        /// <param name="stopActionService">The stop action service.</param>
        public JobService(
            IRepository<Job> repository,
            ICacheManager cacheManager,
            IRouteStopService routeStopService,
            IStopActionService stopActionService,
            IJobGroupService jobGroupService,
            IDateTimeHelper dateTimeHelper,
            IJobDataCollectionService jobDataCollectionService,
            ILocationDistanceService locationDistanceService,
            IWebFleetOrderService webFleetOrderService,
            ILocationGroupService locationGroupService)
            : base(repository, cacheManager)
        {
            this._routeStopService = routeStopService;
            this._stopActionService = stopActionService;
            this._jobGroupService = jobGroupService;
            this._dateTimeHelper = dateTimeHelper;
            this._jobDataCollectionService = jobDataCollectionService;
            this._locationDistanceService = locationDistanceService;
            this._webFleetOrderService = webFleetOrderService;
            this._locationGroupService = locationGroupService;
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>The get value of.</summary>
        /// <param name="enumName">The enum name.</param>
        /// <param name="enumConst">The enum const.</param>
        /// <returns>The <see cref="int"/>.</returns>
        /// <exception cref="ArgumentException"></exception>
        public static int GetValueOf(string enumName, string enumConst)
        {
            Type enumType = Type.GetType(enumName);
            if (enumType == null)
            {
                throw new ArgumentException("Specified enum type could not be found", "enumName");
            }

            object value = Enum.Parse(enumType, enumConst);
            return Convert.ToInt32(value);
        }

        public void AdjustJobForShift(Job job, string shiftName, bool saveNow = true)
        {
            if (job == null)
            {
                return;
            }
            foreach (RouteStop rs in job.RouteStops)
            {
                this.AdjustRouteStopForShift(rs, shiftName, false);
            }

            if (saveNow)
            {
                InsertOrUpdate(job);
            }
        }

        /// <summary>
        /// Adjusts the routestop default time windows for the provided shift name
        /// </summary>
        /// <param name="rs"></param>
        /// <param name="shiftName"></param>
        /// <param name="saveNow"></param>
        public void AdjustRouteStopForShift(RouteStop rs, string shiftName, bool saveNow = true)
        {
            if (rs == null)
            {
                return;
            }
            switch (shiftName.ToLower())
            {
                case "morning":
                    rs.WindowStart = new TimeSpan(3, 0, 0).Ticks;
                    rs.WindowEnd = new TimeSpan(18, 0, 0).Ticks;
                    break;

                case "evening":
                    rs.WindowStart = new TimeSpan(18, 0, 0).Ticks;
                    rs.WindowEnd = new TimeSpan(1, 3, 0, 0).Ticks;
                    break;

                default:
                    rs.WindowStart = TimeSpan.Zero.Ticks;
                    rs.WindowEnd = new TimeSpan(23, 59, 0).Ticks;
                    break;
            }
        }

        public void Assign(
            int jobId,
            int? assignedDriverId,
            int assignedUserId,
            bool isJobPairAssignment = false,
            IList<int> driverJobIdSequence = null)
        {
            Job job = this.GetById(jobId);

            if (job != null)
            {
                ICollection<Job> jobs = new[] { job };
                if (isJobPairAssignment && job.JobPairId.HasValue && job.JobPairId > 0)
                {
                    jobs = this.GetByJobPairId(job.JobPairId.Value);
                }

                foreach (Job j in jobs)
                {
                    j.AssignedDriverId = assignedDriverId;
                    j.AssignedDateTime = DateTime.UtcNow;
                    j.JobStatus = JobStatus.Assigned;

                    if (driverJobIdSequence != null)
                    {
                        j.DriverSortOrder = driverJobIdSequence.IndexOf(job.Id) + 1;
                    }

                    this._jobDataCollectionService.Add(j, assignedUserId, j.AssignedDriverId);

                    this.Update(j, false);
                }

                int jobCount = 0;
                if (driverJobIdSequence != null)
                {
                    foreach (Job j in this.GetJobs(driverJobIdSequence))
                    {
                        j.DriverSortOrder = jobCount++;
                        this.Update(j, false);
                    }
                }

                this.SaveChanges();
            }
        }

        /// <summary>
        /// Deletes all associations to this job
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public bool ClearJob(int jobId)
        {
            bool ret = true;

            return ret;
        }

        public Job Clone(
            Job job,
            DateTime? dueDate,
            bool cloneRouteStops = true,
            string orderNumber = "",
            bool copyJobPairId = false,
            int? jobGroupIdOverride = null,
            JobTemplateType templateType = JobTemplateType.Unspecified,
            bool copyDriverAssignment = true,
            bool copyPickNumber = true,
            bool copyBookingNumber = true,
            bool copyOrderNumber = true)
        {
            if (job == null)
            {
                return null;
            }
            //job = GetByIdWithAll(job.Id);

            // create the new Job
            var clonedJob = new Job
                {
                    DueDate = dueDate,
                    JobGroupId = jobGroupIdOverride > 0 ? jobGroupIdOverride : job.JobGroupId,
                    ChassisId = job.ChassisId,
                    ChassisOwnerId = job.ChassisOwnerId,
                    ContainerId = job.ContainerId,
                    ContainerOwnerId = job.ContainerOwnerId,
                    IsTransmitted = false,
                    JobStatus = JobStatus.Unassigned,
                };

            if (clonedJob.JobGroupId.HasValue && clonedJob.JobGroupId > 0
                && (clonedJob.JobGroup == null || clonedJob.JobGroup.Id != clonedJob.JobGroupId))
            {
                clonedJob.JobGroup = this._jobGroupService.GetById(clonedJob.JobGroupId.Value);
            }

            if (copyDriverAssignment)
            {
                clonedJob.AssignedDriverId = job.AssignedDriverId;
            }

            if (copyPickNumber)
            {
                clonedJob.PickupNumber = job.PickupNumber;
            }

            if (copyBookingNumber)
            {
                clonedJob.BookingNumber = job.BookingNumber;
            }

            if (copyOrderNumber)
            {
                clonedJob.OrderNumber = job.OrderNumber;
            }

            clonedJob.JobTemplateType = templateType != JobTemplateType.Unspecified ? templateType : job.JobTemplateType;

            if (clonedJob.JobTemplateType.ToString().ToLower().StartsWith("import"))
            {
                clonedJob.IsPreparatory = true;
            }

            if (jobGroupIdOverride.HasValue)
            {
                clonedJob.JobGroupId = jobGroupIdOverride;
            }

            if (copyJobPairId)
            {
                clonedJob.JobPairId = job.JobPairId;
            }

            if (orderNumber.Length > 0)
            {
                clonedJob.OrderNumber = orderNumber;
            }

            this.Insert(clonedJob);
            if (clonedJob.Id > 0)
            {
                clonedJob = this.GetById(clonedJob.Id);
            }

            var clonedRoutes = new List<RouteStop>();
            if (cloneRouteStops)
            {
                int count = 0;
                foreach (RouteStop route in job.RouteStops.OrderBy(rs => rs.SortOrder))
                {
                    int minutes = 30;
                    if (route.StopDelay.HasValue && route.StopDelay.Value > 0)
                    {
                        minutes = (int)route.StopDelay.Value;
                    }

                    clonedRoutes.Add(
                        CreateJobRouteStop(
                            clonedJob,
                            count++,
                            route.LocationId,
                            minutes,
                            route.StopActionId,
                            route.WindowStart,
                            route.WindowEnd,
                            false));
                }

                for (int i = 0; i < clonedRoutes.Count; i++)
                {
                    RouteStop route = clonedRoutes[i];
                    clonedJob.RouteStops.Add(route);
                    this._routeStopService.Insert(route);
                }
            }

            this.Update(clonedJob);
            clonedJob = this.GetById(clonedJob.Id);

            return clonedJob;
        }

        public bool CreateDefaultRouteStops(
            Job job,
            int? shipperLocationId,
            int? consigneeLocationId,
            JobTemplateType orderType,
            bool clearPreviousRouteStops = false)
        {
            bool result = true;

            job.JobTemplateType = orderType;

            if (true) //if (orderType > 0)
            {
                if (clearPreviousRouteStops && job.RouteStops.Count > 0)
                {
                    job.RouteStops.Clear();
                }

                switch (orderType)
                {
                    case JobTemplateType.Import:
                        this.AddRouteStop(job, "PLWC", shipperLocationId, 120, 0, 0);
                        this.AddRouteStop(job, "DLWC", consigneeLocationId, 30, 0, 0);
                        break;

                    case JobTemplateType.Export:
                        this.AddRouteStop(job, "PLWC", shipperLocationId, 30, 0, 0);
                        this.AddRouteStop(job, "DLWC", consigneeLocationId, 120, 0, 0);
                        break;

                    case JobTemplateType.ImportLiveUnload:
                        this.AddRouteStop(job, "PLWC", shipperLocationId, 120, 0, 0);
                        this.AddRouteStop(job, "LU", consigneeLocationId, 30, 0, 0);
                        this.AddRouteStop(job, "DEWC", shipperLocationId, 30, 0, 0);
                        break;

                    case JobTemplateType.ExportLiveLoad:
                        this.AddRouteStop(job, "PEWC", null, 30, 0, 0);
                        this.AddRouteStop(job, "LL", shipperLocationId, 30, 0, 0);
                        this.AddRouteStop(job, "DLWC", consigneeLocationId.Value, 120, 0, 0);
                        break;

                    default:
                        result = false;
                        break;
                }
            }
            else
            {
                result = false;
            }
            return result;
        }

        /// <summary>The create jobs template.</summary>
        /// <param name="job">The job.</param>
        /// <param name="type">The type.</param>
        /// <param name="yardPull">The yard pull.</param>
        /// <param name="emptyMove">The empty move.</param>
        /// <param name="homeLocation">The home location.</param>
        /// <returns>The <see cref="ICollection"/>.</returns>
        public ICollection<Job> CreateJobsTemplate(
            Job job,
            JobTemplateType type,
            int? shipperLocationId,
            int? consigneeLocationId,
            string containerNumber,
            bool yardPull,
            bool emptyMove,
            int? homeLocationId = null,
            int? yardLocationId = null,
            int? terminalLocationId = null)
        {
            Job job1 = null, job2 = null, job3 = null;
            var result = new List<Job>();
            if (job != null)
            {
                job.JobTemplateType = type;

                if (job.JobTemplateType.ToString().ToLower().StartsWith("import"))
                {
                    job.IsPreparatory = true;
                }

                int? deducedTerminalLocationId, deducedCustomerLocationId, deducedYardLocationId;
                this.GetJobLocations(
                    job, out deducedTerminalLocationId, out deducedCustomerLocationId, out deducedYardLocationId);

                if (deducedTerminalLocationId.HasValue)
                {
                    terminalLocationId = deducedTerminalLocationId.Value;
                }

                if (homeLocationId.HasValue)
                {
                    if (!yardLocationId.HasValue || yardLocationId == 0)
                    {
                        yardLocationId = homeLocationId;
                    }
                }

                if (yardPull)
                {
                    int yardPullJobGroupOverride =
                        this._jobGroupService.GetByName(new[] { "Evening" }).Select(p => p.Id).FirstOrDefault();

                    if (job.JobTemplateType.ToString().StartsWith("Import"))
                    {
                        job1 = this.Clone(
                            job,
                            this.DateTimeAddDays(job.DueDate, -1),
                            false,
                            job.OrderNumber + "-YP",
                            true,
                            yardPullJobGroupOverride);

                        this.AddRouteStop(
                            job1, this._stopActionService.GetByShortName("PLWC").Id, terminalLocationId, 120, 0, 0);
                        this.AddRouteStop(
                            job1, this._stopActionService.GetByShortName("DLWC").Id, yardLocationId, 30, 0, 0);
                        result.Add(job1);

                        job2 = this.Clone(job, job.DueDate, true, string.Empty, true);
                        job2.RouteStops.First().LocationId = yardLocationId;
                        result.Add(job2);
                    }
                    else if (job.JobTemplateType.ToString().StartsWith("Export"))
                    {
                        // yard pull does not exist for exports
                    }
                }

                if (emptyMove)
                {
                    Job nextJob = null;

                    if (job.JobTemplateType.ToString().StartsWith("Import"))
                    {
                        if (result.Count == 0 && job.JobTemplateType.ToString().StartsWith("Export") == false)
                        {
                            job1 = this.Clone(job, job.DueDate, true, string.Empty, true);
                            result.Add(job1);
                        }

                        int? lastLocationId = result.Last().RouteStops.Last().LocationId;

                        nextJob = this.Clone(job, null, false, job.OrderNumber + "-I", true);

                        this.AddRouteStop(
                            nextJob, this._stopActionService.GetByShortName("PEWC").Id, lastLocationId, 30, 0, 0, job);
                        this.AddRouteStop(
                            nextJob,
                            this._stopActionService.GetByShortName("DEWC").Id,
                            terminalLocationId,
                            120,
                            0,
                            0,
                            job);
                    }
                    else if (job.JobTemplateType.ToString().StartsWith("Export"))
                    {
                        job1 = this.Clone(
                            job, this.DateTimeAddDays(job.DueDate, -1), false, job.OrderNumber + "-E", true);
                        this.AddRouteStop(
                            job1, this._stopActionService.GetByShortName("PEWC").Id, terminalLocationId, 60, 0, 0);
                        this.AddRouteStop(
                            job1,
                            this._stopActionService.GetByShortName("DEWC").Id,
                            job.RouteStops.First().LocationId,
                            30,
                            0,
                            0);
                        result.Add(job1);

                        nextJob = this.Clone(job, job.DueDate, true, string.Empty, true);
                        nextJob.RouteStops.First().LocationId = job1.RouteStops.Last().LocationId;
                        nextJob.RouteStops.Last().StopDelay = 60; // DEWC, 60 minutes hard coded
                        result.Add(nextJob);
                    }
                    else
                    {
                        // custom job
                        nextJob = this.Clone(job, job.DueDate, false, job.OrderNumber + "-EMPTY", true);
                        this.AddRouteStop(nextJob, null, yardLocationId, 30, 0, 0);
                        this.AddRouteStop(nextJob, null, deducedCustomerLocationId, 30, 0, 0);
                    }
                    result.Add(nextJob);
                }
                else if (job.JobTemplateType.ToString().StartsWith("Export"))
                {
                    // export without empty move
                    job.RouteStops.Last().StopDelay = 120;
                }
            }

            if (type == JobTemplateType.Unspecified && result.Count == 1)
            {
                // custom job, just add the locations to the route stops without actions
                this.AddRouteStop(result[0], null, shipperLocationId, 30, 0, 0);
                this.AddRouteStop(result[0], null, consigneeLocationId, 30, 0, 0);
            }

            int pairId = 0;
            for (int i = 0; i < result.Count; i++)
            {
                if (i == 0)
                {
                    pairId = result[i].Id;
                }

                result[i].JobTemplateType = type;
                result[i].JobPairId = pairId;
                result[i].ContainerNumber = containerNumber;
                this.Update(result[i], false);
            }

            this.SaveChanges();

            return result;
        }

        public override void Delete(Job entity, bool saveChanges = true)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            // Mark deleted instead
            entity.IsDeleted = true;
            this._repository.Update(entity, saveChanges);

            // remove entity from cache
            if (this._enableCaching)
            {
                this._cacheManager.RemoveByPattern(string.Format(this.CacheByIdPatternKey, entity.Id));
            }
        }

        public void DeletePermanently(Job entity, bool saveChanges)
        {
            if (entity != null)
            {
                this._repository.Delete(entity, saveChanges);
            }
        }

        public HashSet<int> GetAssignedDriverIds(DateTime? dueDate, int jobGroupId)
        {
            return
                new HashSet<int>(
                    this.GetOrders(dueDate, dueDate, jobGroupId).Where(p => p.AssignedDriverId != null).Select(
                        p => p.Id));
        }

        /// <summary>The get by id with all.</summary>
        /// <param name="entityId">The entity id.</param>
        /// <returns>The <see cref="Job"/>.</returns>
        public Job GetByIdWithAll(int entityId)
        {
            Job result = this.SelectWithAll().FirstOrDefault(entity => entity.Id == entityId);
            if (result != null && result.RouteStops != null)
            {
                result.RouteStops = result.RouteStops.OrderBy(p => p.SortOrder).ToList();
            }
            return result;
        }

        public ICollection<Job> GetByJobPairId(int id)
        {
            return this.SelectWithAll().Where(m => m.JobPairId == id).ToList();
        }

        public Job GetByOrderNumber(string orderNumber)
        {
            return this.SelectWithAll().FirstOrDefault(p => p.OrderNumber == orderNumber);
        }

        public IEnumerable<Job> GetDriverJobs(int driverId, DateTime? dueDate, int? jobGroupId)
        {
            return
                this.Select().Where(
                    p => p.AssignedDriverId == driverId && p.DueDate == dueDate && p.JobGroupId == jobGroupId).OrderBy(
                        p => p.DriverSortOrder).ThenBy(p => p.Id);
        }

        public ICollection<Location> GetJobLocations(Job job)
        {
            var result = new List<Location>();

            if (job != null)
            {
                if (job.RouteStops == null && job.Id > 0)
                {
                    job = this.GetByIdWithAll(job.Id);
                }

                if (job.RouteStops != null)
                {
                    result = job.RouteStops.Select(p => p.Location).ToList();
                }
            }
            return result;
        }

        public JobStatus GetJobStatus(string statusString)
        {
            IEnumerable<JobStatus> values = Enum.GetValues(typeof(JobStatus)).Cast<JobStatus>();
            return values.FirstOrDefault(status => statusString == status.ToString());
        }

        /// <summary>The get job template type.</summary>
        /// <param name="name">The name.</param>
        /// <returns>The <see cref="JobTemplateType"/>.</returns>
        public JobTemplateType GetJobTemplateType(string name)
        {
            try
            {
                object value = Enum.Parse(typeof(JobTemplateType), name.Replace(" ", string.Empty), true);
                return (JobTemplateType)value;
            }
            catch (Exception ex)
            {
                return JobTemplateType.Unspecified;
            }
        }

        public ICollection<Job> GetJobs(IEnumerable<int> ids)
        {
            List<Job> query = this.Select().Where(p => ids.Contains(p.Id)).ToList();
            return ids.Select(id => query.FirstOrDefault(p => p.Id == id)).Where(item => item != null).ToList();
        }

        public NewOrderType GetOrderType(string orderTypString)
        {
            switch (orderTypString.ToLower())
            {
                case "import":
                    return NewOrderType.Import;

                case "export":
                    return NewOrderType.Export;

                case "import live unload":
                    return NewOrderType.ImportLiveUnload;

                case "export live load":
                    return NewOrderType.ExportLiveLoad;

                default:
                    return NewOrderType.Custom;
            }
        }

        /// <summary>The get orders.</summary>
        /// <param name="startDateRange">The start date range.</param>
        /// <param name="endDateRange">The end date range.</param>
        /// <param name="jobGroupId">The job group id.</param>
        /// <param name="unassignedOrdersOnly">The unassigned orders only.</param>
        /// <returns>The <see cref="IQueryable"/>.</returns>
        public IQueryable<Job> GetOrders(
            DateTime? startDateRange,
            DateTime? endDateRange,
            int? jobGroupId = 0,
            bool showUnassignedOrders = true,
            bool showAssignedOrders = true)
        {
            IQueryable<Job> query = this.SelectWithAll();

            if (!(showAssignedOrders && showUnassignedOrders))
            {
                if (showUnassignedOrders)
                {
                    query = query.Where(p => p.AssignedDriverId == null);
                }
                else if (showAssignedOrders)
                {
                    query = query.Where(p => p.AssignedDriverId != null);
                }
            }

            if (startDateRange.HasValue)
            {
                query = query.Where(p => p.DueDate >= startDateRange);
            }

            if (endDateRange.HasValue)
            {
                query = query.Where(p => p.DueDate <= endDateRange);
            }

            if (jobGroupId.HasValue && jobGroupId > 0)
            {
                query = query.Where(p => p.JobGroupId == jobGroupId);
            }

            List<Job> items = query.ToList();
            return query;
        }

        /// <summary>The get preparatory orders.</summary>
        /// <returns>The <see cref="ICollection"/>.</returns>
        public ICollection<Job> GetPreparatoryOrders()
        {
            return this.SelectWithAll().Where(m => m.IsDeleted == false && m.IsPreparatory).ToList();
        }

        public override void Insert(Job entity, bool saveChanges = true)
        {
            if (entity.JobStatus == JobStatus.Assigned && entity.DueDate.HasValue && !entity.IsDeleted)
            {
                Task.Factory.StartNew(
                    () =>
                        {
                            entity.LocationDistanceProcessedDate = null;
                            //_locationDistanceService.CreateEmptyRecords(entity.DueDate.Value, GetJobLocations(entity));
                        });
            }
            else if (entity.JobStatus == JobStatus.Unassigned)
            {
                entity.LocationDistanceProcessedDate = null;
            }

            if (entity.DataCollection == null)
            {
                entity.DataCollection = new JobDataCollection { };
            }

            IDictionaryEnumerator enumerator = HttpContext.Current.Cache.GetEnumerator();
            while (enumerator.MoveNext())
            {
                HttpContext.Current.Cache.Remove(enumerator.Key.ToString());
            }

            base.Insert(entity, saveChanges);
        }

        public void InsertOrUpdateRouteStop(RouteStop entity, bool saveChanges = true)
        {
            this._routeStopService.InsertOrUpdate(entity, saveChanges);

            if (entity.JobId.HasValue)
            {
                this.SetIsTerminalJob(entity.JobId.Value);
            }
        }

        /// <summary>
        /// Determines if the provided OrderNumber exists within a Job in the information store
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        public bool IsOrderNumberUnique(string orderNumber, bool? isDeleted = null)
        {
            return isDeleted.HasValue
                       ? this.Select().FirstOrDefault(
                           p =>
                           (p.OrderNumber == orderNumber || p.OrderNumber.StartsWith(orderNumber + "-"))
                           && p.IsDeleted == isDeleted) == null
                       : this.Select().FirstOrDefault(
                           p => (p.OrderNumber == orderNumber || p.OrderNumber.StartsWith(orderNumber + "-"))) == null;
        }

        public void MarkCompleted(Job job, int userId, DateTime? completedDate, bool saveNow = true)
        {
            if (job != null)
            {
                job.JobStatus = JobStatus.Completed;

                DateTime? utcCompletedDate = null;
                if (completedDate.HasValue)
                {
                    utcCompletedDate = this._dateTimeHelper.ConvertLocalToUtcTime(completedDate.Value.Date);
                }

                this._jobDataCollectionService.MarkCompleted(job, userId, utcCompletedDate); // saves job entity

                if (saveNow)
                {
                    this.Update(job);
                }
            }
        }

        public void MarkTransmitted(Job job)
        {
            job.IsTransmitted = true;
            this.Update(job);
        }

        public void ReorderStops(Job job, bool saveNow = false)
        {
            if (job != null && job.RouteStops != null)
            {
                int count = 0;
                foreach (RouteStop rs in job.RouteStops)
                {
                    rs.SortOrder = count;
                    count++;
                }
                InsertOrUpdate(job, saveNow);
            }
        }

        public IQueryable<Job> SelectWithAll()
        {
            return
                this._repository.SelectWith(
                    "Chassis",
                    "Container",
                    "ChassisOwner",
                    "ContainerOwner",
                    "RouteStops",
                    "RouteStops.Location",
                    "RouteStops.Location.LocationGroups",
                    "AssignedDriver",
                    "RouteStops.StopAction",
                    "JobGroup").Where(f => f.IsDeleted == false);
        }

        public void SetIsTerminalJob(int jobId)
        {
            int terminalLocationGroupId =
                this._locationGroupService.GetByName(new[] { "Terminal", "Marine Terminal" }).Select(p => p.Id).
                    FirstOrDefault();

            Job job = this.GetByIdWithAll(jobId);
            bool isTerminalJob = job.ContainsLocationGroup(terminalLocationGroupId);

            if (job.IsTerminalOrder != isTerminalJob)
            {
                job.IsTerminalOrder = isTerminalJob;
                this.Update(job);
            }
        }

        public void SetIsValid(Job job, bool value, bool saveNow = true)
        {
            if (job != null)
            {
                job.IsValid = value;
                InsertOrUpdate(job, saveNow);
            }
        }

        public override void Update(Job entity, bool saveChanges = true)
        {
            if (!entity.IsValid)
            {
                entity.LocationDistanceProcessedDate = null;
            }

            base.Update(entity, saveChanges);
        }

        public void UpdateJobPairDetails(
            int jobPairId,
            int? containerOwnerId,
            int? containerId,
            int? chassisId,
            string pickupNumber,
            string bookingNumber,
            string containerNumber,
            string billOfLading)
        {
            foreach (Job job in this.GetByJobPairId(jobPairId))
            {
                job.ContainerOwnerId = containerOwnerId;
                job.ContainerId = containerId;
                job.ChassisId = chassisId;
                job.BookingNumber = bookingNumber;
                job.PickupNumber = pickupNumber;
                job.ContainerNumber = containerNumber;
                job.BillOfLading = billOfLading;
                this.Update(job, false);
            }

            this.SaveChanges();
        }

        /// <summary>
        /// Updates the Job Status for a given order
        /// If the Job IsPreparatory, then a Transmitted or Pending status is not allowed
        /// </summary>
        /// <param name="job"></param>
        /// <param name="status"></param>
        /// <param name="saveNow"></param>
        public void UpdateJobStatus(Job job, JobStatus status, bool saveNow = true)
        {
            if (job != null && job.JobStatus != status)
            {
                job.JobStatus = status;
                InsertOrUpdate(job, saveNow);
            }
        }

        /// <summary>
        /// Queries WebFleet for Finished jobs in the last week,
        /// </summary>
        public void UpdateWeeklyOrderStatus()
        {
            ICollection<WebFleetOrder> webFleetOrders = this._webFleetOrderService.GetOrders(
                SelectionTimeSpan.ThisMonth);
            IEnumerable<WebFleetOrder> webFleetOrdersFinished =
                webFleetOrders.Where(p => p.OrderState == WebFleetOrderState.Finished);
            var completedJobIds = new HashSet<int>(); // job ids where all routestops are Finished

            foreach (WebFleetOrder order in webFleetOrdersFinished)
            {
                Job job = this.GetByOrderNumber(order.OrderNumberDetails.OrderNumber);
                if (job == null)
                {
                    continue;
                }

                if (job.JobStatus != JobStatus.Completed && !completedJobIds.Contains(job.Id)
                    && this.IsAllLegsOrOrderComplete(job, webFleetOrdersFinished))
                {
                    completedJobIds.Add(job.Id);
                    job.JobStatus = JobStatus.Completed;
                    this.Update(job, false);
                }
            }

            this.SaveChanges();
        }

        #endregion

        #region Methods

        protected override IQueryable<Job> InternalSelect()
        {
            return base.InternalSelect().Where(f => f.IsDeleted == false);
        }

        private void AddRouteStop(
            Job job, string stopAction, int? locationId, int stopDelay, long windowStart, long windowEnd)
        {
            StopAction sa = this._stopActionService.GetByShortName(stopAction);
            if (sa != null && sa.Id > 0)
            {
                AddRouteStop(job, sa.Id, locationId, stopDelay, windowStart, windowEnd);
            }
        }

        private void AddRouteStop(
            Job job,
            int stopActionId,
            int? locationId,
            int stopDelay,
            long windowStart,
            long windowEnd,
            Job previousJob = null)
        {
            string jobGroup = string.Empty;
            if (job != null && job.JobGroup != null)
            {
                jobGroup = job.JobGroup.Name;
            }

            if (job != null)
            {
                DateTime? jobDueDate = null;
                if (job.DueDate.HasValue)
                {
                    jobDueDate = job.DueDate;
                }
                else if (previousJob != null)
                {
                    jobDueDate = previousJob.DueDate;
                }

                if (job.RouteStops == null)
                {
                    job.RouteStops = new Collection<RouteStop>();
                }

                if (windowStart == 0)
                {
                    switch (jobGroup)
                    {
                        case "Morning":
                            windowStart = new TimeSpan(3, 0, 0).Ticks;
                            break;

                        case "Evening":
                            windowStart = new TimeSpan(18, 0, 0).Ticks;
                            break;
                    }
                }

                if (windowEnd == 0)
                {
                    switch (jobGroup)
                    {
                        case "Morning":
                            windowEnd = new TimeSpan(18, 0, 0).Ticks;
                            break;

                        case "Evening":
                            windowEnd = new TimeSpan(1, 3, 0, 0).Ticks;
                            break;

                        default:
                            windowEnd = new TimeSpan(23, 59, 0).Ticks;
                            break;
                    }
                }
                var routeStop = new RouteStop
                    {
                        JobId = job.Id,
                        StopActionId = stopActionId,
                        LocationId = locationId,
                        WindowStart = windowStart,
                        WindowEnd = windowEnd,
                        StopDelay = stopDelay,
                        SortOrder = job.RouteStops.Count
                    };
                job.RouteStops.Add(routeStop);
            }
        }

        private RouteStop CreateJobRouteStop(
            Job job,
            int sortOrder,
            int? locationId,
            int? minutes,
            int? stopActionId,
            long windowStart,
            long windowEnd,
            bool bSave = false)
        {
            if (job == null || job.Id == 0)
            {
                throw new Exception("Job is invalid");
            }
            var result = new RouteStop
                {
                    JobId = job.Id,
                    LocationId = locationId,
                    StopDelay = minutes,
                    StopActionId = stopActionId,
                    SortOrder = sortOrder,
                    WindowStart = windowStart,
                    WindowEnd = windowEnd,
                };

            if (bSave)
            {
                this._routeStopService.Insert(result);

                job.RouteStops.Add(result);
                this.Update(job);
                job = this.GetByIdWithAll(job.Id);
            }
            return result;
        }

        private RouteStop CreateJobRouteStop(
            Job job,
            int sortOrder,
            int? locationId,
            int? minutes,
            string actionShortName,
            long windowStart,
            long windowEnd,
            bool bSave = false)
        {
            StopAction sa = this._stopActionService.GetByShortName(actionShortName);
            if (sa == null)
            {
                throw new Exception("Unable to Fetch Stop Action: " + actionShortName);
            }

            return CreateJobRouteStop(job, sortOrder, locationId, minutes, sa.Id, windowStart, windowEnd, bSave);
        }

        /// <summary>The create template job from original.</summary>
        /// <param name="originalJob">The original job.</param>
        /// <param name="templateType">The template type.</param>
        /// <param name="leg">The leg.</param>
        /// <param name="yardPull">The yard pull.</param>
        /// <param name="emptyMove">The empty move.</param>
        /// <param name="terminalLocation">The terminal location.</param>
        /// <param name="customerLocation">The customer location.</param>
        /// <param name="yardLocation">The yard location.</param>
        private void CreateTemplateJobFromOriginal(
            Job originalJob,
            JobTemplateType templateType,
            int leg,
            bool yardPull,
            bool emptyMove,
            Location terminalLocation,
            Location customerLocation,
            Location yardLocation)
        {
            Job result = this.Clone(originalJob, originalJob.DueDate);
            result.RouteStops.Clear();
        }

        private DateTime? DateTimeAddDays(DateTime? dt, int days)
        {
            return dt.HasValue ? dt.Value.AddDays(days) : dt;
        }

        /// <summary>The get job locations.</summary>
        /// <param name="job">The job.</param>
        /// <param name="terminalLocationId">The terminal location id.</param>
        /// <param name="customerLocationId">The customer location id.</param>
        /// <param name="yardLocationId">The yard location id.</param>
        private void GetJobLocations(
            Job job, out int? terminalLocationId, out int? customerLocationId, out int? yardLocationId)
        {
            terminalLocationId = null;
            customerLocationId = null;
            yardLocationId = null;

            if (job != null && job.JobTemplateType > 0 && job.RouteStops != null && job.RouteStops.Count > 0)
            {
                switch (job.JobTemplateType)
                {
                    case JobTemplateType.Import:
                        if (job.RouteStops.Count >= 2)
                        {
                            terminalLocationId = job.RouteStops.First().LocationId;
                            customerLocationId = job.RouteStops.Last().LocationId;
                        }

                        break;

                    case JobTemplateType.ImportLiveUnload:
                        if (job.RouteStops.Count > 2)
                        {
                            terminalLocationId = job.RouteStops.First().LocationId;
                            customerLocationId = job.RouteStops[1].LocationId;
                        }

                        break;

                    case JobTemplateType.Export:
                        if (job.RouteStops.Count >= 2)
                        {
                            customerLocationId = job.RouteStops.First().LocationId;
                            terminalLocationId = job.RouteStops.Last().LocationId;
                        }

                        break;

                    case JobTemplateType.ExportLiveLoad:
                        if (job.RouteStops.Count > 2)
                        {
                            terminalLocationId = job.RouteStops.First().LocationId;
                            customerLocationId = job.RouteStops[1].LocationId;
                        }

                        break;
                }
            }
        }

        private int GetPropertyIndex(ObjectStateEntry entry, string propertyName)
        {
            OriginalValueRecord record = entry.GetUpdatableOriginalValues();

            for (int i = 0; i != record.FieldCount; i++)
            {
                FieldMetadata metaData = record.DataRecordInfo.FieldMetadata[i];
                if (metaData.FieldType.Name == propertyName)
                {
                    return metaData.Ordinal;
                }
            }
            return -1;
        }

        private bool IsAllLegsOrOrderComplete(Job job, IEnumerable<WebFleetOrder> webFleetOrders)
        {
            if (job == null && job.RouteStops == null)
            {
                return false;
            }
            foreach (RouteStop rs in job.RouteStops)
            {
                WebFleetOrder rsWebFleet =
                    webFleetOrders.FirstOrDefault(
                        p => p.OrderNumber == string.Format("{0}-{1}", job.OrderNumber, rs.Id));

                if (rsWebFleet == null || rsWebFleet.OrderState != WebFleetOrderState.Finished)
                {
                    return false;
                }
            }
            return true;
        }

        private bool IsDirtyProperty(ObjectContext ctx, object entity, string propertyName)
        {
            ObjectStateEntry entry;
            if (ctx.ObjectStateManager.TryGetObjectStateEntry(entity, out entry))
            {
                int propIndex = this.GetPropertyIndex(entry, propertyName);

                if (propIndex != -1)
                {
                    object oldValue = entry.OriginalValues[propIndex];
                    object newValue = entry.CurrentValues[propIndex];

                    return !Equals(oldValue, newValue);
                }
                else
                {
                    throw new ArgumentException(
                        String.Format(
                            "Cannot find original value for property '{0}' in entity entry '{1}'",
                            propertyName,
                            entry.EntitySet.ElementType.FullName));
                }
            }

            return false;
        }

        #endregion
    }
}