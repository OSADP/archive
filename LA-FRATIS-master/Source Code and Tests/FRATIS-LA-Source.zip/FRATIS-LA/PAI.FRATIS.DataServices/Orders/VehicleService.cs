﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Orders
{
    public interface IVehicleService : IEntityServiceBase<Vehicle>
    {
        #region Public Methods and Operators

        Vehicle GetByLegacyId(string legacyId);

        int? GetDriverId(int? vehicleId);

        int? GetVehicleId(int? driverId);

        IEnumerable<Vehicle> GetVehicles();

        IQueryable<Vehicle> SelectWithAll();

        #endregion
    }

    public class VehicleService : EntityServiceBase<Vehicle>, IVehicleService
    {
        #region Constructors and Destructors

        public VehicleService(IRepository<Vehicle> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        public Vehicle GetByLegacyId(string legacyId)
        {
            return this.SelectWithAll().FirstOrDefault(p => p.LegacyId == legacyId);
        }

        public int? GetDriverId(int? vehicleId)
        {
            if (vehicleId.HasValue)
            {
                Vehicle result = this.GetById(vehicleId.Value);
                return result != null ? result.DriverId : null;
            }
            return null;
        }

        public int? GetVehicleId(int? driverId)
        {
            if (driverId.HasValue)
            {
                Vehicle item = this.Select().FirstOrDefault(p => p.DriverId == driverId);
                if (item != null)
                {
                    return item.Id;
                }
            }

            return null;
        }

        public IEnumerable<Vehicle> GetVehicles()
        {
            return this.SelectWithAll().OrderBy(p => p.Name);
        }

        public override void Insert(Vehicle entity, bool saveChanges = true)
        {
            this.RemovePreviousDriverAssignmentIfAlreadyExists(entity, saveChanges);
            base.Insert(entity, saveChanges);
        }

        public IQueryable<Vehicle> SelectWithAll()
        {
            return this._repository.SelectWith("Driver");
        }

        public override void Update(Vehicle entity, bool saveChanges = true)
        {
            this.RemovePreviousDriverAssignmentIfAlreadyExists(entity, saveChanges);
            base.Update(entity, saveChanges);
        }

        #endregion

        #region Methods

        private void RemovePreviousDriverAssignmentIfAlreadyExists(Vehicle entity, bool saveChanges)
        {
            if (entity.DriverId.HasValue)
            {
                Vehicle existingVehicleWithDriverAssignment =
                    this.InternalSelect().FirstOrDefault(p => p.DriverId == entity.DriverId);

                if (existingVehicleWithDriverAssignment != null)
                {
                    existingVehicleWithDriverAssignment.DriverId = null;
                    this.Update(existingVehicleWithDriverAssignment, saveChanges);
                }
            }
        }

        #endregion
    }
}