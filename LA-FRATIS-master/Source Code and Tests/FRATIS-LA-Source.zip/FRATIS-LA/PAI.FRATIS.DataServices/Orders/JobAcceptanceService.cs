﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain.Orders;
using PAI.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Orders
{
    public interface IJobAcceptanceService : IEntityServiceBase<JobAcceptance>
    {
        
    }

    public class JobAcceptanceService : EntityServiceBase<JobAcceptance>, IJobAcceptanceService
    {
        public JobAcceptanceService(IRepository<JobAcceptance> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }
    }
}
