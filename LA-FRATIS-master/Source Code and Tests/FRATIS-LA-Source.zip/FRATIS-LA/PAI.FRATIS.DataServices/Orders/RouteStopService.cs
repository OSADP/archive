﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Orders
{
    public interface IRouteStopService : IEntityServiceBase<RouteStop>
    {
        #region Public Methods and Operators

        void DeleteByJobId(int jobId);

        IEnumerable<RouteStop> GetByJobId(int jobId);

        IEnumerable<Job> GetJobsByLocationGroup(int groupId);

        IEnumerable<Job> GetJobsWithLocation(
            IEnumerable<int?> locationIds, DateTime? dtSince = null, DateTime? dtUntil = null);

        IEnumerable<Job> GetJobsWithLocationBySyncDate(
            IEnumerable<int?> locationIds, DateTime? dtSince, DateTime? dtUntil);

        IQueryable<Job> GetJobsWithLocationQueryable(
            IEnumerable<int?> locationIds, DateTime? dtSince = null, DateTime? dtUntil = null);

        IEnumerable<int> GetLocationIds(DateTime startDateRange, DateTime endDateRange);

        IEnumerable<int> GetLocationIds(DateTime dueDate, int daysToInclude = 0, int? jobGroupId = null);

        IEnumerable<RouteStop> GetRouteStopsForJobs(IEnumerable<int?> jobIds);

        IEnumerable<RouteStop> GetRoutesWithLocation(
            IEnumerable<int?> locationIds, DateTime? dtSince = null, DateTime? dtUntil = null);

        #endregion
    }

    public class RouteStopService : EntityServiceBase<RouteStop>, IRouteStopService
    {
        #region Fields

        private readonly ILocationService _locationService;

        #endregion

        #region Constructors and Destructors

        public RouteStopService(
            IRepository<RouteStop> repository, ICacheManager cacheManager, ILocationService locationService)
            : base(repository, cacheManager)
        {
            this._locationService = locationService;
        }

        #endregion

        #region Public Methods and Operators

        public void DeleteByJobId(int jobId)
        {
            foreach (RouteStop rs in this.Select().Where(p => p.JobId == jobId).ToList())
            {
                Delete(rs, false);
            }

            this.SaveChanges();
        }

        public IEnumerable<RouteStop> GetByJobId(int jobId)
        {
            return
                this.InternalSelect().Where(m => m.JobId == jobId).OrderBy(m => m.SortOrder).ThenBy(m => m.Id).ToList();
        }

        public IEnumerable<Job> GetJobsByLocationGroup(int groupId)
        {
            IEnumerable<int?> locationIds =
                this._locationService.GetByLocationGroups(new[] { groupId }).Select(l => l.Id).ToList().Cast<int?>();

            List<Job> result =
                this.InternalSelect().Where(p => locationIds.Contains(p.LocationId)).Where(p => p.Job != null).Select(
                    p => p.Job).ToList();

            return result;
        }

        public IEnumerable<Job> GetJobsWithLocation(
            IEnumerable<int?> locationIds, DateTime? dtSince = null, DateTime? dtUntil = null)
        {
            return this.GetJobsWithLocationQueryable(locationIds, dtSince, dtUntil).ToList();
        }

        public IEnumerable<Job> GetJobsWithLocationBySyncDate(
            IEnumerable<int?> locationIds, DateTime? dtSince, DateTime? dtUntil)
        {
            return this.GetJobsWithLocation(locationIds, dtSince, dtUntil);
        }

        public IQueryable<Job> GetJobsWithLocationQueryable(
            IEnumerable<int?> locationIds, DateTime? dtSince = null, DateTime? dtUntil = null)
        {
            if (dtSince.HasValue == false)
            {
                return
                    this.InternalSelect().Where(p => locationIds.Contains(p.LocationId)).Where(p => p.Job != null).
                        Select(p => p.Job);
            }

            IQueryable<RouteStop> query =
                this.InternalSelect().Where(
                    p =>
                    locationIds.Contains(p.LocationId)
                    &&
                    ((p.CreatedDate >= dtSince.Value) || (p.ModifiedDate >= dtSince.Value)
                     || (p.Job.CreatedDate <= dtSince.Value || p.Job.ModifiedDate >= dtSince.Value)));

            if (dtUntil.HasValue)
            {
                query =
                    query.Where(
                        p =>
                        (p.CreatedDate <= dtUntil.Value) || (p.ModifiedDate <= dtUntil.Value)
                        || p.Job.CreatedDate <= dtUntil.Value || p.Job.ModifiedDate <= dtUntil.Value);
            }

            return query.Where(p => p.Job != null).Select(p => p.Job);
        }

        public IEnumerable<int> GetLocationIds(DateTime startDateRange, DateTime endDateRange)
        {
            return
                (IEnumerable<int>)
                this.InternalSelect().Where(
                    p => p.Job.DueDate >= startDateRange && p.Job.DueDate <= endDateRange && p.LocationId > 0).Select(
                        p => p.LocationId);
        }

        public IEnumerable<int> GetLocationIds(DateTime dueDate, int daysToInclude = 0, int? jobGroupId = null)
        {
            if (dueDate.Year == 1970 || dueDate.Year == 0001)
            {
                return new List<int>();
            }

            DateTime upperDate = dueDate.AddDays(daysToInclude);
            DateTime lowerDate = dueDate.AddDays(-daysToInclude);

            if (jobGroupId.HasValue)
            {
                return daysToInclude > 0
                           ? this.InternalSelect().Where(
                               p =>
                               p.Job.DueDate <= upperDate && p.Job.DueDate >= lowerDate
                               && p.Job.JobGroupId == jobGroupId.Value && p.LocationId > 0).Select(p => p.Location.Id)
                           : (IEnumerable<int>)
                             this.InternalSelect().Where(
                                 p =>
                                 p.Job.DueDate == dueDate && p.Job.JobGroupId == jobGroupId.Value && p.LocationId > 0).
                                 Select(p => p.LocationId);
            }

            return daysToInclude > 0
                       ? this.InternalSelect().Where(
                           p => p.Job.DueDate >= lowerDate && p.Job.DueDate <= upperDate && p.LocationId > 0).Select(
                               p => p.Location.Id)
                       : this.InternalSelect().Where(p => p.Job.DueDate == dueDate && p.LocationId > 0).Select(
                           p => p.Location.Id);
        }

        public IEnumerable<Job> GetPendingTerminalOrders(IEnumerable<int?> terminalLocationIds)
        {
            IEnumerable<Job> jobs = this.GetJobsWithLocation(terminalLocationIds);
            return jobs.Where(j => j.GetTerminalJobType(terminalLocationIds) != TerminalJobType.Unspecified).ToList();
        }

        public IEnumerable<RouteStop> GetRouteStopsForJobs(IEnumerable<int?> jobIds)
        {
            return this.InternalSelect().Where(p => jobIds.Contains(p.JobId)).ToList();
        }

        public IEnumerable<RouteStop> GetRoutesWithLocation(
            IEnumerable<int?> locationIds, DateTime? dtSince = null, DateTime? dtUntil = null)
        {
            if (dtSince.HasValue == false)
            {
                return this.InternalSelect().Where(p => locationIds.Contains(p.LocationId)).ToList();
            }

            IQueryable<RouteStop> query =
                this.InternalSelect().Where(
                    p =>
                    locationIds.Contains(p.LocationId) && (p.CreatedDate >= dtSince.Value)
                    || (p.ModifiedDate >= dtSince.Value));

            if (dtUntil.HasValue)
            {
                query = query.Where(p => (p.CreatedDate <= dtUntil.Value) || (p.ModifiedDate <= dtUntil.Value));
            }

            return query.ToList();
        }

        public override void Insert(RouteStop entity, bool saveChanges = true)
        {
            base.Insert(entity, saveChanges);
        }

        public override void Update(RouteStop entity, bool saveChanges = true)
        {
            base.Update(entity, saveChanges);
        }

        #endregion

        #region Methods

        protected override IQueryable<RouteStop> InternalSelect()
        {
            return this._repository.SelectWith("Location", "StopAction");
        }

        #endregion
    }
}