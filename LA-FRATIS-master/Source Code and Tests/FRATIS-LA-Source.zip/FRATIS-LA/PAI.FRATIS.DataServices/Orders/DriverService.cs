﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Geography;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.FRATIS.Wrappers.WebFleet.Model;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Orders
{
    /// <summary>The driverService interface.</summary>
    public interface IDriverService : IEntityServiceBase<Driver>, IInstallableEntity
    {
        #region Public Methods and Operators

        /// <summary>The get by id with all.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        Driver GetByIdWithAll(int id);

        /// <summary>The get by name.</summary>
        /// <param name="driverName">The driver name.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        Driver GetByName(string driverName);

        /// <summary>The get by legacy id.</summary>
        /// <param name="webFleetDriverId">The legacy id.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        Driver GetByWebFleetDriverId(string webFleetDriverId);

        /// <summary>The get by web fleet id.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        Driver GetByWebFleetId(string id);

        IQueryable<Driver> GetUnusedDrivers(DateTime? dueDate, int jobGroupId);

        /// <summary>The select with all.</summary>
        /// <returns>The <see cref="IQueryable"/>.</returns>
        IQueryable<Driver> SelectWithAll();

        IQueryable<Driver> SelectWithMessages();

        void SetEarliestStartTime(long ticks);

        void WebFleetSync();

        #endregion
    }

    /// <summary>The driver service.</summary>
    public class DriverService : EntityServiceBase<Driver>, IDriverService
    {
        #region Fields

        private readonly IJobService _jobService;

        private readonly ILocationService _locationService;

        private readonly IVehicleService _vehicleService;

        private readonly IWebFleetObjectService _webFleetObjectService;

        #endregion

        #region Constructors and Destructors

        /// <summary>Initializes a new instance of the <see cref="DriverService"/> class.</summary>
        /// <param name="repository">The repository.</param>
        /// <param name="cacheManager">The cache manager.</param>
        public DriverService(
            IRepository<Driver> repository,
            ICacheManager cacheManager,
            IJobService jobService,
            ILocationService locationService,
            IVehicleService vehicleService,
            IWebFleetObjectService webFleetObjectService)
            : base(repository, cacheManager)
        {
            this._jobService = jobService;
            this._locationService = locationService;
            this._vehicleService = vehicleService;
            this._webFleetObjectService = webFleetObjectService;
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>The get by id with all.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        public Driver GetByIdWithAll(int id)
        {
            return this.SelectWithAll().FirstOrDefault(m => m.Id == id);
        }

        /// <summary>The get by name.</summary>
        /// <param name="driverName">The driver name.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        public Driver GetByName(string driverName)
        {
            return this.SelectWithAll().FirstOrDefault(f => f.DisplayName == driverName);
        }

        /// <summary>The get by web fleet driver id.</summary>
        /// <param name="webFleetDriverId">The web fleet driver id.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        public Driver GetByWebFleetDriverId(string webFleetDriverId)
        {
            return this.SelectWithAll().FirstOrDefault(f => f.WebFleetDriverId == webFleetDriverId);
        }

        /// <summary>The get by web fleet id.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Driver"/>.</returns>
        public Driver GetByWebFleetId(string id)
        {
            return this.Select().FirstOrDefault(f => f.WebFleetDriverId == id);
        }

        public int? GetDriverId(int? vehicleId)
        {
            return vehicleId.HasValue ? this._vehicleService.GetDriverId(vehicleId.Value) : null;
        }

        public IQueryable<Driver> GetUnusedDrivers(DateTime? dueDate, int jobGroupId)
        {
            IQueryable<Job> query = this._jobService.Select().Where(p => p.DueDate == dueDate);
            if (jobGroupId > 0)
            {
                query = query.Where(p => p.JobGroupId == jobGroupId);
            }

            query = query.Where(p => p.AssignedDriverId.HasValue);

            List<int?> ids = query.Select(p => p.AssignedDriverId).ToList();
            IOrderedQueryable<Driver> unusedDrivers =
                this.Select().Where(p => !ids.Contains(p.Id) && !p.IsPlaceholderDriver).OrderBy(p => p.DisplayName);
            return unusedDrivers;
        }

        public void Install()
        {
            // install default location if needed
            if (this._locationService.Select().FirstOrDefault(p => p.DisplayName == "Home") == null)
            {
                this._locationService.Install();
            }

            Location defaultLocation = this._locationService.Select().FirstOrDefault(p => p.DisplayName == "Home");

            if (this.Select().FirstOrDefault(p => p.IsPlaceholderDriver) == null)
            {
                var placeholderDriver = new Driver
                    {
                        DisplayName = "Placeholder Driver",
                        FirstName = "Placeholder",
                        LastName = "Driver",
                        IsPlaceholderDriver = true,
                        AvailableDrivingHours = 11,
                        AvailableDutyHours = 14,
                        StartingLocation = defaultLocation
                    };

                this.Insert(placeholderDriver);
            }
        }

        /// <summary>The select with all.</summary>
        /// <returns>The <see cref="IQueryable"/>.</returns>
        public IQueryable<Driver> SelectWithAll()
        {
            return this._repository.SelectWith("JobGroups", "StartingLocation");
        }

        public IQueryable<Driver> SelectWithMessages()
        {
            return this._repository.SelectWith("JobGroups", "StartingLocation", "SentMessages", "ReceivedMessages");
        }

        public void SetEarliestStartTime(long ticks)
        {
            foreach (Driver d in this.Select().ToList())
            {
                d.EarliestStartTime = ticks;
                this.Update(d, false);
            }

            this.SaveChanges();
        }

        public void WebFleetSync()
        {
            ICollection<WebFleetDriver> webfleetDrivers = this._webFleetObjectService.GetDrivers();
            List<Driver> localDrivers = this.Select().Where(p => p.Id > 0).ToList();

            if (this.UpdateDriversToLocalDb(localDrivers, webfleetDrivers))
            {
                this.SaveChanges();
            }
        }

        #endregion

        #region Methods

        private bool UpdateDriversToLocalDb(IList<Driver> localDrivers, IEnumerable<WebFleetDriver> webfleetDrivers)
        {
            bool changesMade = false;
            Location homeLocation = this._locationService.Select().FirstOrDefault(p => p.WebFleetId == "TREXWARE");

            if (homeLocation == null)
            {
                return false;
            }

            foreach (WebFleetDriver webfleetDriver in webfleetDrivers)
            {
                Driver existingDriver =
                    localDrivers.FirstOrDefault(p => p.WebFleetDriverId == webfleetDriver.DriverNumber.ToUpper());
                if (existingDriver == null)
                {
                    // add locally
                    this.Insert(
                        new Driver
                            {
                                DisplayName = webfleetDriver.Name,
                                WebFleetDriverId = webfleetDriver.DriverNumber.ToUpper(),
                                WebFleetVehicleId =
                                    webfleetDriver.CurrentVehicleObjectNumber != null
                                        ? webfleetDriver.CurrentVehicleObjectNumber.ToUpper()
                                        : string.Empty,
                                StartingLocationId = homeLocation != null ? homeLocation.Id : 0,
                                Phone = webfleetDriver.Phone ?? string.Empty,
                                Email = webfleetDriver.Email ?? string.Empty,
                                Position = new WebFleetLocation()
                            },
                        false);
                    changesMade = true;
                }
                else
                {
                    // synchronize changes
                    if (existingDriver.DisplayName != webfleetDriver.Name
                        ||
                        (!string.IsNullOrEmpty(existingDriver.Phone) && !string.IsNullOrEmpty(webfleetDriver.Phone)
                         && existingDriver.Phone != webfleetDriver.Phone)
                        ||
                        (!string.IsNullOrEmpty(existingDriver.Email) && !string.IsNullOrEmpty(webfleetDriver.Email)
                         && existingDriver.Email != webfleetDriver.Email))
                    {
                        existingDriver.DisplayName = webfleetDriver.Name;
                        existingDriver.Phone = webfleetDriver.Phone ?? string.Empty;
                        existingDriver.Email = webfleetDriver.Email ?? string.Empty;
                        this.Update(existingDriver, false);
                        changesMade = true;
                    }
                }
            }
            return changesMade;
        }

        #endregion
    }
}