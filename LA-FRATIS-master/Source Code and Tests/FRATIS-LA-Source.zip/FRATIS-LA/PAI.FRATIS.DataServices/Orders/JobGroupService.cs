﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Orders
{
    public interface IJobGroupService : IEntityServiceBase<JobGroup>, IInstallableEntity
    {
        #region Public Methods and Operators

        ICollection<JobGroup> GetByIds(IEnumerable<int> ids);

        IQueryable<JobGroup> GetByName(IEnumerable<string> names);

        ICollection<JobGroup> GetGroups();

        #endregion
    }

    /// <summary>The job group service.</summary>
    public class JobGroupService : EntityServiceBase<JobGroup>, IJobGroupService
    {
        #region Constructors and Destructors

        public JobGroupService(IRepository<JobGroup> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        public ICollection<JobGroup> GetByIds(IEnumerable<int> ids)
        {
            return this.InternalSelect().Where(m => ids.Contains(m.Id)).ToList();
        }

        public IQueryable<JobGroup> GetByName(IEnumerable<string> names)
        {
            return this.InternalSelect().Where(p => names.Contains(p.Name));
        }

        /// <summary>
        /// Gets the job groups ordered by ordering, name
        /// </summary>
        /// <returns></returns>
        public ICollection<JobGroup> GetGroups()
        {
            return this.InternalSelect().OrderBy(m => m.Ordering).ThenBy(m => m.Name).ToList();
        }

        public void Install()
        {
            ICollection<JobGroup> existingGroups = this.GetGroups();
            bool isChanged = false;

            foreach (JobGroup group in this.GetBuiltInGroupList())
            {
                JobGroup x = existingGroups.FirstOrDefault(p => p.Name.ToLower() == group.Name.ToLower());
                if (x == null || x.Id == 0)
                {
                    // add new record
                    isChanged = true;
                    this.Insert(group, false);
                }
            }

            if (isChanged)
            {
                this._repository.SaveChanges();
            }
        }

        #endregion

        #region Methods

        /// <summary>The get built in group list.</summary>
        /// <returns>The <see cref="IEnumerable"/>.</returns>
        private IEnumerable<JobGroup> GetBuiltInGroupList()
        {
            var groups = new List<JobGroup>
                {
                    new JobGroup { Name = "Morning", Ordering = 1, ShiftStartTime = new TimeSpan(7, 0, 0) },
                    new JobGroup { Name = "Evening", Ordering = 2, ShiftStartTime = new TimeSpan(20, 0, 0) }
                };
            return groups;
        }

        #endregion
    }
}