//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Equipment
{
    public interface IContainerOwnerService : IEntityServiceBase<ContainerOwner>, IInstallableEntity, IArchivedEntity
    {
        #region Public Methods and Operators

        ICollection<ContainerOwner> GetContainerOwners(bool? isDomestic = null);

        #endregion
    }

    public class ContainerOwnerService : EntityServiceBase<ContainerOwner>, IContainerOwnerService
    {
        #region Constructors and Destructors

        public ContainerOwnerService(IRepository<ContainerOwner> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Properties

        public bool IsDeleted { get; set; }

        #endregion

        #region Public Methods and Operators

        public ICollection<ContainerOwner> GetContainerOwners(bool? isDomestic = null)
        {
            // var query = InternalSelectSimple();
            IQueryable<ContainerOwner> query = this.InternalSelect();
            if (isDomestic.HasValue)
            {
                query = query.Where(p => p.IsDomestic == isDomestic.Value);
            }

            return query.OrderBy(p => p.DisplayName).ToList();
        }

        public void Install()
        {
            // get all containers already persisted to db
            ICollection<ContainerOwner> existingContainerOwners = this.GetContainerOwners(null);

            this.InstallIfNecessary("Domestic", "DOM", true, existingContainerOwners, false);
            this.InstallIfNecessary("International", "INT", false, existingContainerOwners, false);

            this.InstallIfNecessary("ACL / Grimaldi Group / Inarme", "ACLU", null, existingContainerOwners, false);
            this.InstallIfNecessary("APL Limited", "APLU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Bridge Chassis Supply, LLC", "BCHS", null, existingContainerOwners, false);
            this.InstallIfNecessary("Burlington Northern Santa Fe", "BNAU", null, existingContainerOwners, false);
            this.InstallIfNecessary("China Shipping Container Line", "CHNJ", null, existingContainerOwners, false);
            this.InstallIfNecessary("CMA-CGM (America), LLC", "CMDU", null, existingContainerOwners, false);
            this.InstallIfNecessary("COFC Logistics, LLC", "CFQU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Compania Chilena De Nevegacion", "CNIU", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Compania Sud-Americana De Vapores (CSAV)", "CSVU", null, existingContainerOwners, false);
            this.InstallIfNecessary("COSCO N.A.", "CCMJ", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Evergreen Shipping Agency (America) Corp.", "EGLV", null, existingContainerOwners, false);
            this.InstallIfNecessary("Hamburg Sud North America, Inc.", "SUDU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Hanjin Shipping Co., Ltd.", "HJCU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Hapag-Lloyd (America) Inc. ", "HLCU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Horizon Lines of Alaska, LLC", "HRZK", null, existingContainerOwners, false);
            this.InstallIfNecessary("Horizon Lines, LLC", "HRZD", null, existingContainerOwners, false);
            this.InstallIfNecessary("Hyundai Merchant Marine, Inc.", "HDMU", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "K-line America, Inc. (Kawasaki Kisen Kaisha Ltd)", "KKLU", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Maersk Agency USA, Inc. (dba Maersk Line/Safmarine/Maersk Domestic)",
                "MAEU",
                null,
                existingContainerOwners,
                false);
            this.InstallIfNecessary("Matson Navigation Company", "MATS", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Mediterranean Shipping Company S. A.", "MSCU", null, existingContainerOwners, false);
            this.InstallIfNecessary("MOL (America), Inc.", "MOLU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Nippon Yusen Kaisha (NYK Line)", "NYKU", null, existingContainerOwners, false);
            this.InstallIfNecessary("Norfolk Southern Corporation", "NSCU", null, existingContainerOwners, false);
            this.InstallIfNecessary("OOCL (USA), Inc.", "OOLL", null, existingContainerOwners, false);
            this.InstallIfNecessary("Pacer Stacktrain (Pacer Intl, Inc.)", "PCKA", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Pacific International Lines (Pte) Ltd.", "PABV", null, existingContainerOwners, false);
            this.InstallIfNecessary("Pasha Hawaii Transport Lines LLC", "PSHI", null, existingContainerOwners, false);
            this.InstallIfNecessary("Sea Star Line, LLC", "SSLH", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Turkon Container Transp. & Shipping Inc.", "TRKU", null, existingContainerOwners, false);
            this.InstallIfNecessary("UIIAEP", "UIIAXX", null, existingContainerOwners, false);
            this.InstallIfNecessary("Union Pacific Railroad Company", "UP", null, existingContainerOwners, false);
            this.InstallIfNecessary("United Arab Shipping Company", "UASU", null, existingContainerOwners, false);
            this.InstallIfNecessary("US Lines, LLC", "ANLC", null, existingContainerOwners, false);
            this.InstallIfNecessary("Wan Hai Lines Ltd.", "WHLC", null, existingContainerOwners, false);
            this.InstallIfNecessary("Yangming Marine Transport", "YMLU", null, existingContainerOwners, false);
            this.InstallIfNecessary(
                "Zim Amer Integrated Shipping Svcs Co Inc/Zim Integrated Shipping Svcs Ltd.",
                "ZIMU",
                null,
                existingContainerOwners,
                false);

            this.SaveChanges();
        }

        #endregion

        #region Methods

        protected override IQueryable<ContainerOwner> InternalSelect()
        {
            return this._repository.SelectWith("AllowedContainers", "AllowedChassisOwner");
        }

        /// <summary>
        /// The install if specified container owner if it does not already exists. necessary.
        /// Duplicate checks determined by matching shortname and matching first word of display name
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="shortname">The shortname.</param>
        /// <param name="isDomestic">The is domestic.</param>
        /// <param name="existingContainerOwners">The existing container owners.</param>
        /// <param name="saveChangesNow">The save changes now.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        private bool InstallIfNecessary(
            string name,
            string shortname,
            bool? isDomestic,
            ICollection<ContainerOwner> existingContainerOwners = null,
            bool saveChangesNow = false)
        {
            if (existingContainerOwners == null)
            {
                existingContainerOwners = this.GetContainerOwners(null);
            }

            string nameFirstWord = name.Trim();
            if (name.IndexOf(' ') >= 0)
            {
                nameFirstWord = name.Substring(0, name.IndexOf(' '));
            }

            ContainerOwner item =
                existingContainerOwners.FirstOrDefault(
                    p => p.ShortName == shortname && p.DisplayName.StartsWith(nameFirstWord));
            if (item == null)
            {
                item = new ContainerOwner { DisplayName = name, ShortName = shortname, IsDomestic = isDomestic };
                this.Insert(item, saveChangesNow);
                return true;
            }

            return false;
        }

        #endregion
    }
}