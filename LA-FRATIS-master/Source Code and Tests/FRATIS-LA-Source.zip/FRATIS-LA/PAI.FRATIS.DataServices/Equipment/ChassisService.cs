//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Equipment
{
    public interface IChassisService : IEntityServiceBase<Chassis>, IInstallableEntity
    {
        #region Public Methods and Operators

        /// <summary>
        /// Gets a collection of all Chassis
        /// regardless of their IsDomestic or IsEnabled status
        /// </summary>
        /// <returns></returns>
        ICollection<Chassis> GetChassis();

        IEnumerable<Chassis> GetCompatibleChassisForContainer(string containerName);

        /// <summary>
        /// Gets a collection of all valid, enabled Domestic Chassis
        /// This includes Chassis with IsDomestic set to null
        /// </summary>
        /// <returns></returns>
        ICollection<Chassis> GetDomesticChassis();

        /// <summary>
        /// Gets a collection of all enabled Chassis
        /// regardless of their IsDomestic status
        /// </summary>
        /// <returns></returns>
        ICollection<Chassis> GetEnabledChassis();

        /// <summary>
        /// Gets a collection of all valid, enabled International Chassis
        /// This includes Chassis with IsDomestic set to null
        /// </summary>
        /// <returns></returns>
        ICollection<Chassis> GetInternationalChassis();

        #endregion
    }

    public class ChassisService : EntityServiceBase<Chassis>, IChassisService
    {
        #region Constructors and Destructors

        public ChassisService(IRepository<Chassis> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        public ICollection<Chassis> GetChassis()
        {
            return this.InternalSelect().Where(p => p.Id > 0).OrderBy(p => p.DisplayName).ToList();
        }

        public IEnumerable<Chassis> GetCompatibleChassisForContainer(string containerName)
        {
            IQueryable<Chassis> result = from chassis in this._repository.Select()
                                         where
                                             chassis.DisplayName.StartsWith(
                                                 containerName.Replace("Container", "Chassis").Replace("HC", "").Trim())
                                         select chassis;
            return result;
        }

        public ICollection<Chassis> GetDomesticChassis()
        {
            return
                this.InternalSelect().Where(p => p.IsDomestic != false).Where(p => p.Enabled).OrderBy(
                    p => p.DisplayName).ToList();
        }

        public ICollection<Chassis> GetEnabledChassis()
        {
            return this.InternalSelect().Where(p => p.Id > 0).Where(p => p.Enabled).OrderBy(p => p.DisplayName).ToList();
        }

        public ICollection<Chassis> GetInternationalChassis()
        {
            return
                this.InternalSelect().Where(p => p.IsDomestic != true).Where(p => p.Enabled).OrderBy(p => p.DisplayName)
                    .ToList();
        }

        public void Install()
        {
            ICollection<Chassis> existingChassiss = this.GetChassis();
            bool isChanged = false;

            foreach (Chassis chassis in this.GetChassisList())
            {
                Chassis x =
                    existingChassiss.FirstOrDefault(p => p.DisplayName.ToLower() == chassis.DisplayName.ToLower());
                if (x == null || x.Id == 0)
                {
                    // add new record
                    isChanged = true;
                    this.Insert(chassis, false);
                }
            }

            if (isChanged)
            {
                this._repository.SaveChanges();
            }
        }

        #endregion

        #region Methods

        private IEnumerable<Chassis> GetChassisList()
        {
            var chassis = new List<Chassis>
                {
                    new Chassis { DisplayName = "Chassis 20, 2 Axles", Enabled = true, IsDomestic = false },
                    new Chassis { DisplayName = "Chassis 20, 3 Axles", Enabled = true, IsDomestic = false },
                    new Chassis { DisplayName = "Chassis 40", Enabled = true, IsDomestic = false },
                    new Chassis { DisplayName = "Chassis 45", Enabled = true, IsDomestic = false },
                    new Chassis { DisplayName = "Chassis 48", Enabled = true, IsDomestic = true },
                    new Chassis { DisplayName = "Chassis 53", Enabled = true, IsDomestic = true },
                    new Chassis
                        {
                            DisplayName = "Trailer",
                            Enabled = true,
                            IsDomestic = null // used for both International and Domestic
                        },
                };

            return chassis;
        }

        #endregion
    }
}