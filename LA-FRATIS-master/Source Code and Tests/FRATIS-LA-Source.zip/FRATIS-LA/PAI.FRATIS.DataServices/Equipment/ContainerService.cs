//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Equipment
{
    public interface IContainerService : IEntityServiceBase<Container>, IInstallableEntity
    {
        #region Public Methods and Operators

        Container GetByIdWithAll(int id);

        IQueryable<Container> GetContainers(bool? isDomestic = null);

        IQueryable<Container> SelectWithAll();

        #endregion
    }

    public class ContainerService : EntityServiceBase<Container>, IContainerService
    {
        #region Fields

        private readonly IChassisService _chassisService;

        #endregion

        #region Constructors and Destructors

        public ContainerService(
            IRepository<Container> repository, ICacheManager cacheManager, IChassisService chassisService)
            : base(repository, cacheManager)
        {
            this._chassisService = chassisService;
        }

        #endregion

        #region Public Methods and Operators

        public Container GetByIdWithAll(int id)
        {
            return this.SelectWithAll().FirstOrDefault(m => m.Id == id);
        }

        public IQueryable<Container> GetContainers(bool? isDomestic = null)
        {
            IQueryable<Container> query = this.SelectWithAll();
            if (isDomestic.HasValue)
            {
                query = query.Where(p => p.IsDomestic == isDomestic.Value);
            }
            return query.OrderBy(p => p.DisplayName);
        }

        public void Install()
        {
            IQueryable<Container> existingContainers = this.GetContainers();
            ICollection<Chassis> existingChassis = this._chassisService.GetChassis();
            bool isChanged = false;

            if (existingChassis.Count == 0)
            {
                throw new Exception("No Chassis Exist - Chassis should be initialized before Containers");
            }

            foreach (Container container in this.GetContainerList())
            {
                Container x =
                    existingContainers.FirstOrDefault(p => p.DisplayName.ToLower() == container.DisplayName.ToLower());
                if (x == null || x.Id == 0)
                {
                    // add new record
                    isChanged = true;
                    container.AllowedChassis = new List<Chassis>();
                    foreach (Chassis chassisToAdd in
                        this._chassisService.GetCompatibleChassisForContainer(container.DisplayName).ToList())
                    {
                        container.AllowedChassis.Add(chassisToAdd);
                    }
                    this.Insert(container, false);
                }
                else
                {
                    if (x.AllowedChassis != null)
                    {
                        x.AllowedChassis.Clear();
                    }
                    else
                    {
                        x.AllowedChassis = new Collection<Chassis>();
                    }

                    foreach (Chassis chassisToAdd in
                        this._chassisService.GetCompatibleChassisForContainer(container.DisplayName).ToList())
                    {
                        x.AllowedChassis.Add(chassisToAdd);
                    }
                    this.Update(x, false);
                }
            }

            if (isChanged)
            {
                this._repository.SaveChanges();
            }
        }

        public void RemoveChassis(Container container, Chassis chassisToRemove, bool saveNow = true)
        {
            if (container != null && chassisToRemove != null && chassisToRemove.Id > 0)
            {
                Chassis chassisFound = container.AllowedChassis.FirstOrDefault(m => m.Id == chassisToRemove.Id);
                if (chassisFound != null)
                {
                    container.AllowedChassis.Remove(chassisFound);
                    InsertOrUpdate(container, saveNow);
                }
            }
        }

        public IQueryable<Container> SelectWithAll()
        {
            return this._repository.SelectWith("AllowedChassis");
        }

        #endregion

        #region Methods

        private IEnumerable<Container> GetContainerList()
        {
            var containers = new List<Container>
                {
                    new Container { DisplayName = "Container 20", Enabled = true, IsDomestic = false, },
                    new Container { DisplayName = "Container 40", Enabled = true, IsDomestic = false },
                    new Container { DisplayName = "Container 40 HC", Enabled = true, IsDomestic = false, },
                    new Container { DisplayName = "Container 45 HC", Enabled = true, IsDomestic = false, },
                    new Container { DisplayName = "Container 48", Enabled = true, IsDomestic = true },
                    new Container { DisplayName = "Container 53", Enabled = true, IsDomestic = true },
                };

            return containers;
        }

        #endregion
    }
}