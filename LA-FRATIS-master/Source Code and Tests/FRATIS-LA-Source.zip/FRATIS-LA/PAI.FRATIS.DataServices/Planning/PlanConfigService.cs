﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Planning;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Planning
{
    public class PlanConfigService : EntityServiceBase<PlanConfig>, IPlanConfigService
    {
        #region Fields

        private readonly IRepository<Driver> _driverRepository;

        private readonly IJobService _jobService;

        #endregion

        #region Constructors and Destructors

        public PlanConfigService(
            IRepository<PlanConfig> repository,
            ICacheManager cacheManager,
            IRepository<Driver> driverRepository,
            IJobService jobService)
            : base(repository, cacheManager)
        {
            this._driverRepository = driverRepository;
            this._jobService = jobService;
        }

        #endregion

        #region Public Methods and Operators

        public PlanConfig GetByIdWithAll(int id)
        {
            return this._repository.SelectWith(
                "JobGroup",
                "Drivers",
                "Drivers.StartingLocation",
                //"Drivers.StartingLocation.State",
                "Jobs",
                "Jobs.Chassis",
                "Jobs.ChassisOwner",
                "Jobs.Container",
                "Jobs.ContainerOwner",
                "Jobs.RouteStops",
                "Jobs.RouteStops.Location",
                "Jobs.RouteStops.StopAction").SingleOrDefault(f => f.Id == id);
        }

        public IQueryable<Driver> GetPlanConfigAvailableDrivers(int planConfigId)
        {
            IOrderedQueryable<Driver> drivers =
                from d in this._driverRepository.SelectWith("StartingLocation", "StartingLocation.State")
                where d.PlanConfigs.All(p => p.Id != planConfigId) && d.IsPlaceholderDriver == false
                orderby d.DisplayName
                select d;
            return drivers;
        }

        public IQueryable<Job> GetPlanConfigAvailableJobs(int planConfigId)
        {
            IOrderedQueryable<Job> jobs = from j in this._jobService.SelectWithAll()
                                          where
                                              j.PlanConfigs.All(p => p.Id != planConfigId)
                                              && j.JobStatus == JobStatus.Unassigned && j.IsDeleted == false
                                          orderby j.DueDate ascending
                                          select j;
            return jobs;
        }

        public IQueryable<Driver> GetPlanConfigDrivers(int planConfigId)
        {
            IOrderedQueryable<Driver> drivers =
                from d in this._driverRepository.SelectWith("StartingLocation", "StartingLocation.State")
                where d.PlanConfigs.Any(p => p.Id == planConfigId) && d.IsPlaceholderDriver == false
                orderby d.DisplayName
                select d;
            return drivers;
        }

        public IQueryable<Job> GetPlanConfigJobs(int planConfigId)
        {
            IOrderedQueryable<Job> jobs = from j in this._jobService.SelectWithAll()
                                          where j.PlanConfigs.Any(p => p.Id == planConfigId) && j.IsDeleted == false
                                          orderby j.DueDate ascending
                                          select j;
            return jobs;
        }

        #endregion

        #region Methods

        protected override IQueryable<PlanConfig> InternalSelect()
        {
            return this._repository.SelectWith(
                "Drivers",
                "Drivers.StartingLocation",
                "Jobs",
                "Jobs.JobGroup",
                "Jobs.Chassis",
                "Jobs.ChassisOwner",
                "Jobs.Container",
                "Jobs.ContainerOwner",
                "Jobs.RouteStops",
                "JobGroup");
        }

        #endregion
    }
}