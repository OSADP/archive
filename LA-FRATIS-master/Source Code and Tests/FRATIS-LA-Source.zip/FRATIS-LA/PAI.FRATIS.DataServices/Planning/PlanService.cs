﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.DataServices.Orders;
using PAI.FRATIS.Domain.Planning;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Planning
{
    public interface IPlanService : IEntityServiceBase<Plan>
    {
        #region Public Methods and Operators

        Plan GetByIdWithAll(int id);

        PlanDriverJob GetPlanDriverJobsById(int planDriverJobId);

        IQueryable<PlanDriverJob> GetPlanDriverJobsByPlanDriver(int planDriverId);

        IQueryable<RouteSegmentMetric> GetPlanDriverMetrics(int planDriverId);

        IEnumerable<int> GetUnsendableJobIds(Plan plan);

        IQueryable<Plan> SelectWithAll();

        #endregion
    }

    public class PlanService : EntityServiceBase<Plan>, IPlanService
    {
        #region Fields

        private readonly IRepository<PlanDriverJob> _planDriverJobRepository;

        private readonly IRepository<RouteSegmentMetric> _routeSegmentMetricRepository;

        private readonly IStopActionService _stopActionService;

        #endregion

        #region Constructors and Destructors

        public PlanService(
            IRepository<Plan> repository,
            ICacheManager cacheManager,
            IRepository<PlanDriverJob> planDriverJobRepository,
            IRepository<RouteSegmentMetric> routeSegmentMetricRepository,
            IStopActionService stopActionService)
            : base(repository, cacheManager)
        {
            this._planDriverJobRepository = planDriverJobRepository;
            this._routeSegmentMetricRepository = routeSegmentMetricRepository;
            this._stopActionService = stopActionService;
        }

        #endregion

        #region Public Methods and Operators

        public Plan GetByIdWithAll(int id)
        {
            return this.SelectWithAll().SingleOrDefault(f => f.Id == id);
        }

        public PlanDriverJob GetPlanDriverJobsById(int planDriverJobId)
        {
            return this.SelectPlanDriverJob().FirstOrDefault(f => f.Id == planDriverJobId);
        }

        public IQueryable<PlanDriverJob> GetPlanDriverJobsByPlanDriver(int planDriverId)
        {
            return this.SelectPlanDriverJob().Where(f => f.PlanDriver.Id == planDriverId).OrderBy(f => f.SortOrder);
        }

        public IQueryable<RouteSegmentMetric> GetPlanDriverMetrics(int planDriverId)
        {
            return
                this._routeSegmentMetricRepository.SelectWith(
                    "StartStop",
                    "StartStop.Location",
                    "StartStop.StopAction",
                    "EndStop",
                    "EndStop.Location",
                    "EndStop.StopAction").Where(f => f.PlanDriverId == planDriverId).OrderBy(f => f.SortOrder);
        }

        /// <summary>
        /// Gets the Job Ids of orders unable to be sent via WebFleet
        /// due to assignment to Placeholder Driver or a Driver
        /// without a WebFleet VehicleId
        /// </summary>
        /// <param name="plan"></param>
        /// <returns></returns>
        public IEnumerable<int> GetUnsendableJobIds(Plan plan)
        {
            var result = new HashSet<int>();
            if (plan != null)
            {
                List<int> placeholderDriverJobIds =
                    plan.DriverPlans.Where(
                        p => p.Driver.IsPlaceholderDriver || string.IsNullOrEmpty(p.Driver.WebFleetVehicleId)).
                        SelectMany(p => p.JobPlans).Select(p => p.JobId).ToList();
                foreach (int jobId in placeholderDriverJobIds)
                {
                    result.Add(jobId);
                }

                foreach (int unassignedJobId in plan.UnassignedJobs.Select(p => p.Id))
                {
                    result.Add(unassignedJobId);
                }
            }

            return result.ToList();
        }

        public override void Insert(Plan entity, bool saveChanges = true)
        {
            this.UpdateStopActions(entity);
            base.Insert(entity, saveChanges);
        }

        public IQueryable<Plan> SelectWithAll()
        {
            return this._repository.SelectWith(
                "PlanConfig",
                "JobGroup",
                "DriverPlans",
                "DriverPlans.Driver",
                "DriverPlans.Driver.StartingLocation",
                "DriverPlans.JobPlans",
                "DriverPlans.JobPlans.Job",
                "DriverPlans.JobPlans.Job.Chassis",
                "DriverPlans.JobPlans.Job.ChassisOwner",
                "DriverPlans.JobPlans.Job.Container",
                "DriverPlans.JobPlans.Job.ContainerOwner",
                "DriverPlans.JobPlans.Job.RouteStops",
                "DriverPlans.JobPlans.Job.RouteStops.Location",
                "DriverPlans.JobPlans.Job.RouteStops.StopAction",
                "DriverPlans.JobPlans.PlanDriver",
                "PlanConfig",
                "PlanConfig.Drivers",
                "UnassignedJobs",
                "UnassignedJobs.Chassis",
                "UnassignedJobs.ChassisOwner",
                "UnassignedJobs.Container",
                "UnassignedJobs.ContainerOwner",
                "UnassignedJobs.RouteStops",
                "UnassignedJobs.RouteStops.Location",
                "UnassignedJobs.RouteStops.StopAction");
        }

        public override void Update(Plan entity, bool saveChanges = true)
        {
            this.UpdateStopActions(entity);
            base.Update(entity, saveChanges);
        }

        #endregion

        #region Methods

        private IQueryable<PlanDriverJob> SelectPlanDriverJob()
        {
            return this._planDriverJobRepository.SelectWith(
                "Job.Chassis",
                "Job.ChassisOwner",
                "Job.Container",
                "Job.ContainerOwner",
                "Job.RouteStops",
                "Job.RouteStops.Location",
                "Job.RouteStops.StopAction");
        }

        private void UpdateStopActions(Plan plan)
        {
            //foreach (var driverPlan in plan.DriverPlans)
            //{
            //    foreach (var jobPlan in driverPlan.JobPlans)
            //    {
            //        foreach (var rs in jobPlan.RouteStops)
            //        {
            //            var sa = _stopActionService.StopActions.FirstOrDefault(p => p.ShortName == rs.StopAction.ShortName);
            //            rs.StopActionId = sa.Id;
            //        }
            //    }
            //}
        }

        #endregion
    }
}