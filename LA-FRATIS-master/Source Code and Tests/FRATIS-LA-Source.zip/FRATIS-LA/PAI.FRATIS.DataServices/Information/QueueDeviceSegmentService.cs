//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Information;
using PAI.FRATIS.Wrappers.QueueTimes;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Information
{
    public class SegmentReport
    {
        #region Public Properties

        public TimeSpan? Delay { get; set; }

        public string DelayString
        {
            get
            {
                return this.Delay.HasValue && this.Delay.Value.TotalSeconds > 0
                           ? this.Delay.Value.ToString()
                           : "Unavailable";
            }
        }

        public string Device1 { get; set; }

        public string Device2 { get; set; }

        public string DisplayName { get; set; }

        #endregion
    }

    public interface IQueueDeviceSegmentService : IEntityServiceBase<QueueDeviceSegment>, IInstallableEntity
    {
        #region Public Methods and Operators

        ICollection<SegmentReport> GetReport();

        #endregion
    }

    public class QueueDeviceSegmentService : EntityServiceBase<QueueDeviceSegment>, IQueueDeviceSegmentService
    {
        #region Fields

        private readonly IQueueTimeService _queueTimeService;

        #endregion

        #region Constructors and Destructors

        public QueueDeviceSegmentService(
            IRepository<QueueDeviceSegment> repository, ICacheManager cacheManager, IQueueTimeService queueTimeService)
            : base(repository, cacheManager)
        {
            this._queueTimeService = queueTimeService;
        }

        #endregion

        #region Public Methods and Operators

        public ICollection<SegmentReport> GetReport()
        {
            return
                this.Select().ToList().Select(
                    segment =>
                    new SegmentReport
                        {
                            DisplayName = segment.DisplayName,
                            Device1 = segment.Device1Identifier,
                            Device2 = segment.Device2Identifier,
                            Delay =
                                this._queueTimeService.GetQueueTimeNow(
                                    segment.Device1Identifier, segment.Device2Identifier, 0)
                        }).ToList();
        }

        public void Install()
        {
            List<QueueDeviceSegment> existingRecords = this.Select().ToList();
            this.UpdateIfExists("Bobtail Gate", "265716", "265782", true, existingRecords);
            this.UpdateIfExists("Main Gate - Left Side", "265716", "265783", true, existingRecords);
            this.UpdateIfExists("Main Gate - Right Side", "265716", "265714", true, existingRecords);
        }

        #endregion

        #region Methods

        private QueueDeviceSegment UpdateIfExists(
            string displayName,
            string device1,
            string device2,
            bool saveNow = true,
            List<QueueDeviceSegment> existingRecords = null)
        {
            if (existingRecords == null)
            {
                existingRecords = this.Select().ToList();
            }

            QueueDeviceSegment record =
                existingRecords.FirstOrDefault(
                    p =>
                    (p.Device1Identifier == device1 && p.Device2Identifier == device2)
                    || p.Device2Identifier == device1 && p.Device1Identifier == device2);

            if (record == null)
            {
                record = new QueueDeviceSegment
                    { DisplayName = displayName, Device1Identifier = device1, Device2Identifier = device2 };
                this.Insert(record, saveNow);
            }

            return record;
        }

        #endregion
    }
}