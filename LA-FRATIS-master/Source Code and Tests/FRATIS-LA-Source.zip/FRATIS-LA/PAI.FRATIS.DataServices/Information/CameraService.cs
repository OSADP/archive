//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Domain.Information;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Information
{
    public interface ICameraService : IEntityServiceBase<Camera>, IInstallableEntity
    {
        #region Public Methods and Operators

        IQueryable<Camera> GetCameraEntries();

        #endregion
    }

    /// <summary>The camera service.</summary>
    public class CameraService : EntityServiceBase<Camera>, ICameraService, IInstallableEntity
    {
        #region Constructors and Destructors

        public CameraService(IRepository<Camera> repository, ICacheManager cacheManager)
            : base(repository, cacheManager)
        {
        }

        #endregion

        #region Public Methods and Operators

        public IQueryable<Camera> GetCameraEntries()
        {
            return this.Select().OrderBy(p => p.Name).ThenBy(p => p.Description);
        }

        public void Install()
        {
            var result = new List<Camera>();
            List<Camera> localEntities = this.Select().ToList();

            result.Add(
                new Camera
                    {
                        Name = "Yusen Terminal",
                        Description = "Ingate",
                        Url = "http://www.yti.com/uploads/gatecamera/CAM2/snap.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Yusen Terminal",
                        Description = "Outgate",
                        Url = "http://www.yti.com/uploads/gatecamera/CAM1/snap.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Yusen Terminal",
                        Description = "Chassis",
                        Url = "http://www.yti.com/uploads/gatecamera/CAM3/snap.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "APL Terminal",
                        Description = "Global Gateway South",
                        Url = "http://emsinfo.apl.com/images/camera3.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "APM Terminal",
                        Description = "Ingate (North)",
                        Url =
                            "http://dataservices.namapmterminals.com/apmt/cameraimage.aspx?address=http://10.1.103.178/axis-cgi/jpg/image.cgi?resolution=352x288"
                    });

            result.Add(
                new Camera
                    {
                        Name = "APM Terminal",
                        Description = "Outgate",
                        Url =
                            "http://dataservices.namapmterminals.com/apmt/cameraimage.aspx?address=http://10.1.103.179/axis-cgi/jpg/image.cgi?resolution=352x288"
                    });

            result.Add(
                new Camera
                    {
                        Name = "BENT / Evergreen",
                        Description = "Ingate",
                        Url = "http://stsoaklivecam.voyagertrack.com/livecamImages/stsoakCamera2.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "BENT / Evergreen",
                        Description = "Ingate 2",
                        Url = "http://stsoaklivecam.voyagertrack.com/livecamImages/stsoakCamera1.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "BENT / Evergreen",
                        Description = "7th Street Eastbound",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=9"
                    });

            result.Add(
                new Camera
                    {
                        Name = "C60 (Matson)",
                        Description = "Ingate",
                        Url = "http://www.tideworks.com/terminalcameras/C60gate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Evergreen Container Terminal",
                        Description = "Ingate",
                        Url = "http://egalalivecam.voyagertrack.com/livecamImages/stslaxCamera1.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Evergreen Container Terminal",
                        Description = "Outgate",
                        Url = "http://egalalivecam.voyagertrack.com/livecamImages/stslaxCamera2.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Howard / Matson",
                        Description = "Ingate",
                        Url = "http://www.tideworks.com/terminalCameras/HOWgate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "OICT",
                        Description = "Ingate",
                        Url = "http://www.tideworks.com/terminalCameras/B58gate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "OICT",
                        Description = "Middle Harbor Westbound",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=14"
                    });

            result.Add(
                new Camera
                    {
                        Name = "OICT",
                        Description = "Middle Harbor West (Ingate)",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=15"
                    });

            result.Add(
                new Camera
                    {
                        Name = "PAOH",
                        Description = "Ingate",
                        Url = "http://paolivecam.portsamerica.com/livecamImages/paoCamera1.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "PAOH",
                        Description = "Maritime Northbound (Ingate)",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=2"
                    });

            result.Add(
                new Camera
                    {
                        Name = "PAOH",
                        Description = "Maritime Northbound (Outgate)",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=3"
                    });

            result.Add(
                new Camera
                    {
                        Name = "PAOH",
                        Description = "Ingate",
                        Url = "http://paolivecam.portsamerica.com/livecamImages/paoCamera1.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier A",
                        Description = "Ingate",
                        Url = "http://www.tideworks.com/terminalCameras/PAfrontgate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier A",
                        Description = "Outgate",
                        Url = "http://www.tideworks.com/terminalCameras/PAbackgate.jpg"
                    });

            result.Add(
                new Camera
                    { Name = "Pier F (LBCT)", Description = "Ingate", Url = "http://www.lbct.com/webcam/Ingate.jpg" });

            result.Add(
                new Camera
                    { Name = "Pier F (LBCT)", Description = "Outgate", Url = "http://www.lbct.com/webcam/Outgate.jpg" });

            result.Add(
                new Camera
                    {
                        Name = "Pier F (LBCT)",
                        Description = "Main Entrance",
                        Url = "http://www.lbct.com/webcam/Checkpoint.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier F (LBCT)",
                        Description = "Holding Area",
                        Url = "http://www.lbct.com/webcam/HoldingArea.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier G (ITS)",
                        Description = "Ingate",
                        Url = "http://www.itslb.com/Main/GateCam/its_ingate_480_360.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier G (ITS)",
                        Description = "Outgate",
                        Url = "http://www.itslb.com/Main/GateCam/its_outgate_480_360.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier G (ITS)",
                        Description = "I/B Portal",
                        Url = "http://www.itslb.com/Main/GateCam/its_ibportal_480_360.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier J (PCT)",
                        Description = "Ingate",
                        Url = "https://www.tideworks.com/terminalCameras/PCTPRJgate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier J (PCT)",
                        Description = "Main Gate",
                        Url = "https://www.tideworks.com/terminalCameras/PCTMaingate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier J (PCT)",
                        Description = "Outgate",
                        Url = "https://www.tideworks.com/terminalCameras/PCTPRJoutgate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier J (PCT)",
                        Description = "Main Gate",
                        Url = "https://www.tideworks.com/terminalCameras/PCTMaingate2.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier T (TTI)",
                        Description = "Front Gate",
                        Url = "http://ttilgbcam.tnslgb.com/axis-cgi/jpg/image.cgi?resolution=352x240&camera=1"
                    });

            result.Add(
                new Camera
                    {
                        Name = "Pier T (TTI)",
                        Description = "Front Gate Entrance",
                        Url = "http://ttilgbcam.tnslgb.com/axis-cgi/jpg/image.cgi?resolution=352x240&camera=2"
                    });
            result.Add(
                new Camera
                    {
                        Name = "Pier T (TTI)",
                        Description = "Queuing Area",
                        Url = "http://ttilgbcam.tnslgb.com/axis-cgi/jpg/image.cgi?resolution=352x240&camera=3"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac Container Terminal",
                        Description = "Ingate",
                        Url = "https://www.trapac.com/images/tracam/tracamla2/large.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac Container Terminal",
                        Description = "Outgate",
                        Url = "https://www.trapac.com/images/tracam/tracamla6/large.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac Container Terminal",
                        Description = "Roadability",
                        Url = "https://www.trapac.com/images/tracam/tracamla12/large.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac Container Terminal",
                        Description = "High Line 136 E",
                        Url = "https://www.trapac.com/images/tracam/tracamla14/large.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac: Oakland",
                        Description = "Ingate",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=6"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac: Oakland",
                        Description = "Outgate (7th Street West)",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=7"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac: Oakland",
                        Description = "7th Street East",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=5"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TraPac Container Terminal",
                        Description = "Outgate",
                        Url = "https://www.tideworks.com/terminalCameras/PCTPRJoutgate.jpg"
                    });

            result.Add(
                new Camera
                    {
                        Name = "TTI",
                        Description = "Middle Harbor Westbound",
                        Url = "http://www.portofoakland.com/WebCam/ajax.aspx?a=Snapshot&cID=12"
                    });

            result.Add(
                new Camera
                    {
                        Name = "West Basin Container Terminal",
                        Description = "Ingate",
                        Url =
                            "http://wbctlivecam.voyagertrack.com/livecamImages/wbctCamera1.jpg?resolution=320x240&camera=1&compression=25"
                    });

            result.Add(
                new Camera
                    {
                        Name = "West Basin Container Terminal",
                        Description = "Outgate",
                        Url =
                            "http://wbctlivecam.voyagertrack.com/livecamImages/wbctCamera2.jpg?resolution=320x240&camera=1&compression=25"
                    });

            foreach (Camera item in result)
            {
                Camera matchedItem =
                    localEntities.FirstOrDefault(p => p.Name == item.Name && p.Description == p.Description);

                if (matchedItem == null)
                {
                    this.Insert(item, false);
                }
            }

            this.SaveChanges();
        }

        #endregion
    }
}