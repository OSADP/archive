using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

using NUnit.Framework;

using Ninject;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Tests
{

    public class NodeFactoryTests : TestBase
    {
        INodeFactory nodeFactory;
        INodeFactory NodeFactory
        {
            get { return this.nodeFactory ?? (this.nodeFactory = this.Kernel.Get<INodeFactory>()); }
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            this.Kernel.Bind<INodeFactory>().To<NodeFactory>().InSingletonScope();
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateJob_throws_NullReferenceException_when_job_is_null()
        {
            this.NodeFactory.CreateJobNode(default(Job));
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_has_no_stops()
        {
            this.NodeFactory.CreateJobNode(new Job());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_window_is_too_long()
        {
            this.NodeFactory.CreateJobNode(new Job { RouteStops = new Collection<RouteStop>(new List<RouteStop> { new RouteStop() }) });
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_does_not_have_a_location()
        {
            var job = this.CreateTestJob();
            foreach (var routeStop in job.RouteStops)
            {
                routeStop.Location = default(Location);
            }

            this.NodeFactory.CreateJobNode(job);
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_does_not_have_a_valid_window()
        {
            var job = this.CreateTestJob();
            var x = job.RouteStops.First().WindowEnd;
            job.RouteStops.First().WindowEnd = job.RouteStops.First().WindowStart;
            job.RouteStops.First().WindowStart = x;

            this.NodeFactory.CreateJobNode(job);
        }

        [Test]
        public void Created_Jobs_have_properties_properly_completed()
        {
            for (var i = -5000; i <= 5000; i++)
            {
                var job = this.CreateTestJob();
                var jobNode = this.NodeFactory.CreateJobNode(job);
                Assert.IsNotNull(jobNode);
                Assert.AreEqual(jobNode.Job, job);
                Assert.AreEqual(jobNode.RouteStatistics, new RouteStatistics());
                Assert.AreEqual(jobNode.RouteStops, job.RouteStops);
                Assert.AreEqual(jobNode.WindowStart, job.RouteStops.First().WindowStart);
                Assert.AreEqual(jobNode.WindowEnd, job.RouteStops.First().WindowEnd);
            }
        }

        Job CreateTestJob()
        {
            return
                new Job
                    {
                        RouteStops =
                            new List<RouteStop>
                                {
                                    new RouteStop()
                                        {
                                            WindowStart = new TimeSpan(DateTime.Now.AddHours(1).Ticks), 
                                            WindowEnd = new TimeSpan(DateTime.Now.AddHours(2).Ticks),
                                            Location = new Location()
                                                {
                                                    Latitude = 1,
                                                    Longitude = 1
                                                }
                                        },
                                    new RouteStop()
                                        {
                                            WindowStart = new TimeSpan(DateTime.Now.AddHours(3).Ticks), 
                                            WindowEnd = new TimeSpan(DateTime.Now.AddHours(4).Ticks),
                                            Location = new Location()
                                                {
                                                    Latitude = 1,
                                                    Longitude = 1
                                                }
                                        }
                                }
                    };
        }
    }
}