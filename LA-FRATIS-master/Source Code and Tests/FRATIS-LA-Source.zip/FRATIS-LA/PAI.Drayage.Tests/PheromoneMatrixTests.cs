using System;

using Moq;

using NUnit.Framework;

using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Tests
{

    public class PheromoneMatrixTests : TestBase
    {
        Mock<IObjectiveFunction> objectiveMeasureFunction;
        IPheromoneMatrix pheromoneMatrix;

        [SetUp]
        public void SetUp()
        {
            this.objectiveMeasureFunction = new Mock<IObjectiveFunction>();

            this.pheromoneMatrix = new PheromoneMatrix(0, 0.5, 1000, this.objectiveMeasureFunction.Object);
        }

        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void PheronomeMatrix_UpdatePheromoneMatrix_requires_a_Solution()
        {
            this.pheromoneMatrix.UpdatePheromoneMatrix(default(Solution));
        }

        [Test]
        public void PhermononeMatrix_delegates_to_IObjectiveFunction_to_get_ObjectiveMeasure()
        {
            this.pheromoneMatrix.UpdatePheromoneMatrix(new Solution());

            this.objectiveMeasureFunction.Verify(x => x.GetObjectiveMeasure(It.IsAny<RouteStatistics>()));
        }
    }
}