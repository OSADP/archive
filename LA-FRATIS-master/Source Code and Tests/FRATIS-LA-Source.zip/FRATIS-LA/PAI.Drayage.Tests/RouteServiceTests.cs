using System;
using System.Collections.Generic;
using System.Linq;

using Moq;

using NUnit.Framework;

using PAI.Core;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.FRATIS.Infrastructure;

namespace PAI.Drayage.Tests
{

    public class RouteServiceTests
    {
        Mock<ILogger> logger;
        Mock<IRouteExitFunction> routeExitFunction;
        Mock<INodeService> nodeService;
        Mock<IStatisticsService> statisticsService;
        IRouteService routeService;

        INode driver = 
            new DriverNode(new Driver());

        INode firstJob =
            new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics
                        {
                            TotalExecutionTime = new TimeSpan(1, 0, 0)
                        }
                };

        INode secondJob =
            new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics
                        {
                            TotalExecutionTime = new TimeSpan(0, 1, 0)
                        }
                };

        INode thirdJob =
            new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics
                        {
                            TotalExecutionTime = new TimeSpan(0, 0, 1)
                        }
                };

        RouteStatistics DriverToFirst = 
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(2, 0, 0, 0)
                };

        RouteStatistics FirstToSecond =
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(0, 2, 0, 0)
                };

        RouteStatistics SecondToThird =
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(0, 0, 2, 0)
                };

        RouteStatistics ThirdToDriver =
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(0, 0, 0, 2)
                };

        [SetUp]
        public void SetUp()
        {
            this.logger = new Mock<ILogger>();
            this.routeExitFunction = new Mock<IRouteExitFunction>();
            this.nodeService = new Mock<INodeService>();
            this.statisticsService = new Mock<IStatisticsService>();
        }
        
        public void SetUpSystemUnderTest()
        {
            this.routeService = new RouteService(this.routeExitFunction.Object, this.nodeService.Object, this.statisticsService.Object, this.logger.Object);
        }

        [Test]
        public void RouteService_CalculateRouteStatistics_delegates_to_NodeService()
        {
            this.nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            this.SetUpSystemUnderTest();
            this.routeService.CalculateRouteStatistics(null, null);
            this.nodeService.Verify(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>()));
        }

        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void GetBestFeasableSolution_requires_a_list_of_nodes()
        {
            this.SetUpSystemUnderTest();
            this.routeService.GetBestFeasableSolution(null, new DriverNode(new Driver()), new NodeRouteSolution());
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetBestFeasableSolution_requires_a_driver()
        {
            this.SetUpSystemUnderTest();
            this.routeService.GetBestFeasableSolution(this.nodes, null, new NodeRouteSolution());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void GetBestFeasableSolution_requires_a_list_of_nodes_with_stops()
        {
            this.nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            this.nodeService.Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>())).Returns(new NodeTiming());
            this.SetUpSystemUnderTest();
            this.routeService.GetBestFeasableSolution(new List<INode>(), new DriverNode(new Driver()), new NodeRouteSolution());
        }

        [Test]
        public void GetBestFeasableSolution_does_not_require_a_NodeRouteSolution()
        {
            this.nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            this.nodeService.Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>())).Returns(new NodeTiming());
            this.SetUpSystemUnderTest();
            var result = this.routeService.GetBestFeasableSolution(this.nodes, new DriverNode(new Driver()), null);
            Assert.AreEqual(null, result);
        }

        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void CreateRouteSolution_requires_a_collection_of_nodes()
        {
            this.SetUpSystemUnderTest();
            this.routeService.CreateRouteSolution(null, new DriverNode(new Driver()));
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateRouteSolution_requires_a_driver_node()
        {
            this.SetUpSystemUnderTest();
            this.routeService.CreateRouteSolution(this.nodes, null);
        }

        [Test]
        public void CreateRouteSolution_returns_a_NodeRouteSolution()
        {
            this.nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            this.SetUpSystemUnderTest();
            var result = this.routeService.CreateRouteSolution(this.nodes, new DriverNode(new Driver()));
            Assert.IsInstanceOf<NodeRouteSolution>(result);
        }

        [Test]
        public void CreateRouteSolution_returns_a_solution_whose_statistics_are_equal_to_the_sum_of_the_nodes_statastics()
        {
            this.nodeService.Setup(x => x.GetNodeConnection(this.driver, this.firstJob)).Returns(new NodeConnection { RouteStatistics = this.DriverToFirst });
            this.nodeService.Setup(x => x.GetNodeConnection(this.firstJob, this.secondJob)).Returns(new NodeConnection { RouteStatistics = this.FirstToSecond });
            this.nodeService.Setup(x => x.GetNodeConnection(this.secondJob, this.thirdJob)).Returns(new NodeConnection { RouteStatistics = this.SecondToThird });
            this.nodeService.Setup(x => x.GetNodeConnection(this.thirdJob, this.driver)).Returns(new NodeConnection { RouteStatistics = this.ThirdToDriver });
            this.SetUpSystemUnderTest();
            var result = this.routeService.CreateRouteSolution(this.nodes, this.driver as DriverNode);
            var checkResult = new RouteStatistics();
            checkResult = this.nodes.Aggregate(checkResult, (current, node) => current + node.RouteStatistics);
            checkResult += this.DriverToFirst;
            checkResult += this.FirstToSecond;
            checkResult += this.SecondToThird;
            checkResult += this.ThirdToDriver;
            Assert.AreEqual(checkResult.TotalTime, result.RouteStatistics.TotalTime);
        }

        [Test]
        public void CalculateRouteStatistics_sums_the_statistics_of_the_submitted_nodes()
        {
            this.nodeService.Setup(x => x.GetNodeConnection(this.driver, this.firstJob)).Returns(new NodeConnection { RouteStatistics = this.DriverToFirst });
            this.SetUpSystemUnderTest();
            var result = this.routeService.CalculateRouteStatistics(this.driver, this.firstJob);
            Assert.AreEqual(result, this.DriverToFirst);
        }

        [Test]
        public void GetBestSolution_returns_the_solution_with_the_greatest_number_of_JobNodes_that_is_feasible()
        {
            var solution = new NodeRouteSolution();
            this.nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            this.nodeService.Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>())).Returns(new NodeTiming{IsFeasableTimeWindow = true});
            this.SetUpSystemUnderTest();
            var result = this.routeService.GetBestFeasableSolution(this.nodes, this.driver as DriverNode, solution);
            Assert.AreNotEqual(solution, result);
        }

        List<INode> nodes
        {
            get
            {
                return new List<INode>
                    {
                        this.firstJob,
                        this.secondJob,
                        this.thirdJob
                    };
            }
        }

        [Test]
        public void GetBestSolution_return_the_NodeRouteSolution_with_the_most_job_nodes()
        {
            var left = new NodeRouteSolution
                {
                    Nodes = new List<INode>
                        {
                            new DriverNode(new Driver()),
                            new DriverNode(new Driver()),
                            new JobNode(),
                            new JobNode(),
                            new JobNode(),
                            new DriverNode(new Driver()),
                            new DriverNode(new Driver()),
                            new DriverNode(new Driver())
                        }
                };
            var right = new NodeRouteSolution
                {
                    Nodes = new List<INode>
                        {
                            new JobNode(),
                            new JobNode(),
                            new JobNode(),
                            new JobNode(),
                            new JobNode(),
                            new JobNode(),
                            new JobNode(),
                            new JobNode()
                        }
                };

            this.SetUpSystemUnderTest();
            var result = this.routeService.GetBestSolution(left, right);
            Assert.AreEqual(right, result);
            result = this.routeService.GetBestSolution(right, left);
            Assert.AreEqual(right, result);
        }

        [Test]
        public void GetBestSolution_return_the_Solution_with_the_most_job_nodes()
        {
            var left = new Solution
            {
                RouteSolutions = new List<NodeRouteSolution>
                    {
                        new NodeRouteSolution
                            {
                                Nodes = new List<INode>
                                        {
                                            new DriverNode(new Driver()),
                                            new DriverNode(new Driver()),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new DriverNode(new Driver()),
                                            new DriverNode(new Driver()),
                                            new DriverNode(new Driver())
                                        }
                            },
                        new NodeRouteSolution
                            {
                                Nodes = new List<INode>
                                        {
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode()
                                        }
                            },
                        new NodeRouteSolution
                            {
                                Nodes = new List<INode>
                                        {
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode()
                                        }
                            }
                    }
            };
            var right = new Solution
                {
                    RouteSolutions = new List<NodeRouteSolution>
                        {
                            new NodeRouteSolution
                                {
                                    Nodes = new List<INode>
                                        {
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode()
                                        }
                                },
                            new NodeRouteSolution
                                {
                                    Nodes = new List<INode>
                                        {
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode()
                                        }
                                },
                            new NodeRouteSolution
                                {
                                    Nodes = new List<INode>
                                        {
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode(),
                                            new JobNode()
                                        }
                                }
                        }
                };

            this.SetUpSystemUnderTest();
            var result = this.routeService.GetBestSolution(left, right);
            Assert.AreEqual(right, result);
            result = this.routeService.GetBestSolution(right, left);
            Assert.AreEqual(right, result);
        }
    }
}