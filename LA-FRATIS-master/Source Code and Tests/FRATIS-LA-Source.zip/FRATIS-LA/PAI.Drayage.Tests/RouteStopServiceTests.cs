using System;
using System.Collections.Generic;
using System.Linq;

using Moq;

using NUnit.Framework;

using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Tests
{
    public class RouteStopServiceTests : TestBase
    {
        Mock<IDistanceService> distanceService;
        Mock<IRouteStopDelayService> routeStopDelayService;
        const decimal testDistance = 1.5M;
        TimeSpan waitTime = new TimeSpan(1);
        TimeSpan travelTime = new TimeSpan(1);
        IList<RouteStop> stops = new List<RouteStop>
            {
                new RouteStop
                    {
                        Location = new Location(),
                        WindowEnd = new TimeSpan(12, 5, 0),
                        WindowStart = new TimeSpan(12, 0, 0)
                    },
                new RouteStop
                    {
                        Location = new Location(),
                        WindowEnd = new TimeSpan(13, 5, 0),
                        WindowStart = new TimeSpan(13, 0, 0)
                    },
                new RouteStop
                    {
                        Location = new Location(),
                        WindowEnd = new TimeSpan(14, 5, 0),
                        WindowStart = new TimeSpan(14, 0, 0)
                    }
            };

        readonly OptimizerConfiguration optimizerConfiguration =
            new OptimizerConfiguration
            {
                DefaultStopDelay = new TimeSpan(1, 1, 1, 1, 1),
                MaximumWaitTimeAtStop = new TimeSpan(0, 30, 0)
            };

        IRouteStopService routeStopService;
        IRouteStopService RouteStopService
        {
            get
            {
                return this.routeStopService ?? (this.routeStopService = new RouteStopService(this.distanceService.Object, this.optimizerConfiguration, this.routeStopDelayService.Object));
            }
        }

        [SetUp]
        public void SetUp()
        {
            this.routeStopService = null;
            base.BaseSetUp();
            this.distanceService = MockData.Kernel.GetMock<IDistanceService>();
            this.routeStopDelayService = MockData.Kernel.GetMock<IRouteStopDelayService>();
        }

         //TODO : check what happened to CalculateTripLength
        [Test]
        public void CalculateTripLength_delegates_distance_calculation_to_DistanceService_CalculateDistance()
        {
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.RouteStopService.CalculateTripLength(new RouteStop(), new RouteStop());
            this.distanceService.Verify(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>()), Times.Once);
        }

        [Test]
        public void CalculateRouteStatistics_calls_DistanceService_once_per_leg()
        {

            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.routeStopService = null;
            this.RouteStopService.CalculateRouteStatistics(this.stops, false);
            this.distanceService.Verify(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>()), Times.Exactly(this.stops.Count - 1));
        }

        [Test]
        public void CalculateRouteStatistics_returns_sum_of_the_leg_travel_time_and_distance()
        {
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.routeStopService = null;
            var result = this.RouteStopService.CalculateRouteStatistics(this.stops, false);
            Assert.AreEqual(testDistance * (this.stops.Count - 1), result.TotalTravelDistance);
            Assert.AreEqual(this.waitTime.Ticks * (this.stops.Count - 1), result.TotalTime.Ticks);
        }

        [Test]
        public void CalculateRouteSegmentStatistics_calculates_each_leg_and_sets_times()
        {
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.routeStopService = null;
            this.waitTime = this.stops[0].WindowStart;
            var result = this.RouteStopService.CalculateRouteSegmentStatistics(this.waitTime, this.stops);
            Assert.AreEqual(this.stops.Count - 1, result.Count);
            var currentTime = this.waitTime;
            for (var i = 0; i < this.stops.Count - 1; i++)
            {
                Assert.AreEqual(currentTime, result[i].StartTime);
                currentTime = result[i].EndTime;
                Assert.AreEqual(currentTime, result[i].EndTime);
            }
        }

        [Test]
        public void CreateRouteSegmentStatistics_sets_whiffed_if_arrival_time_is_late()
        {
            var startTime = this.stops[2].WindowEnd;
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.routeStopService = null;
            var result = this.RouteStopService.CalculateRouteSegmentStatistics(startTime, this.stops);

            Assert.IsTrue(result.All(x => x.WhiffedTimeWindow));
        }

        [Test]
        public void CreateRouteSegmentStatistics_sets_whiffed_if_arrival_time_is_earlier_than_configured_wait_time()
        {
            var waitTime = new TimeSpan(6, 0, 0);
            var startTime = this.stops[0].WindowStart.Subtract(waitTime);
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.routeStopService = null;
            var result = this.RouteStopService.CalculateRouteSegmentStatistics(startTime, this.stops);

            Assert.IsTrue(result.All(x => x.WhiffedTimeWindow));
        }

        [Test]
        public void CreateRouteSegmentStatistics_sets_wait_time_if_start_is_earlier_than_configured_wait_time()
        {
            var earlytime = new TimeSpan(1, 0, 0);
            var startTime = this.stops[0].WindowStart.Subtract(earlytime);
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, this.waitTime));
            this.routeStopService = null;
            var result = this.RouteStopService.CalculateRouteSegmentStatistics(startTime, this.stops);

            for (var i = 0; i < result.Count; i++)
            {
                Assert.AreNotEqual(TimeSpan.Zero.Ticks, result[i].Statistics.TotalWaitTime.Ticks);
            }
        }

        [Test]
        public void CreateRouteSegmentStatistics_does_not_sets_wait_time_or_whiffed_if_start_times_are_at_or_within_window()
        {
            this.waitTime = new TimeSpan(0, 5, 0);
            this.travelTime = new TimeSpan(1, 0, 0);
            this.optimizerConfiguration.MaximumWaitTimeAtStop = waitTime;

            var headStart = new TimeSpan(this.optimizerConfiguration.MaximumWaitTimeAtStop.Ticks / 2);
            var startTime = this.stops[1].WindowStart.Subtract(headStart).Subtract(travelTime);
            this.distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength{Distance = 0M, Time = travelTime});
            this.routeStopService = null;
            var result = this.RouteStopService.CalculateRouteSegmentStatistics(startTime, this.stops);

            for (var i = 0; i < result.Count; i++)
            {
                Assert.AreEqual(result[i].Statistics.TotalTime.Subtract(result[i].Statistics.TotalTravelTime), result[i].Statistics.TotalWaitTime);
                Assert.IsFalse(result[i].WhiffedTimeWindow);
            }
        }

        [Test]
        public void CreateRouteSegmentStatistics_delegates_to_Route_Stop_Delay_Service_to_get_execution_time()
        {
            this.routeStopDelayService.Setup(x => x.GetExecutionTime(It.IsAny<RouteStop>(), It.IsAny<TimeSpan>())).Returns(TimeSpan.Zero);
            this.routeStopService = null;
            var result = this.RouteStopService.CalculateRouteSegmentStatistics(this.stops[0].WindowStart, this.stops);
            this.routeStopDelayService.Verify(x => x.GetExecutionTime(It.IsAny<RouteStop>(), It.IsAny<TimeSpan>()), Times.Exactly(this.stops.Count - 1));
        }
    }
}