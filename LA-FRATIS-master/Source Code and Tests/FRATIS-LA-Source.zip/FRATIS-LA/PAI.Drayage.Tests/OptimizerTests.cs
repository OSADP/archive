using Moq;

using Ninject;

using NUnit.Framework;

using PAI.Core;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.FRATIS.Infrastructure;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;

using System;
using System.Collections.Generic;
using System.Linq;

namespace PAI.Drayage.Tests
{

    public class OptimizerTests : TestBase
    {
        private IList<Location> Locations { get; set; }
        private IList<Driver> Drivers { get; set; }
        private IList<Job> Jobs { get; set; }
        private Location StartLocation { get; set; }

        private IDrayageOptimizer _optimizer;
        private IDrayageOptimizer Optimizer
        {
            get
            {
               if (this._optimizer == null)
               {
                   this._optimizer = this.Kernel.Get<IDrayageOptimizer>();
                   this._optimizer.Initialize();
               }
               return this._optimizer;
            }
        }

        Driver placeHolderDriver;
        public Driver PlaceholderDriver
        {
            get
            {
                if (this.placeHolderDriver == null)
                {
                    this.placeHolderDriver =
                        new Driver()
                        {
                            DisplayName = "Placeholder Driver",
                            StartingLocation = this.StartLocation,
                            AvailableDrivingHours = 11,
                            AvailableDutyHours = 14
                        };
                }
                return this.placeHolderDriver;
            }
            set 
            { 
                this.placeHolderDriver = value;
            }
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IDrayageOptimizer>().To<DrayageOptimizer>().InSingletonScope();
            this.Kernel.Bind<IPheromoneMatrix>().To<PheromoneMatrix>().InSingletonScope()
                .WithConstructorArgument("initialPheromoneValue", 0.0)
                .WithConstructorArgument("rho", 0.5)
                .WithConstructorArgument("q", 1000.0);
            this.Kernel.Bind<IRouteExitFunction>().To<RouteExitFunction>().InSingletonScope();
            this.Kernel.Bind<IRouteService>().To<RouteService>().InSingletonScope();
            this.Kernel.Bind<IRouteStopDelayService>().To<RouteStopDelayService>().InSingletonScope();
            this.Kernel.Bind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            this.Kernel.Bind<IStatisticsService>().To<StatisticsService>().InSingletonScope();
            this.Kernel.Bind<IObjectiveFunction>().To<DistanceObjectiveFunction>().InSingletonScope();
            this.Kernel.Bind<IRandomNumberGenerator>().To<RandomNumberGenerator>().InSingletonScope();
            this.Kernel.Bind<IProbabilityMatrix>().To<ProbabilityMatrix>().InSingletonScope();
            this.Kernel.Bind<INodeFactory>().To<NodeFactory>().InSingletonScope();

            this.Kernel.Bind<ILogger>().To<NullLogger>().InSingletonScope();
            this.Kernel.Bind<INodeService>()
                .To<NodeService>()
                .InSingletonScope()
                .WithConstructorArgument("configuration", new OptimizerConfiguration());
            this.Kernel.Bind<IDistanceService>().To<DistanceService>().InSingletonScope();
            this.Kernel.Bind<ITravelTimeEstimator>().To<TravelTimeEstimator>().InSingletonScope();

            this.Kernel.Bind<IReportingService>().To<ReportingService>().InSingletonScope();    // todo verify scope
            this.Kernel.Bind<IRouteSanitizer>().To<RouteSanitizer>().InSingletonScope();    // todo verify scope

            // prepare mock data
            this.StartLocation = MockData.GetMockLocations(1, "Driver").FirstOrDefault();
            this.Locations = MockData.GetMockLocations(20);
            this.Drivers = MockData.GetMockDrivers(10, this.StartLocation);
            this.Jobs = MockData.GetJobs(50, this.Locations, true);
            this.PlaceholderDriver = null;
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DrayageOptimizer_requires_Drivers()
        {
            this.Optimizer.BuildSolution(
                null,
                this.PlaceholderDriver,
                this.Jobs);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DrayageOptimizer_requires_PlaceholderDrivers()
        {
            this.Optimizer.BuildSolution(
                this.Drivers,
                null,
                this.Jobs);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DrayageOptimizer_requires_Jobs()
        {
            this.Optimizer.BuildSolution(
                this.Drivers,
                this.PlaceholderDriver,
                null);
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void DrayageOptimizer_requires_Jobs_has_at_least_one_Job()
        {
            this.Optimizer.BuildSolution(
                this.Drivers,
                this.PlaceholderDriver,
                new List<Job>());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void DrayageOptimizer_must_be_initialized()
        {
            this._optimizer = this.Kernel.Get<IDrayageOptimizer>();
            this._optimizer.BuildSolution(
                this.Drivers,
                this.PlaceholderDriver,
                new List<Job>());
        }

        private class OptimizerParameters
        {
            public Mock<IProbabilityMatrix> ProbabilityMatrix { get; set; }
            public Mock<IRouteService> RouteService { get; set; }
            public Mock<INodeService> NodeService { get; set; }
            public Mock<IRouteStopService> RouteStopService { get; set; }
            public Mock<IRouteExitFunction> RouteExitFunction { get; set; }
            public Mock<ILogger> Logger { get; set; }
            public Mock<IPheromoneMatrix> PheromoneMatrix { get; set; }
            public Mock<IRandomNumberGenerator> RandomNumberGenerator { get; set; }
            public Mock<INodeFactory> NodeFactory { get; set; }

            public int PheromoneUpdateFrequency { get; set; }
            
            public OptimizerParameters()
            {
                this.ProbabilityMatrix = new Mock<IProbabilityMatrix>();
                this.RouteService = new Mock<IRouteService>();
                this.NodeService = new Mock<INodeService>();
                this.RouteStopService = new Mock<IRouteStopService>();
                this.RouteExitFunction = new Mock<IRouteExitFunction>();
                this.Logger = new Mock<ILogger>();
                this.PheromoneMatrix = new Mock<IPheromoneMatrix>();
                this.RandomNumberGenerator = new Mock<IRandomNumberGenerator>();
                this.NodeFactory = new Mock<INodeFactory>();
            }
        }

        [Test]
        public void Optimizer_Clears_Pheromone_Matrix()
        {
            var parameters = this.SetupOptimizerParameters();

            parameters.PheromoneMatrix.Verify(x => x.Clear());
        }

        [Test]
        public void BuildSolution_randomizes_the_list_of_drivers_and_jobs()
        {
            var parameters = this.SetupOptimizerParameters();

            parameters.RandomNumberGenerator.Verify(x => x.Next(), Times.Exactly(this.Drivers.Count + this.Jobs.Count));
        }

        [Test]
        public void BuildSolution_calls_RouteService_GetBestSolution()
        {
            var maxiterations = 50;
            var parameters = this.SetupOptimizerParameters(maxiterations);

            parameters.RouteService.Verify(x => x.GetBestSolution(It.IsAny<Solution>(), It.IsAny<Solution>()), Times.Exactly(maxiterations / 2));
        }

        [Test]
        public void BuildSolution_update_the_pheromone_matrix()
        {
            var parameters = this.SetupOptimizerParameters();

            parameters.PheromoneMatrix.Verify(x => x.UpdatePheromoneMatrix(It.IsAny<Solution>()), Times.Exactly(999 * parameters.PheromoneUpdateFrequency + 1));
        }

        [Test]
        public void GenerateRouteSolution_calls_probability_matrix_GetNominatedElement()
        {
            var parameters = this.SetupOptimizerParameters();

            parameters.ProbabilityMatrix.Verify(x => x.GetNominatedElement(It.IsAny<IList<ProbabilityItem>>()), Times.Exactly(500000));
        }

        [Test]
        public void GenerateRouteSolution_calls_RouteService_CreateRouteSolution()
        {
            var parameters = this.SetupOptimizerParameters();

            parameters.RouteService.Verify(x => x.CreateRouteSolution(It.IsAny<IEnumerable<INode>>(), It.IsAny<DriverNode>()), Times.Exactly(500000));
        }

        [Test]
        public void Can_prepare_mock_data()
        {
            Assert.That(this.StartLocation != null);
            Assert.That(this.Locations != null && this.Locations.Any(), "Mock Locations not ready");
            Assert.That(this.Drivers != null && this.Drivers.Any(), "Mock Drivers not ready");
            Assert.That(this.Jobs != null && this.Jobs.Any(), "Mock Jobs not ready");
        }

        [Test]
        public void Can_create_jobnode_with_jobnodefactory()
        {
            var job = this.Jobs.FirstOrDefault();
            var jobNodeFactory = this.Kernel.Get<INodeFactory>();

            var jobNode = jobNodeFactory.CreateJobNode(job);

            Assert.That(job != null);
            Assert.That(job.RouteStops != null);
            Assert.That(job.RouteStops.Count > 1);
            Assert.That(jobNode != null);            
        }

        /// <summary>
        /// Can build a simple optimization solution
        /// </summary>
        [Test]
        public void Can_build_solution()
        {
            var solution = this.Optimizer.BuildSolution(
                this.Drivers.Take(1).ToList(),
                this.PlaceholderDriver,
                this.Jobs.Take(5).ToList());

            Assert.That(solution != null, "Solution is null");
            Assert.That(solution.RouteSolutions.Any(), "Solution has no route solutions");
        }

        [Test]
        public void Can_test_route_stop_second_window()
        {
            var drivers = this.Drivers.Take(1).ToList();
            var job = this.Jobs.FirstOrDefault();

            var solution = this.Optimizer.BuildSolution(drivers, this.PlaceholderDriver, new List<Job>() { job });

            foreach (var rs in solution.RouteSolutions)
            {
                Console.WriteLine("Driver {0}", rs.DriverNode.Driver.DisplayName);
                var jobRouteStopEnumerator = job.RouteStops.GetEnumerator();
                
                foreach (var node in rs.Nodes)
                {
                    foreach (var routeStop in node.RouteStops)
                    {
                        jobRouteStopEnumerator.MoveNext();
                        Assert.GreaterOrEqual(jobRouteStopEnumerator.Current.WindowStart, routeStop.WindowStart);
                        Assert.LessOrEqual(routeStop.WindowEnd, jobRouteStopEnumerator.Current.WindowEnd);
                    }
                }
            }
        }

        OptimizerParameters SetupOptimizerParameters(int? maxIterations = null)
        {
            var parameters = new OptimizerParameters();

            var jobNode = new JobNode();
            jobNode.Job = new Job();

            parameters.NodeFactory
                      .Setup(x => x.CreateJobNode(It.IsAny<Job>()))
                      .Returns(jobNode);
            parameters.RouteStopService
                      .Setup(x => x.CalculateRouteStatistics(It.IsAny<IList<RouteStop>>(), false))
                      .Returns(new RouteStatistics());
            parameters.RouteService
                      .Setup(x => x.CreateRouteSolution(It.IsAny<IEnumerable<INode>>(), It.IsAny<DriverNode>()))
                      .Returns(new NodeRouteSolution());
            parameters.NodeService
                      .Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>()))
                      .Returns(new NodeTiming()
                          {
                              IsFeasableTimeWindow = true,
                              Node = jobNode
                          });
            parameters.NodeService
                      .Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>()))
                      .Returns(new NodeConnection());
            parameters.ProbabilityMatrix
                      .Setup(x => x.GetNominatedElement(It.IsAny<IList<ProbabilityItem>>()))
                      .Returns(jobNode);

            var optimizer =
                new DrayageOptimizer(
                    probabilityMatrix: parameters.ProbabilityMatrix.Object,
                    routeService: parameters.RouteService.Object,
                    nodeService: parameters.NodeService.Object,
                    routeStopService: parameters.RouteStopService.Object,
                    routeExitFunction: parameters.RouteExitFunction.Object,
                    logger: parameters.Logger.Object,
                    pheromoneMatrix: parameters.PheromoneMatrix.Object,
                    randomNumberGenerator: parameters.RandomNumberGenerator.Object,
                    nodeFactory: parameters.NodeFactory.Object
                    );

            optimizer.Initialize();
            if (maxIterations.HasValue)
            {
                optimizer.MaxIterations = maxIterations.Value;
            }
            parameters.PheromoneUpdateFrequency = optimizer.PheromoneUpdateFrequency;

            optimizer.BuildSolution(
                this.Drivers,
                this.PlaceholderDriver,
                this.Jobs
                );
            return parameters;
        }
    }
}