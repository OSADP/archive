using System;

using Moq;

using NUnit.Framework;

using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Tests
{
    public class StatisticsServiceTests : TestBase
    {
        Mock<IObjectiveFunction> objectiveFunction;

        IStatisticsService statisticsService;
        IStatisticsService StatisticsService
        {
            get
            {
                return this.statisticsService ?? (this.statisticsService = new StatisticsService(this.objectiveFunction.Object));
            }
        }

        [SetUp]
        public void SetUp()
        {
            this.statisticsService = null;
            this.objectiveFunction = this.Kernel.GetMock<IObjectiveFunction>();
        }

        [Test]
        public void CompareRouteStatistics_delegates_to_ObjectiveFunction_to_evaluate_statistics()
        {
            this.objectiveFunction.Setup(x => x.GetObjectiveMeasure(It.IsAny<RouteStatistics>())).Returns(default(double));
            this.StatisticsService.CompareRouteStatistics(new RouteStatistics(), new RouteStatistics());
            this.objectiveFunction.Verify(x => x.GetObjectiveMeasure(It.IsAny<RouteStatistics>()), Times.Exactly(2));
        }

        [Test]
        public void CompareRouteStatistics_returns_the_route_with_the_greatest_value()
        {
            var leftRoute = new RouteStatistics
                {
                    TotalTravelTime = new TimeSpan(1)
                };
            var rightRoute = new RouteStatistics
            {
                TotalTravelTime = new TimeSpan(100)
            };
            this.objectiveFunction.Setup(x => x.GetObjectiveMeasure(leftRoute)).Returns(2.5);
            this.objectiveFunction.Setup(x => x.GetObjectiveMeasure(rightRoute)).Returns(20.5);
            var result = this.StatisticsService.CompareRouteStatistics(leftRoute, rightRoute);
            Assert.AreEqual(-1, result);
            result = this.StatisticsService.CompareRouteStatistics(rightRoute, leftRoute);
            Assert.AreEqual(1, result);
            result = this.StatisticsService.CompareRouteStatistics(leftRoute, leftRoute);
            Assert.AreEqual(0, result);
        }
    }
}