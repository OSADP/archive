using System;
using System.Linq;

using NUnit.Framework;

using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Tests
{
    public class RouteStopDelayServiceTests : TestBase
    {
        IRouteStopDelayService routeStopDelayService;

        OptimizerConfiguration optimizerConfiguration =
            new OptimizerConfiguration
                {
                    DefaultStopDelay = new TimeSpan(1, 1, 1, 1, 1)
                };

        IRouteStopDelayService RouteStopDelayService
        {
            get
            {
                return this.routeStopDelayService ?? (this.routeStopDelayService = new RouteStopDelayService(this.optimizerConfiguration));
            }
        }

        [SetUp]
        public void SetUp()
        {
            this.optimizerConfiguration = new OptimizerConfiguration
                {
                    DefaultStopDelay = new TimeSpan(1, 1, 1, 1, 1)
                };
            this.routeStopDelayService = new RouteStopDelayService(this.optimizerConfiguration);
        }

        [Test]
        public void GetDelay_return_no_time_for_NoAction()
        {
            Assert.AreEqual(TimeSpan.Zero, this.RouteStopDelayService.GetDelay(StopActions.NoAction));
        }

        [Test]
        public void GetDelay_with_location_returns_same_value_as_GetDelay_without_location()
        {
            var testLocation = new Location
                {
                    DisplayName = string.Empty,
                    Id = 0,
                    Latitude = default(double),
                    Longitude = default(double)
                };

            foreach (var stopAction in StopActions.Actions)
            {
                Assert.AreEqual(this.routeStopDelayService.GetDelay(stopAction), this.routeStopDelayService.GetDelay(stopAction, testLocation));
            }
        }

        [Test]
        public void All_Delays_except_NoAction_return_Configuration_default_value()
        {
            var actions = StopActions.Actions.Except(new []{StopActions.NoAction}).ToList();
            foreach (var stopAction in actions)
            {
                Assert.AreEqual(this.optimizerConfiguration.DefaultStopDelay, this.routeStopDelayService.GetDelay(stopAction));
            }
        }
    }
}