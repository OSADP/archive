﻿using Ninject.MockingKernel.Moq;

using NUnit.Framework;

namespace PAI.Drayage.Tests
{
    public class TestBase
    {
        public MoqMockingKernel Kernel { get; set; }

        [SetUp]
        public void BaseSetUp()
        {
            this.Kernel = new MoqMockingKernel();
            MockData.Kernel = this.Kernel;
        }
    }
}
