//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using Moq;

using NUnit.Framework;

using Ninject;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace PAI.Drayage.Tests
{

    public class NodeServiceTests : TestBase
    {
        INodeService nodeService;
        INodeService NodeService
        {
            get { return this.nodeService ?? (this.nodeService = this.Kernel.Get<INodeService>()); }
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            this.Kernel.Bind<INodeService>().To<NodeService>().InSingletonScope();
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetNodeConnection_requires_a_startNode()
        {
            this.NodeService.GetNodeConnection(default(INode), default(INode));
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetNodeConnection_requires_a_endNode()
        {
            var start = new JobNode();
            this.NodeService.GetNodeConnection(start, default(INode));
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void GetNodeConnection_requires_startNode_contains_stops()
        {
            this.NodeService.GetNodeConnection(new JobNode(), new JobNode());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void GetNodeConnection_requires_endNode_contains_stops()
        {
            var start = new JobNode();
            start.RouteStops.Add(new RouteStop());
            this.NodeService.GetNodeConnection(start, new JobNode());
        }

        [Test]
        public void GetNodeConnection_delegates_to_RouteStopService_to_calculate_stastics_for_connection()
        {
            var routeStopService = new Mock<IRouteStopService>();

            var nodeService = new NodeService(routeStopService.Object, new OptimizerConfiguration());

            nodeService.GetNodeConnection(this.MakeTestJobNode(), this.MakeTestJobNode());

            routeStopService.Verify(x => x.CalculateRouteStatistics(It.IsAny<IList<RouteStop>>(), It.IsAny<bool>()));
        }

        [Test]
        public void GetNodeTiming_correctly_assigns_IsFeasableTimeWindow_to_false()
        {

            var startNode = this.MakeDriverNode();
            var endNode = this.MakeTestJobNodeWithStops(false, 8);

            var result = this.NodeService.GetNodeTiming(startNode, endNode, new TimeSpan(), new RouteStatistics());
            Assert.IsFalse(result.IsFeasableTimeWindow);
        }

        [Test]
        public void GetNodeTiming_correctly_assigns_IsFeasableTimeWindow_to_true()
        {

            var startNode = this.MakeDriverNode();
            var endNode = this.MakeTestJobNodeWithStops(true, 3);

            var result = this.NodeService.GetNodeTiming(startNode, endNode, new TimeSpan(), new RouteStatistics());
            Assert.IsTrue(result.IsFeasableTimeWindow);
        }

        DriverNode MakeDriverNode()
        {
            return new DriverNode(new Driver());
        }

        JobNode MakeTestJobNode()
        {
            return new JobNode
                {
                    RouteStops = new List<RouteStop>()
                        {
                            new RouteStop()
                                {
                                    StopDelay = new TimeSpan(0, 30, 0)
                                }
                        }
                };
        }

        JobNode MakeTestJobNodeWithStops(bool makeFeasible, int numberOfStops)
        {
            if (numberOfStops < 3)
                numberOfStops = 3;

            var rng = new RandomNumberGenerator();
            rng.Reseed(0);

            var jobNode =
                new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics(),
                    RouteStops = new List<RouteStop>(),
                    WindowStart = new TimeSpan(0, 0, 0),
                    WindowEnd = new TimeSpan(23, 59, 59)
                };

            for (var i = 0; i < numberOfStops; i++)
            {
                jobNode.RouteStops.Add(
                    new RouteStop()
                        {
                            Location = new Location
                                {
                                    Latitude = rng.NextDouble() + 32,
                                    Longitude = rng.NextDouble() - 97
                                },
                            Id = i,
                            PreTruckConfig = new TruckConfiguration(),
                            PostTruckConfig = new TruckConfiguration(),
                            StopAction = (i % 2 == 0) ? StopActions.PickupEmpty : StopActions.DropOffEmpty,
                            StopDelay = new TimeSpan(0, 15, 0),
                            WindowStart = new TimeSpan(9 + i, 0, 0),
                            WindowEnd = new TimeSpan(10 + i, 30, 0)
                        });
            }

            if (!makeFeasible)
            {
                jobNode.RouteStops.Last().WindowStart += new TimeSpan(50, 0, 0);
                jobNode.RouteStops.Last().WindowEnd += new TimeSpan(50, 0, 0);
            }

            return jobNode;
        }
    }
}