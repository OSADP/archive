﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;

using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.FRATIS.ConsoleDemo
{
    /// <summary>
    /// Helper class used to create Jobs for the console application
    /// </summary>
    public interface IJobHelper
    {
        /// <summary>
        /// Creates the route stop.
        /// </summary>
        /// <param name="job">The job.</param>
        /// <param name="sa">The stop action undertaken at the stop.</param>
        /// <param name="location">The location of the stop.</param>
        /// <param name="stopDelay">The suration of the activity performed at the stop.</param>
        /// <param name="windowStart">The time the stop can begin execution.</param>
        /// <param name="windowEnd">The time the stop must complete execution.</param>
        /// <returns>A configured Route Stop object</returns>
        RouteStop CreateRouteStop(Job job, StopAction sa, Location location,
                                          TimeSpan stopDelay, TimeSpan windowStart, TimeSpan windowEnd);

        /// <summary>
        /// Gets a time span of the specified duration.
        /// </summary>
        /// <param name="minutes">The desired duration in minutes.</param>
        /// <returns>A TimeSpan of minutes duration</returns>
        TimeSpan GetTimeSpan(int minutes);
    }

    /// <summary>
    /// Helper class used to create Jobs for the console application
    /// </summary>
    public class JobHelper : IJobHelper
    {
        /// <summary>
        /// Creates the route stop.
        /// </summary>
        /// <param name="job">The job.</param>
        /// <param name="sa">The stop action undertaken at the stop.</param>
        /// <param name="location">The location of the stop.</param>
        /// <param name="stopDelay">The suration of the activity performed at the stop.</param>
        /// <param name="windowStart">The time the stop can begin execution.</param>
        /// <param name="windowEnd">The time the stop must complete execution.</param>
        /// <returns>A configured Route Stop object</returns>
        public RouteStop CreateRouteStop(Job job, StopAction sa, Location location, TimeSpan stopDelay, TimeSpan windowStart, TimeSpan windowEnd)
        {
            if (sa == null) { throw new Exception("Stop Action is required"); }
            if (job == null) { throw new Exception("Job is invalid"); }

            return new RouteStop()
                {
                    Id = 1,
                    Location = location,
                    PostTruckConfig = null,
                    PreTruckConfig = null,
                    StopAction = sa,
                    StopDelay = stopDelay,
                    WindowStart = windowStart,
                    WindowEnd = windowEnd
                };
        }

        /// <summary>
        /// Gets a time span of the specified duration.
        /// </summary>
        /// <param name="minutes">The desired duration in minutes.</param>
        /// <returns>A TimeSpan of minutes duration</returns>
        public TimeSpan GetTimeSpan(int minutes)
        {
            return new TimeSpan(0, minutes, 0);
        }

        /// <summary>
        /// Gets a time span of the specified duration.
        /// </summary>
        /// <param name="hours">The desired duration's hours length.</param>
        /// <param name="minutes">The desired duration's minutes length.</param>
        /// <returns>A TimeSpan of hours and minutes duration</returns>
        public TimeSpan GetTimeSpan(int hours, int minutes)
        {
            return new TimeSpan(hours, minutes, 0);
        }
    }
}
