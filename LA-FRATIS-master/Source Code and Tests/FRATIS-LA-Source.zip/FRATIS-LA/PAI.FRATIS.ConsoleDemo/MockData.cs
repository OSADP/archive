﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using Ninject;

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.FRATIS.Domain.Geography;
using Location = PAI.Drayage.Optimization.Model.Location;
using LocationQueueDelay = PAI.Drayage.Optimization.Model.LocationQueueDelay;

namespace PAI.FRATIS.ConsoleDemo
{
    /// <summary>
    /// Pregenerated data used for testing purposes.
    /// </summary>
    public static class MockData
    {
        private static JobHelper _helper = null;
        /// <summary>
        /// Gets the job helper object.
        /// </summary>
        /// <value>
        /// The job helper object.
        /// </value>
        public static JobHelper Helper
        {
            get { return _helper ?? (_helper = new JobHelper()); }
        }

        private static IRandomNumberGenerator _randomNumberGenerator;
        private static IRandomNumberGenerator RandomNumberGenerator
        {
            get
            {
                return _randomNumberGenerator ?? (_randomNumberGenerator = GetService<IRandomNumberGenerator>());
            }
        }

        /// <summary>
        /// Gets the service from the Dependancy Injection controller.
        /// </summary>
        /// <typeparam name="TInterface">The type of the interface.</typeparam>
        /// <returns>An object that implements the desired interface</returns>
        public static TInterface GetService<TInterface>()
        {
            try
            {
                var result = Program.Kernel.Get<TInterface>();
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// Gets the mock drivers.
        /// </summary>
        /// <param name="count">The number of drivers to create.</param>
        /// <param name="startLocation">The home location of the driver.</param>
        /// <param name="availableDrivingHours">The available driving hours for the drivers.</param>
        /// <param name="availableDutyHours">The available duty hours for the drivers.</param>
        /// <returns>A list of generated drivers</returns>
        public static IList<Driver> GetMockDrivers(int count = 10,
            Location startLocation = null,
            double availableDrivingHours = 10,
            double availableDutyHours = 11)
        {
            IList<Driver> result = new List<Driver>();
            if (startLocation == null)
            {
                startLocation = GetMockLocations(1, "Driver").FirstOrDefault();
            }

            for (int i = 0; i < count; i++)
            {
                RandomNumberGenerator.Reseed(i);
                var orderType = RandomNumberGenerator.Next(1, 4);
                var isShortHaul = RandomNumberGenerator.Next(1, 3) == 1;
                var isHazmat = RandomNumberGenerator.Next(1, 4) == 1;

                result.Add(new Driver()
                {
                    Id = i + 1,
                    AvailableDrivingHours = 8.0,
                    AvailableDutyHours = 10.0,
                    DisplayName = string.Format("Driver {0}", i + 1),
                    EarliestStartTime = TimeSpan.FromHours(6),
                    StartingLocation = startLocation
                });
            }

            return result;
        }

        private static double GetMockLongitude()
        {
            return double.Parse(string.Format("-98.{0}", RandomNumberGenerator.Next(99999)));
        }

        private static double GetMockLatitude()
        {
            return double.Parse(string.Format("33.{0}", RandomNumberGenerator.Next(99999)));
        }

        /// <summary>
        /// Gets the mock locations.
        /// </summary>
        /// <param name="count">The number of locations to create.</param>
        /// <param name="displayNamePrefix">The display name prefix.</param>
        /// <returns>A list of locations</returns>
        public static IList<Location> GetMockLocations(int count, string displayNamePrefix = "")
        {
            IList<Location> result = new List<Location>();
            for (int i = 0; i < count; i++)
            {
                result.Add(new Location()
                {
                    DisplayName = string.Format("{0} Location {1}", displayNamePrefix, i + 1).Trim(),
                    Latitude = GetMockLatitude(),
                    Longitude = GetMockLongitude(),
                    Id = i + 1
                });
            }
            return result;
        }

        /// <summary>
        /// Gets the mock location queue delays.
        /// </summary>
        /// <param name="locations">The locations for which to create random queue delays.</param>
        /// <returns>a list of random queue delays for the locations submitted</returns>
        public static IList<LocationQueueDelay> GetMockLocationQueueDelays(IEnumerable<Location> locations)
        {
            var result = new List<LocationQueueDelay>();
            foreach (var location in locations)
            {
                var random = new Random();
                var numberOfDelaysToCreate = random.Next(1, 5);
                var dayWindow = new TimeSpan(24, 0, 0).Ticks/numberOfDelaysToCreate;
                for (var i = 0; i < numberOfDelaysToCreate; i++)
                {
                    var partOfDay = (dayWindow) * i + 1;
                    var delayLength = random.Next(30, 90);
                    var windowOffset = random.Next(0, Convert.ToInt32(new TimeSpan(dayWindow).TotalMinutes - delayLength));
                    var delayStart = new TimeSpan(partOfDay).Add(new TimeSpan(0, windowOffset, 0)).Ticks;
                    var delayEnd = new TimeSpan(delayStart).Add(new TimeSpan(0, delayLength, 0)).Ticks;
                    
                    var queueDelay = new LocationQueueDelay
                        {
                            DelayStartTime = 0,
                            DelayEndTime = delayEnd,
                            LocationId = location != null ? location.Id : default(int?),
                            QueueDelay = delayLength
                        };
                    result.Add(queueDelay);
                }
            }
            return result;
        }

        public static IList<LocationDistance> GetMockLocationDistances(IEnumerable<Location> locations)
        {
            var result = new List<LocationDistance>();
            var locs = locations.ToList();
            var counter = 0;
            var random = new Random();
            foreach (var location in locs)
            {
                foreach (var loc in locs.Except(new List<Location>{location}))
                {
                    foreach (var day in Enum.GetValues(typeof(DayOfWeek)).Cast<DayOfWeek>())
                    {
                        var existingLeg = result.FirstOrDefault(x => x.StartLocationId == loc.Id && x.EndLocationId == location.Id);
                        var distance = Convert.ToDecimal(random.Next(1, 1000));
                        if (existingLeg != null)
                        {
                            distance = existingLeg.Distance ?? Convert.ToDecimal(random.Next(1, 1000));
                        }
                        var locationDistance = new LocationDistance
                        {
                            StartLocation = new PAI.FRATIS.Domain.Geography.Location
                            {
                                Id = location.Id,
                                Longitude = location.Longitude,
                                Latitude = location.Latitude
                            },
                            StartLocationId = location.Id,
                            EndLocation = new PAI.FRATIS.Domain.Geography.Location
                            {
                                Id = loc.Id,
                                Longitude = loc.Longitude,
                                Latitude = loc.Latitude
                            },
                            EndLocationId = loc.Id,
                            DayOfWeek = (int)day,
                            Id = ++counter,
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now,
                            Distance = distance,
                            TravelTime = Convert.ToInt64(distance)
                        };
                        for (var i = 0; i < 24; i++)
                        {
                            locationDistance.Hours[i] = new HourDistanceInfo
                                {
                                    TravelTime = locationDistance.TravelTime*random.Next(1, 10)
                                };
                        }
                        result.Add(locationDistance);
                    }
                }
            }
            return result;
        }


        /// <summary>
        /// Gets a random location from the supplied list.
        /// </summary>
        /// <param name="locations">The lsit of locations to select from.</param>
        /// <returns>a random location from the list</returns>
        public static Location GetRandomLocation(IList<Location> locations)
        {
            RandomNumberGenerator.Reseed(0);
            return locations[RandomNumberGenerator.Next(0, locations.Count - 1)];
        }

        /// <summary>
        /// Gets a list of random locations from the supplied list.
        /// </summary>
        /// <param name="count">The number of locations to select.</param>
        /// <param name="locations">The list of locations from which selections are made.</param>
        /// <param name="allowRepeatLocations">if set to <c>true</c> allows the same index from the source list to be selected multiple times.</param>
        /// <returns>a list of locations randomly selected from the source</returns>
        public static IList<Location> GetRandomLocations(int count, IList<Location> locations, bool allowRepeatLocations = false)
        {
            var result = new List<Location>();
            var usedIndexes = new HashSet<int>();

            for (int i = 0; i < count && count <= locations.Count; )
            {
                var randomIndex = RandomNumberGenerator.Next(locations.Count);
                if (allowRepeatLocations || !usedIndexes.Contains(randomIndex))
                {
                    usedIndexes.Add(randomIndex);
                    result.Add(locations[randomIndex]);
                    i++;
                }
                else
                {
                    // do not increment, try again
                }
            }
            return result;
        }

        /// <summary>
        /// Generates a list of jobs.
        /// </summary>
        /// <param name="count">The number of jobs to generate.</param>
        /// <param name="locations">The location list at which job stops may occur.</param>
        /// <param name="twoStopsPerJob">if set to <c>true</c> generates a Pick Up Empty Stop and Drop Off Empty Stop, otherwise generates a No Action stop.</param>
        /// <returns>a random list of jobs</returns>
        public static IList<Job> GetJobs(int count, IList<Location> locations, bool twoStopsPerJob = true)
        {
            IList<Job> result = new List<Job>();
            var routeSanitizer = GetService<IRouteSanitizer>();
            RandomNumberGenerator.Reseed(locations.Count());
            for (int i = 0; i < count; i++)
            {
                _randomNumberGenerator.Reseed(i);
                var orderType = RandomNumberGenerator.Next(1, 4);
                var isShortHaul = RandomNumberGenerator.Next(1, 3) == 1;
                var isHazmat = RandomNumberGenerator.Next(1, 4) == 1;

                var job = new Job()
                {
                    Id = i + 1,
                    DisplayName = string.Format("Job {0}", i + 1),
                    EquipmentConfiguration =
                        new EquipmentConfiguration(
                            new Chassis(), new Container(), new ChassisOwner(), new ContainerOwner()),
                };

                if (twoStopsPerJob)
                {
                    var stopLocations = GetRandomLocations(2, locations, false);
                    var rs1 = Helper.CreateRouteStop(job, StopActions.PickupLoadedWithChassis,
                        stopLocations[0], Helper.GetTimeSpan(30), Helper.GetTimeSpan(0, 0), Helper.GetTimeSpan(24, 0));

                    var rs2 = Helper.CreateRouteStop(job, StopActions.DropOffLoadedWithChassis,
                        stopLocations[1], Helper.GetTimeSpan(30), Helper.GetTimeSpan(12, 0), Helper.GetTimeSpan(14, 0));

                    job.RouteStops.Add(rs1);
                    job.RouteStops.Add(rs2);
                }
                else
                {
                    var rs = Helper.CreateRouteStop(job, StopActions.NoAction,
                        GetRandomLocation(locations), Helper.GetTimeSpan(30), Helper.GetTimeSpan(6, 0), Helper.GetTimeSpan(8, 0));
                    job.RouteStops.Add(rs);
                }

                // route sanitization
                routeSanitizer.PrepareJob(job);

                result.Add(job);
            }

            return result;
        }

        /// <summary>
        /// Gets a list of 2 drivers.
        /// </summary>
        /// <returns>A list of 2 drivers</returns>
        public static IList<Driver> GetStaticDrivers()
        {
            var locations = GetStaticLocations();
            return new List<Driver>()
                {
                    new Driver()
                        {
                            DisplayName = "Driver 1",
                            AvailableDrivingHours = 10,
                            AvailableDutyHours = 11,
                            EarliestStartTime = new TimeSpan(6, 0, 0),
                            StartingLocation = locations[0]
                        },
                    new Driver()
                        {
                            DisplayName = "Driver 2",
                            AvailableDrivingHours = 10,
                            AvailableDutyHours = 11,
                            EarliestStartTime = new TimeSpan(6, 0, 0),
                            StartingLocation = locations[0]
                        },
                };
        }

        /// <summary>
        /// Gets a lsit of 4 locations.
        /// </summary>
        public static IList<Location> GetStaticLocations()
        {
            return new List<Location>()
                {
                    new Location() { DisplayName = "Start Location", Latitude = 0.0, Longitude = 0.0 },
                    new Location() { DisplayName = "Location 1", Latitude = -2, Longitude = 1 },
                    new Location() { DisplayName = "Location 2", Latitude = 1, Longitude = 3 },
                    new Location() { DisplayName = "Location 3", Latitude = 3, Longitude = 0.5 }
                };
        }

        /// <summary>
        /// Gets a static list of 2 jobs.
        /// </summary>
        /// <returns>A static list of 2 jobs</returns>
        public static IList<Job> GetStaticJobs()
        {
            var locations = GetStaticLocations();
            var routeSanitizer = GetService<IRouteSanitizer>();

            var job1 = new Job() { DisplayName = "Job 1" };
            job1.RouteStops = new List<RouteStop>()
                {
                    Helper.CreateRouteStop(
                        job1,
                        StopActions.NoAction,
                        locations[1],
                        TimeSpan.FromMinutes(30),
                        TimeSpan.FromHours(0),
                        TimeSpan.FromHours(24))
                };
            routeSanitizer.PrepareJob(job1);

            var job2 = new Job() { DisplayName = "Job 2" };
            job2.RouteStops = new List<RouteStop>()
                {
                    Helper.CreateRouteStop(
                        job2,
                        StopActions.NoAction,
                        locations[2],
                        TimeSpan.FromMinutes(30),
                        TimeSpan.FromHours(0),
                        TimeSpan.FromHours(24))
                };
            routeSanitizer.PrepareJob(job2);

            return new[] { job1, job2 };
        }
    }
}
