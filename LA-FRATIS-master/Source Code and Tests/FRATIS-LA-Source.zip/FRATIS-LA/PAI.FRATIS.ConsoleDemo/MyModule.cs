﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using Ninject.Modules;

using PAI.Core;
using PAI.Drayage.Optimization.Adapter.Services;
using PAI.FRATIS.Data;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Infrastructure;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;
using PAI.FRATIS.Infrastructure.Data;
using PAI.FRATIS.Infrastructure.Engine;

using Ninject;
using Ninject.Extensions.NamedScope;
using Ninject.Extensions.Conventions;

namespace PAI.FRATIS.ConsoleDemo
{
    /// <summary>
    /// Configuration class to set up dependancy injection
    /// </summary>
    class MyModule : NinjectModule 
    {
        /// <summary>
        /// Binds the implementation classes to the interfaces for dependancy injection
        /// </summary>
        public override void Load()
        {
            Kernel.Bind(
                x => x.FromAssembliesMatching("PAI.*").SelectAllClasses().Excluding(new[] { typeof(Engine) })
                    .BindDefaultInterfaces().Configure(b => b.InThreadScope()));

            Kernel.Rebind(typeof(IRepository<>))
                  .To(typeof(EfRepository<>))
                  .InThreadScope();

            Kernel.Rebind<IDbContext>()
                .To<DataContext>()
                .InThreadScope()
                .WithConstructorArgument("nameOrConnectionString", ConnectionStringManager.ConnectionString);

            this.Rebind<ICacheManager>().To<MemoryCacheManager>().InSingletonScope();

            //Kernel.Bind(
            //    x => x.FromAssembliesMatching("PAI.Drayage.Optimization.Adapter.*").SelectAllClasses().Excluding(new[] { typeof(Engine) })
            //        .BindDefaultInterfaces().Configure(b => b.InThreadScope()));


            Rebind<IPlanGenerator>().To<PlanGenerator>().DefinesNamedScope("OptimizationRun");

            this.Rebind<IDrayageOptimizer>().To<DrayageOptimizer>().InSingletonScope();
            this.Rebind<IPheromoneMatrix>().To<PheromoneMatrix>().InSingletonScope()
                .WithConstructorArgument("initialPheromoneValue", 0.0)
                .WithConstructorArgument("rho", 0.5)
                .WithConstructorArgument("q", 1000.0);
            this.Rebind<IRouteExitFunction>().To<RouteExitFunction>().InSingletonScope();
            this.Rebind<IRouteService>().To<RouteService>().InSingletonScope();
            this.Rebind<IRouteStopDelayService>().To<RouteStopDelayService>().InSingletonScope();
            this.Rebind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            this.Rebind<IStatisticsService>().To<StatisticsService>().InSingletonScope();
            this.Rebind<IObjectiveFunction>().To<DistanceObjectiveFunction>().InSingletonScope();
            this.Rebind<IRandomNumberGenerator>().To<RandomNumberGenerator>().InSingletonScope();
            this.Rebind<IProbabilityMatrix>().To<ProbabilityMatrix>().InSingletonScope();
            this.Rebind<INodeFactory>().To<NodeFactory>().InSingletonScope();
            
            this.Rebind<ILogger>().To<NullLogger>().InSingletonScope();
            this.Rebind<INodeService>()
                .To<NodeService>()
                .InSingletonScope()
                .WithConstructorArgument("configuration", new OptimizerConfiguration());
            this.Rebind<IDistanceService>().To<CachedDistanceService>().InSingletonScope();
            this.Rebind<ITravelTimeEstimator>().To<TravelTimeEstimator>().InSingletonScope();

            Rebind<IDistanceService>().To<DistanceService>()
                .WhenInjectedInto<SuperDistanceService>()
                .InNamedScope("OptimizationRun");

            Bind<IDistanceService>().To<SuperDistanceService>()
                .WhenInjectedInto<CachedDistanceService>()
                .InNamedScope("OptimizationRun");

            //Bind<IDistanceService>().To<DistanceService>().WhenInjectedInto<SuperDistanceService>();

            Bind<IDistanceService>().To<CachedDistanceService>().WhenInjectedInto<RouteStopService>().DefinesNamedScope("RouteStopDistance");

            Bind<IDistanceService>().To<DistanceService>().InNamedScope("RouteStopDistance");


            this.Rebind<IReportingService>().To<ReportingService>().InSingletonScope();
            this.Rebind<IRouteSanitizer>().To<RouteSanitizer>().InSingletonScope();    
        }
    }
}