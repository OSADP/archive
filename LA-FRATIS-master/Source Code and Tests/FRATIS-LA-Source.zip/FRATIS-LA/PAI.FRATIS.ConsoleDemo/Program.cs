﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;

using Ninject;

using System;
using System.Linq;

using PAI.Drayage.Optimization.Adapter.Services;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;
using PAI.FRATIS.Domain.Geography;

using LocationQueueDelay = PAI.Drayage.Optimization.Model.LocationQueueDelay;

namespace PAI.FRATIS.ConsoleDemo
{
    class Program
    {
        private static JobHelper _helper = null;
        /// <summary>
        /// Helper class that configures jobs for optimization
        /// </summary>
        /// <value>
        /// The job helper object.
        /// </value>
        public static JobHelper Helper
        {
            get { return _helper ?? (_helper = new JobHelper()); }
        }

        /// <summary>
        /// Gets or sets the dependancy injection manager.
        /// </summary>
        /// <value>
        /// The dependancy injection manager.
        /// </value>
        public static IKernel Kernel{ get; set; }

        private static void Initialize()
        {
            IKernel kernel = new StandardKernel(new MyModule());
            Kernel = kernel;
        }

        /// <summary>
        /// Gets the service by interface from the dependancy injection manager.
        /// </summary>
        /// <typeparam name="TInterface">The type of the interface to instantiate.</typeparam>
        /// <returns>An object that is the configured implementation of the requested interface.</returns>
        public static TInterface GetService<TInterface>()
        {
            try
            {
                var result = Kernel.Get<TInterface>();
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        static void Main(string[] args)
        {
            Initialize();   // Initialization of Ninject - Dependency Injection

            // set up demo data.
            var startLocation = MockData.GetMockLocations(1, "Driver").FirstOrDefault();
            var locations = MockData.GetMockLocations(6);
            var drivers = MockData.GetMockDrivers(3, startLocation);
            var jobs = MockData.GetJobs(8, locations, true);

            var queueDelays = MockData.GetMockLocationQueueDelays(locations);

            var locationTravelDelays = MockData.GetMockLocationDistances(locations);

            // initialize the Optimization service
            var planGenerator = GetService<IPlanGenerator>();            
            
            // solution iterations
            for (int i = 0; i < 9; i++)
            {
                Console.Write("\n\nOptimizing... ");
                // build the solution
                var solution = planGenerator.GeneratePlan(drivers, jobs, DayOfWeek.Saturday, queueDelays, locationTravelDelays);

                Console.Write("Done!\n");
                // generate statistics
                var reportingService = GetService<IReportingService>();
                var solutionPerformance = reportingService.GetSolutionPerformanceStatistics(solution);

                // output results
                Console.WriteLine("Solution Created");
                Console.WriteLine(solution.RouteSolutions.Count.ToString() + " route solutions.");
                Console.WriteLine(solution.UnassignedJobNodes.Count.ToString() + " unassigned jobs.");
                Console.WriteLine(solution.RouteStatistics.TotalTime.ToString() + " : total time.\n");

                // iterate through generated routes
                foreach (var routeSolution in solution.RouteSolutions)
                {
                    Console.WriteLine(string.Format("Solution for Driver {0}\n", routeSolution.DriverNode.Driver.DisplayName));
                    Console.WriteLine(string.Format("\tStart Location -\n\t\t{0}", routeSolution.AllNodes.FirstOrDefault().RouteStops.FirstOrDefault().Location.DisplayName));
                    Console.WriteLine(string.Format("\tStart Time -\n\t\t{0}", routeSolution.DriverNode.Driver.EarliestStartTime));
                    
                    int stopCount = 0;
                    // select the drivers statistics from the truck collection by driver name
                    var driverStatistics =
                        solutionPerformance.TruckStatistics.FirstOrDefault(
                            p => p.Key.DriverNode.Driver.Id == routeSolution.DriverNode.Driver.Id).Value;

                    // iterate through each order
                    foreach (var node in routeSolution.Nodes)
                    {
                        var jn = node as JobNode;
                        Console.WriteLine(string.Format("\n\tOrder {0}", jn.Job.DisplayName));

                        var startStatistics = driverStatistics.RouteSegmentStatistics[0];
                        if (startStatistics.Statistics.TotalWaitTime.TotalSeconds > 0)
                        {
                            Console.WriteLine(string.Format("\t\t\tWait for {0}", startStatistics.Statistics.TotalWaitTime));
                        }

                        //iterate through each stop required for the order
                        foreach (var rs in node.RouteStops)
                        {
                            Console.WriteLine(string.Format("\t\tStop {0}: {1}", ++stopCount, rs.Location.DisplayName));
                            Console.WriteLine(string.Format("\t\t\tWindow {0}: {1}", rs.WindowStart, rs.WindowEnd));

                            try
                            {
                                // display the statistics for the stop
                                var segmentStatistics = driverStatistics.RouteSegmentStatistics[stopCount-1];
                                Console.WriteLine(string.Format("\t\t\tLeave Previous Stop @ {0}", segmentStatistics.StartTime));
                                Console.WriteLine(string.Format("\t\t\tDistance: {0} mi", segmentStatistics.Statistics.TotalTravelDistance));
                                if (segmentStatistics.Statistics.TotalWaitTime.TotalSeconds > 0)
                                {
                                    Console.WriteLine(string.Format("\t\t\tWait for {0}", segmentStatistics.Statistics.TotalWaitTime));                                
                                }
                                Console.WriteLine(string.Format("\t\t\tQueue Delay @ {0}", segmentStatistics.Statistics.TotalQueueTime));
                                Console.WriteLine(string.Format("\t\t\tArrive @ {0}", segmentStatistics.StartTime.Add(segmentStatistics.Statistics.TotalTravelTime).Add(segmentStatistics.Statistics.TotalWaitTime)));
                                Console.WriteLine(string.Format("\t\t\tFinished @ {0}", segmentStatistics.EndTime));
                            }
                            catch (Exception e)
                            {
                                // Console.WriteLine("Unable to get statistics");
                                continue;
                            }                            
                        }
                    }
                    Console.WriteLine(string.Format("\n\tEnd -\n\t\t{0}", routeSolution.AllNodes.LastOrDefault().RouteStops.FirstOrDefault().Location.DisplayName));
                }

                // prompt user for permission to continue
                Console.Write("Press any key to ");
                Console.WriteLine(i == 2 ? "exit." : "continue.");

                Console.ReadKey();
            }
        }
    }
}
