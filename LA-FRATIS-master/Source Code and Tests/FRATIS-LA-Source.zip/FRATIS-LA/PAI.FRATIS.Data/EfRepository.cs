﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

using PAI.Core;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.Data
{
    /// <summary>
    /// Entity Framework repository
    /// </summary>
    public class EfRepository<T> : IRepository<T>
        where T : class
    {
        #region Fields

        private readonly IDbContext _context;

        private readonly IIncluder _includer;

        private IDbSet<T> _entities;

        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="context">Object context</param>
        /// <param name="includer">Eager loading property includer</param>
        public EfRepository(IDbContext context, IIncluder includer)
        {
            this._context = context;
            this._includer = includer;
        }

        #endregion

        #region Properties

        private IDbSet<T> Entities
        {
            get
            {
                return this._entities ?? (this._entities = this._context.Set<T>());
            }
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Attaches the entity to the underlying context of this reposity.  
        /// It is placed in the Unchanged state as if it was just read from the database
        /// </summary>
        /// <param name="entity">The entity to attach</param>
        /// <param name="markDirty">Marks the newly attached entity as modified</param>
        /// <returns></returns>
        public void Attach(T entity, bool markDirty = false)
        {
            this._context.Attach(entity, markDirty);
        }

        public void Delete(T entity, bool saveChanges = true)
        {
            try
            {
                this.Entities.Remove(entity);

                if (saveChanges)
                {
                    this._context.SaveChanges();
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                string msg = this.GetMessageFromDbEntityValidationException(dbEx);
                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        public void Detach(T entity)
        {
            this._context.Detach(entity);
        }

        public T GetById(object id)
        {
            return this.Entities.Find(id);
        }

        public object GetContext()
        {
            return this._context;
        }

        public object GetObjectContext()
        {
            return this._context.ObjectContext;
        }

        public void Insert(T entity, bool saveChanges = true)
        {
            try
            {
                this.Entities.Add(entity);

                if (saveChanges)
                {
                    this._context.SaveChanges();
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                string msg = this.GetMessageFromDbEntityValidationException(dbEx);
                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        public void MarkDirty(T entity)
        {
            this._context.MarkDirty(entity);
        }

        public int SaveChanges()
        {
            return this._context.SaveChanges();
        }

        /// <summary>
        /// Selects query
        /// </summary>
        public IQueryable<T> Select()
        {
            return this.Entities;
        }

        /// <summary>
        /// Selects query with included properties
        /// </summary>
        /// <param name="includeProperties"></param>
        public IQueryable<T> SelectWith(params Expression<Func<T, object>>[] includeProperties)
        {
            return includeProperties.Aggregate(
                this.Select(), (current, includeProperty) => this._includer.Include(current, includeProperty));
        }

        public IQueryable<T> SelectWith(params string[] includeProperties)
        {
            return includeProperties.Aggregate(
                this.Select(), (current, includeProperty) => this._includer.Include(current, includeProperty));
        }

        public void SetConnectionString(string connectionString)
        {
            this._context.SetConnectionString(connectionString);
        }

        public void Update(T entity, bool saveChanges = true)
        {
            try
            {
                if (saveChanges)
                {
                    this._context.SaveChanges();
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                string msg = this.GetMessageFromDbEntityValidationException(dbEx);
                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        #endregion

        #region Methods

        [ExcludeFromCodeCoverage]
        private string GetMessageFromDbEntityValidationException(DbEntityValidationException dbEx)
        {
            var sb = new StringBuilder();
            foreach (DbEntityValidationResult validationErrors in dbEx.EntityValidationErrors)
            {
                foreach (DbValidationError validationError in validationErrors.ValidationErrors)
                {
                    sb.AppendFormat(
                        "Property: {0} Error: {1}" + Environment.NewLine,
                        validationError.PropertyName,
                        validationError.ErrorMessage);
                }
            }
            return sb.ToString();
        }

        #endregion
    }
}