﻿using System.Data.Entity.ModelConfiguration;
using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Domain.Logging;

namespace PAI.FRATIS.Data.Mappings
{
    class ExternalSyncMap  : EntityTypeConfiguration<ExternalSync>
    {
        public ExternalSyncMap()
        {
        }
    }
}
