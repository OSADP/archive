using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Data.Mappings
{
    internal class PlanDriverJobMap : EntityTypeConfiguration<PlanDriverJob>
    {
        #region Constructors and Destructors

        public PlanDriverJobMap()
        {
            this.Ignore(p => p.Metrics);
            this.Ignore(p => p.DepartureTimeSpan);
        }

        #endregion
    }
}