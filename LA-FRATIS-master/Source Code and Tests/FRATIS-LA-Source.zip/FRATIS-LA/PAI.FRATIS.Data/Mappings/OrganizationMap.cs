﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Users;

namespace PAI.FRATIS.Data.Mappings
{
    internal class OrganizationMap : EntityTypeConfiguration<Organization>
    {
    }
}