﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Data.Mappings
{
    public class JobGroupMap : EntityTypeConfiguration<JobGroup>
    {
    }
}