﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Data.Mappings
{
    internal class LocationDistanceMap : EntityTypeConfiguration<LocationDistance>
    {
        #region Constructors and Destructors

        public LocationDistanceMap()
        {
            this.Ignore(p => p.Hours);
            this.Ignore(p => p.IsComplete);
        }

        #endregion
    }
}