﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Information;

namespace PAI.FRATIS.Data.Mappings
{
    /// <summary>The weather city map.</summary>
    public class QueueDeviceSegmentMap : EntityTypeConfiguration<QueueDeviceSegment>
    {
        #region Constructors and Destructors

        public QueueDeviceSegmentMap()
        {
            Property(p => p.Device1Identifier).HasMaxLength(25);
            Property(p => p.Device2Identifier).HasMaxLength(25);
            this.Ignore(p => p.TimeSegmentStart);
            this.Ignore(p => p.TimeSegmentEnd);
        }

        #endregion
    }
}