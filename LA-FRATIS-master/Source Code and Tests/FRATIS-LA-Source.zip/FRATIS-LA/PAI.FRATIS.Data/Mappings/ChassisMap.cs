﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Equipment;

namespace PAI.FRATIS.Data.Mappings
{
    /// <summary>The chassis map.</summary>
    internal class ChassisMap : EntityTypeConfiguration<Chassis>
    {
    }
}