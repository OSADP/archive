﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Data.Mappings
{
    internal class PlanConfigMap : EntityTypeConfiguration<PlanConfig>
    {
        #region Constructors and Destructors

        public PlanConfigMap()
        {
            this.HasMany(p => p.Drivers).WithMany(p => p.PlanConfigs).Map(f => f.ToTable("PlanConfigDriver"));
            this.HasMany(p => p.Jobs).WithMany(p => p.PlanConfigs).Map(f => f.ToTable("PlanConfigJob"));
        }

        #endregion
    }
}