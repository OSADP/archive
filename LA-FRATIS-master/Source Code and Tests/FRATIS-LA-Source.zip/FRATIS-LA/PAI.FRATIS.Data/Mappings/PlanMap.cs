﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Data.Mappings
{
    internal class PlanMap : EntityTypeConfiguration<Plan>
    {
        #region Constructors and Destructors

        public PlanMap()
        {
            this.Ignore(p => p.TotalMetrics);
            this.Ignore(p => p.TotalJobCount);
            this.Ignore(p => p.TotalJobIds);
        }

        #endregion
    }
}