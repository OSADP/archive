﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Messaging;

namespace PAI.FRATIS.Data.Mappings
{
    class SimpleMessageMap : EntityTypeConfiguration<SimpleMessage>
    {
        public SimpleMessageMap()
        {
            HasOptional(p => p.FromUser).WithMany(p => p.SentMessages);
            HasOptional(p => p.ToUser).WithMany(p => p.ReceivedMessages);
            HasOptional(p => p.FromDriver).WithMany(p => p.SentMessages);
            HasOptional(p => p.ToDriver).WithMany(p => p.ReceivedMessages);
        }
    }
}
