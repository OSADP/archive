﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Data.Mappings
{
    internal class DriverMap : EntityTypeConfiguration<Driver>
    {
        #region Constructors and Destructors

        public DriverMap()
        {
            this.HasMany(p => p.JobGroups).WithMany(p => p.Drivers).Map(f => f.ToTable("DriverXJobGroup"));
            this.Ignore(p => p.DisplayName);
            //Ignore(p => p.Position.LegacyId);
        }

        #endregion
    }
}