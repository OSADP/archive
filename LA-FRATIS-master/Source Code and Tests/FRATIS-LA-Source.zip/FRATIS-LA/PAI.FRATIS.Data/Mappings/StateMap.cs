﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Data.Mappings
{
    internal class StateMap : EntityTypeConfiguration<State>
    {
    }
}