﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Data.Mappings
{
    internal class RouteMetricMap : EntityTypeConfiguration<RouteSegmentMetric>
    {
        #region Constructors and Destructors

        public RouteMetricMap()
        {
            this.Ignore(p => p.DepartureTime);
            this.Ignore(p => p.DepartureTimeSpan);
            this.Ignore(p => p.TotalTravelTimeSpan);
            //Ignore(p => p.ArrivalTimeString);
        }

        #endregion
    }
}