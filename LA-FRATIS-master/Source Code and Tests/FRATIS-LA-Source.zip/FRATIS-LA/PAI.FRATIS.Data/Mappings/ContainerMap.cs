﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Equipment;

namespace PAI.FRATIS.Data.Mappings
{
    internal class ContainerMap : EntityTypeConfiguration<Container>
    {
        #region Constructors and Destructors

        public ContainerMap()
        {
            this.HasMany(p => p.AllowedChassis).WithMany(p => p.Containers).Map(f => f.ToTable("ContainerXChassis"));
        }

        #endregion
    }
}