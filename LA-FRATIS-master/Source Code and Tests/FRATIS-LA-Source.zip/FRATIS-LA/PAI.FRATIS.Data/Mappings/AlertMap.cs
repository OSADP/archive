﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Messaging;

namespace PAI.FRATIS.Data.Mappings
{
    internal class AlertMap : EntityTypeConfiguration<Alert>
    {
    }
}