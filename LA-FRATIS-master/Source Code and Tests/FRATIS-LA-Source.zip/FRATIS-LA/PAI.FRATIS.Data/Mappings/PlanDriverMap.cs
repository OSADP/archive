﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Data.Mappings
{
    internal class PlanDriverMap : EntityTypeConfiguration<PlanDriver>
    {
        #region Constructors and Destructors

        public PlanDriverMap()
        {
            this.Ignore(p => p.DepartureTimeSpan);
            this.Ignore(p => p.RouteSegmentMetrics);
            this.Ignore(p => p.TotalMetrics);

            //Ignore(p => p.DepartureTime);
        }

        #endregion
    }
}