﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Configuration;

namespace PAI.FRATIS.Data.Mappings
{
    internal class SettingMap : EntityTypeConfiguration<Setting>
    {
    }
}