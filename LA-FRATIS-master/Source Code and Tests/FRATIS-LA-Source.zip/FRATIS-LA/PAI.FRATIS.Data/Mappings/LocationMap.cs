﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Data.Mappings
{
    internal class LocationMap : EntityTypeConfiguration<Location>
    {
        #region Constructors and Destructors

        public LocationMap()
        {
            this.HasMany(p => p.LocationGroups).WithMany(p => p.Locations).Map(f => f.ToTable("LocationXLocationGroup"));
            //HasMany(p => p.HoursOfOperation).WithRequired(p => p.Location);
            this.Ignore(p => p.StreetAddress);
        }

        #endregion
    }
}