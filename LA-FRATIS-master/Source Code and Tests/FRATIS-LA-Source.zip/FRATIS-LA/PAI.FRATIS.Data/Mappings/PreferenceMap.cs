﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Configuration;

namespace PAI.FRATIS.Data.Mappings
{
    internal class PreferenceMap : EntityTypeConfiguration<Preference>
    {
        #region Constructors and Destructors

        public PreferenceMap()
        {
            this.HasOptional(p => p.DefaultHomeLocation);
        }

        #endregion
    }
}