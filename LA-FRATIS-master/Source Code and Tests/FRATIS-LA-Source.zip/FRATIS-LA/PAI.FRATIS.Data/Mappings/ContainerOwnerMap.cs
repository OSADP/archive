﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Equipment;

namespace PAI.FRATIS.Data.Mappings
{
    internal class ContainerOwnerMap : EntityTypeConfiguration<ContainerOwner>
    {
    }
}