﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Users;

namespace PAI.FRATIS.Data.Mappings
{
    internal class UserMap : EntityTypeConfiguration<User>
    {
        #region Constructors and Destructors

        public UserMap()
        {
            this.Ignore(p => p.UserType);
        }

        #endregion
    }
}