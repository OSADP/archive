﻿using System.Data.Entity.ModelConfiguration;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Data.Mappings
{
    /// <summary>The location queue delay map.</summary>
    internal class LocationQueueDelayMap : EntityTypeConfiguration<LocationQueueDelay>
    {
        #region Constructors and Destructors

        public LocationQueueDelayMap()
        {
            this.HasRequired(p => p.Location).WithMany(p => p.Queues);
        }

        #endregion
    }
}