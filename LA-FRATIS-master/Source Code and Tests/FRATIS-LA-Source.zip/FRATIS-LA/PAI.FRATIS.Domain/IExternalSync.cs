﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAI.FRATIS.Domain
{
    public interface IExternalSync
    {
        /// <summary>
        /// Gets or sets the time in which this object was converted to a flat file for synchronization
        /// </summary>
        DateTime? SyncProcessedTime { get; set; }

        /// <summary>
        /// Gets or sets the time, if known, in which the external entity reported acknowledgement of this object
        /// </summary>
        DateTime? SyncExternalAckTime { get; set; }
    }

    public interface IExternalSyncEntity : IExternalSync
    {
        DateTime? LegacySyncDateTime { get; set; }
    }
}
