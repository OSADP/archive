using System.Collections.Generic;

namespace PAI.FRATIS.Domain.Geography
{
    /// <summary>The location group to which a location can be assigned.</summary>
    public class LocationGroup : EntityBase
    {
        #region Public Properties

        /// <summary>Gets or sets the children.</summary>
        public virtual ICollection<LocationGroup> Children { get; set; }

        /// <summary>
        /// Gets or sets a boolean representing if this location group represents a home location starting point
        /// </summary>
        public bool IsHomeLocation { get; set; }

        /// <summary>
        /// Gets or sets the locations within this location group
        /// </summary>
        public virtual ICollection<Location> Locations { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        public string Name { get; set; }

        public virtual LocationGroup Parent { get; set; }

        /// <summary>
        /// Gets or sets the parent id for hierarchical location groups
        /// </summary>
        public int? ParentId { get; set; }

        #endregion
    }
}