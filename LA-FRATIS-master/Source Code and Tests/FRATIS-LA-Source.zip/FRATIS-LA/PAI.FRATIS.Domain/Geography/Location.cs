﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;

using PAI.FRATIS.Domain.Users;

namespace PAI.FRATIS.Domain.Geography
{
    /// <summary>
    /// Represents a geographical location
    /// </summary>
    public class Location : EntityBase, IArchivedEntity
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public virtual string City { get; set; }

        /// <summary>
        /// Gets or sets the display name
        /// </summary>
        public string DisplayName { get; set; }

        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the hours of operation for the provided location
        /// </summary>
        public ICollection<LocationHours> HoursOfOperation { get; set; }

        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets the latitude in degrees
        /// </summary>
        public virtual double? Latitude { get; set; }

        public string LegacyId { get; set; }

        /// <summary>
        /// Gets or sets the location group.
        /// </summary>
        public virtual ICollection<LocationGroup> LocationGroups { get; set; }

        /// <summary>
        /// Gets or sets the longitude in degrees
        /// </summary>
        public virtual double? Longitude { get; set; }

        /// <summary>
        /// Gets or sets location notes
        /// </summary>
        public string Note { get; set; }

        public virtual Organization Organization { get; set; }

        public int? OrganizationId { get; set; }

        public string Phone { get; set; }

        /// <summary>Gets or sets the queues.</summary>
        public ICollection<LocationQueueDelay> Queues { get; set; }

        /// <summary>
        /// Gets or sets the state
        /// </summary>
        public virtual string State { get; set; }

        /// <summary>
        /// Gets or sets the address
        /// </summary>
        public virtual string Street { get; set; }

        /// <summary>
        /// Gets the street address
        /// Consists of StreetNumber and Street
        /// </summary>
        public string StreetAddress
        {
            get
            {
                return string.Format("{0} {1}", "", this.Street).Trim();
            }

            set
            {
                this.Street = value;
            }
        }

        /// <summary>
        /// Gets or sets the street number
        /// </summary>
        public string StreetNumber { get; set; }

        public int? WaitingTime { get; set; }

        /// <summary>
        /// Gets or sets the Web Fleet Location Id
        /// </summary>
        public virtual string WebFleetId { get; set; }

        /// <summary>
        /// Gets or sets the zip
        /// </summary>
        public virtual string Zip { get; set; }

        #endregion
    }
}