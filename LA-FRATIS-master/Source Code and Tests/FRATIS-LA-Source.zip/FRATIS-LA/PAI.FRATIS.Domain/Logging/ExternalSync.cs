﻿using System;
using PAI.FRATIS.Domain.Users;

namespace PAI.FRATIS.Domain.Logging
{
    /// <summary>
    /// Represents the last synchronization time of a given organization
    /// Used in determing which jobs require external CSV output / sync
    /// </summary>
    public class ExternalSync : EntityBase, IDatedEntity
    {
        public int? OrganizationId { get; set; }

        public DateTime? TimeStamp { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}
