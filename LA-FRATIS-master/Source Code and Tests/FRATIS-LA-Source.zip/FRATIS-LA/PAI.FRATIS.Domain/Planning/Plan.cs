﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Domain.Planning
{
    /// <summary>
    /// represents a plan
    /// </summary>
    public class Plan : EntityBase, IDatedEntity
    {
        #region Fields

        /// <summary>
        /// Gets or sets the driver plans
        /// </summary>
        private ICollection<PlanDriver> _driverPlans;

        /// <summary>
        /// Gets or sets the unassigned jobs
        /// </summary>
        private ICollection<Job> _unassignedJobs;

        #endregion

        #region Public Properties

        public DateTime? CreatedDate { get; set; }

        public virtual ICollection<PlanDriver> DriverPlans
        {
            get
            {
                return this._driverPlans ?? (this._driverPlans = new List<PlanDriver>());
            }
            set
            {
                this._driverPlans = value;
            }
        }

        /// <summary>
        /// Gets or sets whether this Plan has been accepted
        /// A Plan is accepted once the Solution is displayed and the user
        /// selects to Transmit the solution to the Drivers
        /// This also triggers Terminal ETA planning messages
        /// </summary>
        public bool IsAccepted { get; set; }

        public virtual JobGroup JobGroup { get; set; }

        public DateTime? ModifiedDate { get; set; }

        /// <summary>
        /// Gets or sets the PlanConfig
        /// </summary>
        public virtual PlanConfig PlanConfig { get; set; }

        public int? PlanConfigId { get; set; }

        /// <summary>
        /// Gets or sets the unique id for a run
        /// </summary>
        public virtual int Run { get; set; }

        public int TotalJobCount
        {
            get
            {
                return this.TotalJobIds.Count();
            }
        }

        public IEnumerable<int> TotalJobIds
        {
            get
            {
                var ids = new HashSet<int>();
                foreach (int jobId in this.DriverPlans.SelectMany(dp => dp.JobPlans.Select(p => p.JobId).ToList()))
                {
                    ids.Add(jobId);
                }

                foreach (Job j in this.UnassignedJobs)
                {
                    ids.Add(j.Id);
                }

                return ids.ToList();
            }
        }

        public RouteSegmentMetric TotalMetrics
        {
            get
            {
                var result = new RouteSegmentMetric();
                if (this.DriverPlans != null)
                {
                    result = this.DriverPlans.Aggregate(result, (current, dp) => current + dp.TotalMetrics);
                }
                return result;
            }
        }

        /// <summary>
        /// Gets or sets whether this plan was transmitted
        /// </summary>
        public virtual bool Transmitted { get; set; }

        public virtual ICollection<Job> UnassignedJobs
        {
            get
            {
                return this._unassignedJobs ?? (this._unassignedJobs = new List<Job>());
            }
            set
            {
                this._unassignedJobs = value;
            }
        }

        /// <summary>
        /// Gets or sets whether this plan is user created
        /// </summary>
        public virtual bool UserCreated { get; set; }

        /// <summary>
        /// Gets or sets whether this plan was modified
        /// </summary>
        public virtual bool UserModified { get; set; }

        #endregion
    }
}