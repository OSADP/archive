﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Domain.Planning
{
    /// <summary>
    /// represents a PlanConfig
    /// </summary>
    public class PlanConfig : EntityBase, IDatedEntity
    {
        #region Fields

        private ICollection<Driver> _drivers;

        private ICollection<Job> _jobs;

        #endregion

        #region Public Properties

        public DateTime? CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the default driver
        /// </summary>
        public virtual Driver DefaultDriver { get; set; }

        /// <summary>
        /// Gets or sets the drivers
        /// </summary>
        public virtual ICollection<Driver> Drivers
        {
            get
            {
                return this._drivers ?? (this._drivers = new List<Driver>());
            }
            set
            {
                this._drivers = value;
            }
        }

        /// <summary>
        /// Gets or sets Due Date provided upon Plan Creation
        /// </summary>
        public virtual DateTime DueDate { get; set; }

        public virtual JobGroup JobGroup { get; set; }

        public int? JobGroupId { get; set; }

        /// <summary>
        /// Gets or sets the jobs
        /// </summary>
        public virtual ICollection<Job> Jobs
        {
            get
            {
                return this._jobs ?? (this._jobs = new List<Job>());
            }
            set
            {
                this._jobs = value;
            }
        }

        public DateTime? ModifiedDate { get; set; }

        public TimeSpan? ShiftStartTime { get; set; }

        #endregion
    }
}