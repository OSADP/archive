﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Domain.Planning
{
    /// <summary>
    /// represents a driver plan
    /// </summary>
    public class PlanDriver : EntityBase
    {
        #region Fields

        private ICollection<PlanDriverJob> _jobPlans;

        /// <summary>
        /// Gets or sets the route segment metrics
        /// </summary>
        private IList<RouteSegmentMetric> _routeSegmentMetrics;

        #endregion

        #region Public Properties

        public long DepartureTime { get; set; }

        public TimeSpan DepartureTimeSpan
        {
            get
            {
                return new TimeSpan(this.DepartureTime);
            }
        }

        /// <summary>
        /// Gets or sets the Driver
        /// </summary>
        public virtual Driver Driver { get; set; }

        public virtual int DriverId { get; set; }

        /// <summary>
        /// Gets or sets the jobs
        /// </summary>
        public virtual ICollection<PlanDriverJob> JobPlans
        {
            get
            {
                return this._jobPlans ?? (this._jobPlans = new List<PlanDriverJob>());
            }
            set
            {
                this._jobPlans = value;
            }
        }

        public virtual IList<RouteSegmentMetric> RouteSegmentMetrics
        {
            get
            {
                return this._routeSegmentMetrics ?? (this._routeSegmentMetrics = new List<RouteSegmentMetric>());
            }
            set
            {
                this._routeSegmentMetrics = value;
            }
        }

        public RouteSegmentMetric TotalMetrics
        {
            get
            {
                var result = new RouteSegmentMetric();
                if (this.RouteSegmentMetrics != null)
                {
                    result = this.RouteSegmentMetrics.Aggregate(result, (current, metric) => current + metric);
                }
                return result;
            }
        }

        #endregion
    }
}