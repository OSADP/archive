﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Domain.Users;

namespace PAI.FRATIS.Domain.Messaging
{
    public class SimpleMessage : EntityBase, IDatedEntity, IExternalSync
    {
        public DateTime? TimeStamp { get; set; }

        public int? ToVehicleId { get; set; }

        public virtual Vehicle ToVehicle { get; set; }

        public string From { get; set; }

        public int? FromDriverId { get; set; }

        public virtual Driver FromDriver { get; set; }

        public int? FromOrganizationId { get; set; }

        public virtual Organization FromOrganization { get; set; }

        public int? FromUserId { get; set; }

        public virtual User FromUser { get; set; }

        public string To { get; set; }

        public int? ToDriverId { get; set; }

        public virtual Driver ToDriver { get; set; }

        public int? ToOrganizationId { get; set; }

        public virtual Organization ToOrganization { get; set; }

        public int? ToUserId { get; set; }

        public virtual User ToUser { get; set; }

        public string Subject { get; set; }

        public string MessageBody { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
       
        public int? AlertId { get; set; }

        public bool IsAcknowledged { get; set; }

        public DateTime? ReadTimeStamp { get; set; }

        public DateTime? SyncProcessedTime { get; set; }

        public DateTime? SyncExternalAckTime { get; set; }
    }
}
