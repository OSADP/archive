using System;

using PAI.FRATIS.Domain.Information;

namespace PAI.FRATIS.Domain.Equipment
{
    /// <summary>
    /// Represents the location of an object as reported by WEBFLEET
    /// </summary>
    public class WebFleetLocation : IPositionInfo
    {
        #region Public Properties

        /// <summary>
        /// Location description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Latitude coordinates of the reported position
        /// </summary>
        public double? Latitude { get; set; }

        /// <summary>
        /// Legacy Id
        /// </summary>
        public int LegacyId { get; set; }

        /// <summary>
        /// Gets or sets the Longitude coordinates of the reported position
        /// </summary>
        public double? Longitude { get; set; }

        /// <summary>
        /// Current location position string
        /// </summary>
        public string PositionText { get; set; }

        /// <summary>
        /// UTC Time the position was reported
        /// </summary>
        public DateTime? TimeStamp { get; set; }

        #endregion
    }
}