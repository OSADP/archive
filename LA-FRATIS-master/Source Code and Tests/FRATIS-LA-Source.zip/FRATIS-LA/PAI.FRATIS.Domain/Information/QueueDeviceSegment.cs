﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;

namespace PAI.FRATIS.Domain.Information
{
    /// <summary>
    /// Represents a queue device segment for identification for queue delay reporting purposes
    /// </summary>
    public class QueueDeviceSegment : EntityBase, IDatedEntity
    {
        #region Public Properties

        public DateTime? CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the last calculated average delay
        /// </summary>
        public int CurrentAverage { get; set; }

        /// <summary>
        /// Gets or sets the starting device identifier
        /// </summary>
        public string Device1Identifier { get; set; }

        /// <summary>
        /// Gets or sets the ending device identifier
        /// </summary>
        public string Device2Identifier { get; set; }

        /// <summary>
        /// Gets or sets the segment name
        /// </summary>
        public string DisplayName { get; set; }

        public DateTime? ModifiedDate { get; set; }

        /// <summary>
        /// value from 0-47 incicating the 30 minute interval
        /// </summary>
        public int Segment { get; set; }

        public TimeSpan TimeSegmentEnd
        {
            get
            {
                return new TimeSpan(0, (this.Segment + 1) * 30, 0);
            }
        }

        public TimeSpan TimeSegmentStart
        {
            get
            {
                return new TimeSpan(0, this.Segment * 30, 0);
            }
        }

        /// <summary>
        /// Gets or sets the total delay in seconds
        /// </summary>
        public long TotalDelay { get; set; }

        /// <summary>
        /// Gets or sets the vehicle count
        /// </summary>
        public int VehicleCount { get; set; }

        #endregion
    }
}