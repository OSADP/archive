﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Planning;
using PAI.FRATIS.Domain.Users;

namespace PAI.FRATIS.Domain.Orders
{
    /// <summary>
    /// Represents a driver
    /// </summary>
    public sealed class Driver : EntityBase
    {
        #region Constructors and Destructors

        public Driver()
        {
            this.AvailableDrivingHours = 11;
            this.AvailableDutyHours = 14;
            this.JobGroups = new Collection<JobGroup>();
            this.Position = new WebFleetLocation();
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the available driving time in hours
        /// </summary>
        public double AvailableDrivingHours { get; set; }

        /// <summary>
        /// Gets or sets the available duty time in hours
        /// </summary>
        public double AvailableDutyHours { get; set; }

        /// <summary>
        /// Gets or sets the display name for the given driver
        /// </summary>
        public string DisplayName
        {
            get
            {
                return string.Format("{0} {1}", this.FirstName, this.LastName).Trim();
            }
            set
            {
                if (value.IndexOf(',') > 0)
                {
                    this.LastName = value.Substring(0, value.IndexOf(',')).Trim();
                    this.FirstName = value.Substring(value.IndexOf(',') + 1).Trim();
                }
                else if (value.IndexOf(' ') > 0)
                {
                    this.FirstName = value.Substring(0, value.IndexOf(' ')).Trim();
                    this.LastName = value.Substring(value.IndexOf(' ') + 1).Trim();
                }
                else
                {
                    this.FirstName = value;
                }
            }
        }

        /// <summary>Gets or sets the driver type.</summary>
        public string DriverType { get; set; }

        /// <summary>
        /// Gets or sets the earliest start time in which the driver can work in ticks
        /// </summary>
        public long EarliestStartTime { get; set; }

        public TimeSpan EarliestStartTimeSpan
        {
            get
            {
                return new TimeSpan(this.EarliestStartTime);
            }
        }

        /// <summary>Gets or sets the email.</summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the driver's first name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets if the given driver is a "placeholder / dummy" driver
        /// </summary>
        public bool IsPlaceholderDriver { get; set; }

        /// <summary>
        /// Gets or sets the JobGroups in which this driver is eligible to work
        /// </summary>
        public ICollection<JobGroup> JobGroups { get; set; }

        /// <summary>
        /// Gets or sets the driver's last name
        /// </summary>
        public string LastName { get; set; }

        public Organization Organization { get; set; }

        /// <summary>
        /// Gets or sets the organization id for the driver
        /// </summary>
        public int? OrganizationId { get; set; }

        /// <summary>Gets or sets the phone.</summary>
        public string Phone { get; set; }

        /// <summary>
        /// Navigational property representing Plan Configurations
        /// </summary>
        public ICollection<PlanConfig> PlanConfigs { get; set; }

        /// <summary>
        /// Gets or sets the last reported webfleet position of the driver
        /// </summary>
        public WebFleetLocation Position { get; set; }

        /// <summary>
        /// Gets or sets the starting location of the driver
        /// </summary>
        public Location StartingLocation { get; set; }

        /// <summary>
        /// Gets or sets the starting location id
        /// </summary>
        public int? StartingLocationId { get; set; }

        /// <summary>
        /// Gets or sets the WebFleetVehicleId
        /// </summary>
        public string WebFleetDriverId { get; set; }

        /// <summary>
        /// Gets or sets the WebFleetVehicleId
        /// </summary>
        public string WebFleetVehicleId { get; set; }

        #endregion

        #region Public Methods and Operators

        public override string ToString()
        {
            return string.Format("{0} {1} ({2}", this.FirstName, this.LastName, this.Id);
        }

        #endregion
    }
}