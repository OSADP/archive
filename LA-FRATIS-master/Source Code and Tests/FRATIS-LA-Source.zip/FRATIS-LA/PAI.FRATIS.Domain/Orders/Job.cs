﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using PAI.FRATIS.Domain.Equipment;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Domain.Orders
{
    /// <summary>
    /// Represents a drayage job
    /// </summary>
    public class Job : EntityBase, IArchivedEntity, IDatedEntity
    {
        #region Fields

        /// <summary>
        /// Gets or sets the route stops
        /// </summary>
        private IList<RouteStop> _routeStops;

        #endregion

        #region Public Properties

        public DateTime? ActualETA { get; set; }

        /// <summary>
        /// Gets or sets the estimated time of arrival for the driver
        /// at the destination - currently only populated for marine terminal destined orders
        /// </summary>
        public DateTime? AlgorithmETA { get; set; }

        /// <summary>
        /// Gets or sets the time in which this order was manually assigned to a driver
        /// </summary>
        public DateTime? AssignedDateTime { get; set; }

        public virtual Driver AssignedDriver { get; set; }

        /// <summary>
        /// Gets or sets the id of the driver manually assigned to this driver
        /// </summary>
        public int? AssignedDriverId { get; set; }

        /// <summary>
        /// Gets or sets the job bill of lading
        /// </summary>
        public string BillOfLading { get; set; }

        /// <summary>
        /// Gets or sets the Pickup Number
        /// </summary>
        public string BookingNumber { get; set; }

        /// <summary>
        /// Gets or sets the chassis
        /// </summary>
        public virtual Chassis Chassis { get; set; }

        public int? ChassisId { get; set; }

        /// <summary>
        /// Gets or sets the chassis
        /// </summary>
        public virtual ChassisOwner ChassisOwner { get; set; }

        public int? ChassisOwnerId { get; set; }

        /// <summary>
        /// Gets the Consignee Location based upon RouteStops within this model
        /// </summary>
        public Location ConsigneeLocation
        {
            get
            {
                Location result = null;
                if (this.RouteStops != null && this.RouteStops.Count > 0)
                {
                    RouteStop end = this.RouteStops.LastOrDefault();
                    if (end != null && end.Location != null)
                    {
                        result = end.Location;
                    }

                    if (this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName == "LL") != null)
                    {
                        RouteStop rs = this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName.StartsWith("DL"));
                        if (rs != null && rs.Location != null)
                        {
                            result = rs.Location;
                        }
                    }
                    else if (this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName == "LU") != null)
                    {
                        RouteStop rs = this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName.StartsWith("LU"));
                        if (rs != null && rs.Location != null)
                        {
                            result = rs.Location;
                        }
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Gets or sets the container
        /// </summary>
        public virtual Container Container { get; set; }

        public int? ContainerId { get; set; }

        /// <summary>
        /// Gets or sets the job container number
        /// </summary>
        public string ContainerNumber { get; set; }

        /// <summary>
        /// Gets or sets the container
        /// </summary>
        public virtual ContainerOwner ContainerOwner { get; set; }

        public int? ContainerOwnerId { get; set; }

        public DateTime? CreatedDate { get; set; }

        public JobDataCollection DataCollection { get; set; }

        /// <summary>Gets or sets the driver sort order.</summary>
        public int DriverSortOrder { get; set; }

        /// <summary>
        /// Gets or sets the job due date
        /// </summary>
        public virtual DateTime? DueDate { get; set; }

        public DateTime? EnRouteETA { get; set; }

        /// <summary>Gets or sets a value indicating whether is deleted.</summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Indicates whether this job is awaiting a
        /// response from the Marine Terminal
        /// before it can be processed
        /// </summary>
        public bool IsPreparatory { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating whether the Terminal Import job is ready for pickup or processing
        /// </summary>
        public bool? IsReady { get; set; }

        public string IsReadyString
        {
            get
            {
                if (this.JobStatus == JobStatus.Unassigned || this.JobStatus == JobStatus.Assigned)
                {
                    return this.IsReady.HasValue && this.IsReady.Value ? "Ready" : "Waiting";
                }
                else if (this.JobStatus == JobStatus.Completed)
                {
                    return "Completed";
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets or sets if this job/order contains marine terminal stops
        /// </summary>
        public bool IsTerminalOrder { get; set; }

        /// <summary>
        /// Gets or sets whether this job was transmitted to a driver's vehicle
        /// </summary>
        public bool IsTransmitted { get; set; }

        /// <summary>
        /// Gets or sets whether this Order/Job passes validation
        /// </summary>
        public bool IsValid { get; set; }

        /// <summary>
        /// Gets or sets the Job Group
        /// </summary>
        public virtual JobGroup JobGroup { get; set; }

        public int? JobGroupId { get; set; }

        /// <summary>
        /// Gets or sets the job pair id for associating jobs spanning multiple legs
        /// </summary>
        public int? JobPairId { get; set; }

        /// <summary>
        /// Gets or sets the JobStatus
        /// </summary>
        public virtual JobStatus JobStatus { get; set; }

        /// <summary>
        /// Gets or sets the job template type.
        /// </summary>
        public JobTemplateType JobTemplateType { get; set; }

        /// <summary>
        /// Gets or sets the time which the location distance processed
        /// by the external distance service for this job
        /// </summary>
        public DateTime? LocationDistanceProcessedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        /// <summary>
        /// Gets or sets the Pickup Number
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the order number
        /// </summary>
        public virtual string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets the Pickup Number
        /// </summary>
        public string PickupNumber { get; set; }

        public virtual ICollection<PlanConfig> PlanConfigs { get; set; }

        /// <summary>
        /// Gets or sets the route stops
        /// </summary>
        public virtual IList<RouteStop> RouteStops
        {
            get
            {
                if (this._routeStops != null)
                {
                    this._routeStops = this._routeStops.OrderBy(p => p.SortOrder).ToList();
                }
                else
                {
                    this._routeStops = new List<RouteStop>();
                }
                return this._routeStops;

                //return _routeStops ?? (_routeStops = new List<RouteStop>());
            }
            set
            {
                this._routeStops = value;
            }
        }

        /// <summary>
        /// Gets the shipper location based upon RouteStops within this Job
        /// </summary>
        public Location ShipperLocation
        {
            get
            {
                Location result = null;
                if (this.RouteStops != null && this.RouteStops.Count > 0)
                {
                    RouteStop first = this.RouteStops.FirstOrDefault();
                    if (first != null && first.Location != null)
                    {
                        result = first.Location;
                    }
                    if (this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName == "LL") != null)
                    {
                        RouteStop rs = this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName.StartsWith("LL"));
                        if (rs != null && rs.Location != null)
                        {
                            result = rs.Location;
                        }
                    }
                    else if (this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName == "LU") != null)
                    {
                        RouteStop rs = this.RouteStops.FirstOrDefault(p => p.StopAction.ShortName.StartsWith("PL"));
                        if (rs != null && rs.Location != null)
                        {
                            result = rs.Location;
                        }
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Gets or sets the marine terminal response regarding availabilty
        /// </summary
        //public bool? IsMarineTerminalAvailable { get; set; }
        /// <summary>
        /// Gets or sets the marine terminal LAST modified date.
        /// </summary>
        public DateTime? TerminalModifiedDate { get; set; }

        #endregion

        #region Public Methods and Operators

        public TerminalJobType GetTerminalJobType(IEnumerable<int?> terminalLocationIds)
        {
            var result = TerminalJobType.Unspecified;
            if (this.RouteStops != null && terminalLocationIds != null && terminalLocationIds.Any())
            {
                RouteStop matchingRouteStop =
                    this.RouteStops.FirstOrDefault(
                        p => p.LocationId != null && terminalLocationIds.Contains(p.LocationId));
                if (matchingRouteStop != null)
                {
                    switch (matchingRouteStop.StopAction.ShortName)
                    {
                        case "PEWC":
                        case "DLWC":
                            result = TerminalJobType.Export;
                            break;

                        case "PLWC":
                            result = TerminalJobType.Import;
                            break;
                    }
                }
            }
            return result;
        }

        #endregion
    }
}