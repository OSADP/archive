﻿using System;
using System.Collections.Generic;
using PAI.FRATIS.Domain.Geography;
using PAI.FRATIS.Domain.Planning;

namespace PAI.FRATIS.Domain.Orders
{
    using System.Collections.ObjectModel;

    public partial class JoeTest : EntityBase
    {
        public string MyField { get; set; }
        public string MyField2 { get; set; }
    }
}