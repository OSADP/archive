//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections.Generic;
using System.Linq;

namespace PAI.FRATIS.Domain.Orders
{
    public static class JobExtensions
    {
        #region Public Methods and Operators

        public static bool ContainsLocation(this Job job, int locationId)
        {
            return job.ContainsLocations(new List<int> { locationId });
        }

        public static bool ContainsLocationGroup(this Job job, int locationGroupId)
        {
            if (job != null && job.RouteStops != null)
            {
                if (
                    job.RouteStops.Where(rs => rs.Location != null).Where(rs => rs.Location.LocationGroups != null).Any(
                        rs => rs.Location.LocationGroups.Any(lg => lg.Id == locationGroupId)))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool ContainsLocations(this Job job, IList<int> locationIds)
        {
            if (job != null && job.RouteStops != null)
            {
                return
                    job.RouteStops.Where(rs => rs.LocationId.HasValue).Any(
                        rs => rs.LocationId != null && locationIds.Contains(rs.LocationId.Value));
            }
            return false;
        }

        #endregion
    }
}