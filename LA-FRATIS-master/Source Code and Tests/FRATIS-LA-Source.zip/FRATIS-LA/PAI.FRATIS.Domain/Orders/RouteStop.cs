using System;

using PAI.FRATIS.Domain.Geography;

namespace PAI.FRATIS.Domain.Orders
{
    /// <summary>
    /// Represents a route stop
    /// </summary>
    public class RouteStop : EntityBase, IDatedEntity, ISortableEntity
    {
        #region Public Properties

        public DateTime? ActualETA { get; set; }

        public DateTime? CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the estimated time of arrival for the driver
        /// at the destination
        /// </summary>
        public DateTime? EstimatedETA { get; set; }

        /// <summary>
        /// Gets or sets whether this is a dynamic stop
        /// </summary>
        public bool IsDynamicStop { get; set; }

        /// <summary>
        /// Gets or sets the associated order
        /// </summary>
        public virtual Job Job { get; set; }

        public virtual int? JobId { get; set; }

        /// <summary>
        /// Gets or sets the location
        /// </summary>
        public virtual Location Location { get; set; }

        /// <summary>
        /// Gets or sets the location id
        /// </summary>
        public int? LocationId { get; set; }

        public DateTime? ModifiedDate { get; set; }

        /// <summary>
        /// Gets or sets the sort order
        /// </summary>
        public virtual int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets stop action
        /// </summary>
        public virtual StopAction StopAction { get; set; }

        public int? StopActionId { get; set; }

        /// <summary>
        /// Gets or sets the stop delay in ticks
        /// </summary>
        public virtual long? StopDelay { get; set; }

        public long WindowEnd { get; set; }

        public long WindowStart { get; set; }

        #endregion
    }
}