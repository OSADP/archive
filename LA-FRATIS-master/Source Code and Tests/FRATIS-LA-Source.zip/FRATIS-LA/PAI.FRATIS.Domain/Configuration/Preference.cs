﻿using System;

using PAI.FRATIS.Domain.Geography;
    //    Copyright 2014 Productivity Apex Inc.
    //        http://www.productivityapex.com/
    //
    //    Licensed under the Apache License, Version 2.0 (the "License");
    //    you may not use this file except in compliance with the License.
    //    You may obtain a copy of the License at
    //
    //        http://www.apache.org/licenses/LICENSE-2.0
    //
    //    Unless required by applicable law or agreed to in writing, software
    //    distributed under the License is distributed on an "AS IS" BASIS,
    //    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    //    See the License for the specific language governing permissions and
    //    limitations under the License.

namespace PAI.FRATIS.Domain.Configuration
{
    /// <summary>Represents configuration preferences</summary>
    public class Preference : EntityBase, IDatedEntity
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets the created date
        /// </summary>
        public DateTime? CreatedDate { get; set; }

        public virtual Location DefaultHomeLocation { get; set; }

        /// <summary>Gets or sets the default home location id.</summary>
        public int? DefaultHomeLocationId { get; set; }

        public virtual Location DefaultTerminalLocation { get; set; }

        /// <summary>
        /// The default terminal location id
        /// </summary>
        public int? DefaultTerminalLocationId { get; set; }

        public virtual Location DefaultYardLocation { get; set; }

        /// <summary>
        /// The default yard location id
        /// </summary>
        public int? DefaultYardLocationId { get; set; }

        /// <summary>
        /// Gets or sets the modified date
        /// </summary>
        public DateTime? ModifiedDate { get; set; }

        #endregion
    }
}