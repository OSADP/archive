﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Geography
{
    public class CachedDistanceService : IDistanceService
    {
        private readonly IDistanceService _distanceService;

        private readonly ConcurrentDictionary<int, TripLength> _dictionary;

        public CachedDistanceService(IDistanceService distanceService)
        {
            _distanceService = distanceService;
            _dictionary = new ConcurrentDictionary<int, TripLength>();
        }

        public TripLength CalculateDistance(Location startLocation, Location endLocation)
        {
            var result = TripLength.Zero;

            try
            {
                if (!startLocation.Equals(endLocation))
                {
                    var locationsTuple = GetLocationsTuple(startLocation, endLocation);
                    var hash = locationsTuple.GetHashCode();

                    result = _dictionary.GetOrAdd(
                        hash, i => _distanceService.CalculateDistance(startLocation, endLocation));
                }
            }
            catch
            {
                result = TripLength.Zero;
            }

            return result;
        }

        /// <summary>
        /// Calculates the trip length
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <param name="startTime"></param>
        /// <returns></returns>
        public TripLength CalculateDistance(Location startLocation, Location endLocation, TimeSpan startTime)
        {
            var result = TripLength.Zero;

            try
            {
                if (!startLocation.Equals(endLocation))
                {
                    var locationsTuple = GetLocationsTuple(startLocation, endLocation);
                    var hash = locationsTuple.GetHashCode();

                    result = _dictionary.GetOrAdd(
                        hash, i => _distanceService.CalculateDistance(startLocation, endLocation, startTime));
                }
            }
            catch
            {
                result = TripLength.Zero;
            }

            return result;
        }

        /// <summary>
        /// Gets a Tuple in the pre-defined required sequence
        /// </summary>
        /// <param name="startLocation"></param>
        /// <param name="endLocation"></param>
        /// <returns></returns>
        private Tuple<Location, Location> GetLocationsTuple(Location startLocation, Location endLocation)
        {
            var result = new Tuple<Location, Location>(startLocation, endLocation);

            if (startLocation.CompareTo(endLocation) < 1)
            {
                result = new Tuple<Location, Location>(endLocation, startLocation);
            }

            return result;
        }
    }
}
