//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;

using System.Collections.Generic;
using System.Linq;

using PAI.Core;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Provides a means of interacting with and between Routes
    /// </summary>
    public class RouteService : IRouteService
    {
        protected readonly ILogger _logger;
        private readonly IRouteExitFunction _routeExitFunction;
        private readonly INodeService _nodeService;
        private readonly IStatisticsService _statisticsService;

        /// <summary>
        /// Initializes a new instance of the <see cref="RouteService"/> class.
        /// </summary>
        /// <param name="routeExitFunction">The route exit function.</param>
        /// <param name="nodeService">The node service.</param>
        /// <param name="statisticsService">The statistics service.</param>
        /// <param name="logger">The logger.</param>
        public RouteService(IRouteExitFunction routeExitFunction, 
            INodeService nodeService, IStatisticsService statisticsService, ILogger logger)
        {
            this._routeExitFunction = routeExitFunction;
            this._nodeService = nodeService;
            this._statisticsService = statisticsService;
            this._logger = logger;
        }

        /// <summary>
        /// Calculates the RouteStatistics between two nodes
        /// </summary>
        /// <param name="origin">the point to begin calculating statistics from</param>
        /// <param name="destination">the point where statistics calculation ends</param>
        /// <returns>the route statistics from origin to destination</returns>
        public RouteStatistics CalculateRouteStatistics(INode origin, INode destination)
        {
            var nodeConnection = this._nodeService.GetNodeConnection(origin, destination);
            return nodeConnection.RouteStatistics;
        }
        
        /// <summary>
        /// Returns true if the given route solution is feasable within time windows and exit criteria
        /// </summary>
        /// <param name="nodeRouteSolution">the solution to analyze</param>
        /// <returns>true if feasible, otherwise false</returns>
        public bool IsFeasableRouteSolution(NodeRouteSolution nodeRouteSolution)
        {
            if (nodeRouteSolution == null)
            {
                throw new ArgumentNullException("nodeRouteSolution cannot be null");
            }

            if (nodeRouteSolution.DriverNode == null)
            {
                throw new ArgumentNullException("nodeRouteSolution cannot have a null driver");
            }

            var driverNode = nodeRouteSolution.DriverNode;
            var currentNodeEndTime = driverNode.Driver.EarliestStartTime;
            var cumulativeRouteStatistics = new RouteStatistics();
            var allNodes = nodeRouteSolution.AllNodes;

            for (int i = 0; i < allNodes.Count - 1; i++)
            {
                var nodeTiming = this._nodeService.GetNodeTiming(allNodes[i], allNodes[i + 1], currentNodeEndTime, cumulativeRouteStatistics);

                if (nodeTiming.IsFeasableTimeWindow)
                {
                    // is it a feasable route
                    var lastConnection = this._nodeService.GetNodeConnection(nodeTiming.Node, driverNode);
                    var finalRouteStatistics = nodeTiming.CumulativeRouteStatistics + lastConnection.RouteStatistics;

                    if (this._routeExitFunction.ExeedsExitCriteria(finalRouteStatistics, driverNode.Driver))
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                currentNodeEndTime = nodeTiming.EndExecutionTime;
                cumulativeRouteStatistics = nodeTiming.CumulativeRouteStatistics;
            }

            return true;
        }

        /// <summary>
        /// Creates a route solution from a list of nodes
        /// </summary>
        /// <param name="nodes">the grouping of jobs to assign to the drive</param>
        /// <param name="driverNode">the driver to assign the jobs to</param>
        /// <returns>a route that the driver can feasibly complete</returns>
        public NodeRouteSolution CreateRouteSolution(IEnumerable<INode> nodes, DriverNode driverNode)
        {
            if (nodes == null)
            {
                throw new ArgumentNullException("Node list cannot be null");
            }

            if (driverNode == null)
            {
                throw new ArgumentNullException("driverNode Node cannot be null");
            }

            var routeSolution = new NodeRouteSolution
                {
                    DriverNode = driverNode,
                    StartTime =  driverNode.Driver.EarliestStartTime,
                    Nodes = nodes.ToList()
                };

            var allNodes = routeSolution.AllNodes;

            // calculate route statistics
            for (int i = 0; i < allNodes.Count; i++)
            {
                // create node plan
                var node = allNodes[i];

                // add node trip length
                routeSolution.RouteStatistics += node.RouteStatistics;

                var previousNode = i == 0 ? null : allNodes[i - 1];
                if (previousNode != null)
                {
                    var statistics = this.CalculateRouteStatistics(previousNode, node);
                    routeSolution.RouteStatistics += statistics;
                }
            }
            
            return routeSolution;
        }


        /// <summary>
        /// Gets the route stops for route solution.
        /// </summary>
        /// <param name="routeSolution">The route solution.</param>
        /// <returns>the list of stops</returns>
        public IList<RouteStop> GetRouteStopsForRouteSolution(NodeRouteSolution routeSolution)
        {
            var allNodes = routeSolution.AllNodes;

            var routeStops = new List<RouteStop>();

            routeStops.AddRange(allNodes[0].RouteStops);

            // calculate route statistics
            for (int i = 1; i < allNodes.Count; i++)
            {
                // create node plan
                var node = allNodes[i];
                
                var previousNode = allNodes[i - 1];
                if (previousNode != null)
                {
                    var nodeConnection = this._nodeService.GetNodeConnection(previousNode, node);
                    if (nodeConnection.RouteStops != null)
                    {
                        routeStops.AddRange(nodeConnection.RouteStops);
                    }
                }

                routeStops.AddRange(node.RouteStops);
            }

            return routeStops;
        }

        /// <summary>
        /// Gets the best solution between a new list of <see cref="INode"/> and a current best <see cref="NodeRouteSolution"/>
        /// </summary>
        /// <param name="nodes">the list of jobs to compair</param>
        /// <param name="driverNode">the driver to which the jobs are assigned</param>
        /// <param name="bestSolution">the currently evaluated best solution</param>
        /// <returns>the best solution</returns>
        public NodeRouteSolution GetBestFeasableSolution(IList<INode> nodes, DriverNode driverNode, NodeRouteSolution bestSolution)
        {
            if (nodes == null)
            {
                throw new ArgumentNullException("node list cannot be null");
            }

            if (nodes.Count == 0)
            {
                throw new OptimizationException("nodes is empty");
            }

            // create solution
            var routeSolution = this.CreateRouteSolution(nodes, driverNode);

            // check feasibility
            if (this.IsFeasableRouteSolution(routeSolution))
            {
                if (bestSolution != null)
                {
                    routeSolution = this.GetBestSolution(bestSolution, routeSolution);
                }
            } 
            else
            {
                routeSolution = bestSolution;
            }

            return routeSolution;
        }

        /// <summary>
        /// Gets the best solution.
        /// </summary>
        /// <param name="left">The first solution to compare</param>
        /// <param name="right">The second solution to compare</param>
        /// <returns>the better solution of the two</returns>
        public NodeRouteSolution GetBestSolution(NodeRouteSolution left, NodeRouteSolution right)
        {
            var leftSolutionJobNodeCount = left.AllNodes.Count(x => x is JobNode);
            var rightSolutionJobNodeCount = right.AllNodes.Count(x => x is JobNode);
            return leftSolutionJobNodeCount > rightSolutionJobNodeCount ? left : right;
        }

        /// <summary>
        /// Gets the best solution.
        /// </summary>
        /// <param name="left">The first solution to compare</param>
        /// <param name="right">The second solution to compare</param>
        /// <returns>the better solution of the two</returns>
        public Solution GetBestSolution(Solution left, Solution right)
        {
            var leftSolutionJobNodeCount = left.RouteSolutions.SelectMany(x => x.AllNodes).Count(y => y is JobNode);
            var rightSolutionJobNodeCount = right.RouteSolutions.SelectMany(x => x.AllNodes).Count(y => y is JobNode);
            return leftSolutionJobNodeCount > rightSolutionJobNodeCount ? left : right;
        }
    }
}