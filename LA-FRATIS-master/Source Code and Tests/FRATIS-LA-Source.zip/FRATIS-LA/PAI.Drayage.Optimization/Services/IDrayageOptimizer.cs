using System;
using System.Collections.Generic;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// The Route Optimizer
    /// </summary>
    public interface IDrayageOptimizer
    {
        /// <summary>
        /// Builds the solution.
        /// </summary>
        /// <param name="drivers">The drivers.</param>
        /// <param name="defaultDriver">The default driver.</param>
        /// <param name="jobs">The jobs.</param>
        /// <returns>the best generated solution</returns>
        Solution BuildSolution(IList<Driver> drivers, Driver defaultDriver, IList<Job> jobs);

        /// <summary>
        /// Gets or sets a value indicating whether [enable parallelism].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [enable parallelism]; otherwise, <c>false</c>.
        /// </value>
        bool EnableParallelism { get; set; }
        /// <summary>
        /// Gets or sets the pheromone update frequency.
        /// </summary>
        /// <value>
        /// The pheromone update frequency.
        /// </value>
        int PheromoneUpdateFrequency { get; set; }
        /// <summary>
        /// Gets or sets the maximum number of iterations to run.
        /// </summary>
        /// <value>
        /// The maximum number of iterations to run.
        /// </value>
        int MaxIterations { get; set; }
        /// <summary>
        /// Gets or sets the maximum iteration since best result before quitting.
        /// </summary>
        /// <value>
        /// The maximum iteration since best result before quitting.
        /// </value>
        int MaxIterationSinceBestResult { get; set; }
        /// <summary>
        /// Gets or sets the maximum execution time.
        /// </summary>
        /// <value>
        /// The maximum execution time.
        /// </value>
        int MaxExecutionTime { get; set; }

        /// <summary>
        /// Occurs when [progress changed]. to synchronize thread p0rocesses when parallelism is enabled
        /// </summary>
        event EventHandler<ProgressEventArgs> ProgressChanged;

        /// <summary>
        /// Initializes Optimizer
        /// </summary>
        void Initialize();
    }
}
