﻿using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// A means for interacting with and amoung Nodes
    /// </summary>
    public class NodeService : INodeService
    {
        protected readonly OptimizerConfiguration _configuration;
        protected readonly IRouteStopService _routeStopService;
        
        public NodeService(IRouteStopService routeStopService, OptimizerConfiguration configuration)
        {
            this._configuration = configuration;
            this._routeStopService = routeStopService;
        }

        /// <summary>
        /// Gets the <see cref="NodeConnection"/> between two nodes
        /// </summary>
        /// <param name="startNode">the node to start the connection from</param>
        /// <param name="endNode">the node that the connection ends at</param>
        /// <returns>a representation of the travel distance between the start and end nodes</returns>
        public virtual NodeConnection GetNodeConnection(INode startNode, INode endNode)
        {
            return this.CreateNodeConnection(startNode, endNode);
        }

        /// <summary>
        /// Creates a <see cref="NodeConnection"/> between two nodes
        /// </summary>
        /// <param name="startNode">the node to start the connection from</param>
        /// <param name="endNode">the node that the connection ends at</param>
        /// <returns>a representation of the travel distance between the start and end nodes</returns>
        public virtual NodeConnection CreateNodeConnection(INode startNode, INode endNode)
        {
            if (startNode == null)
            {
                throw new ArgumentNullException("startNode cannot be null");
            }

            if (endNode == null)
            {
                throw new ArgumentNullException("endNode cannot be null");
            }

            if (startNode.RouteStops.Count == 0)
            {
                throw new OptimizationException("StartNode has no stops");
            }

            if (endNode.RouteStops.Count == 0)
            {
                throw new OptimizationException("EndNode has no stops");
            }

            var nodeConnection = new NodeConnection()
                {
                    StartNode = startNode,
                    EndNode = endNode
                };

            // start of connection is last stop of start node
            var startStop = startNode.RouteStops.Last();

            // end of connection is first stop of end node
            var endStop = endNode.RouteStops.First();

            // calculate local route statistics
            var stops = new List<RouteStop> {startStop, endStop};
            nodeConnection.RouteStatistics = this._routeStopService.CalculateRouteStatistics(stops, true);
            
            return nodeConnection;
        }
        
        /// <summary>
        /// Returns the <see cref="NodeTiming"/> for the next node
        /// </summary>
        /// <returns>A representation of the probable times for the job given the previous stops in the route</returns>
        public virtual NodeTiming GetNodeTiming(INode startNode, INode endNode, TimeSpan currentNodeEndTime, RouteStatistics currentRouteStatistics)
        {
            var connection = this.GetNodeConnection(startNode, endNode);

            TimeSpan nextNodeArrivalTime = currentNodeEndTime + connection.RouteStatistics.TotalTime;
            TimeSpan nextNodeCompletionTime = endNode.RouteStops != null
                                                  ? nextNodeArrivalTime.Add(
                                                      endNode.RouteStops.FirstOrDefault().StopDelay.Value)
                                                  : nextNodeArrivalTime;

            bool isFirstStop = startNode is DriverNode;
            bool early = nextNodeArrivalTime < endNode.WindowStart;
            bool late = nextNodeArrivalTime > endNode.WindowEnd;

            bool isFeasableTimeWindow = false;
            TimeSpan waitTime = TimeSpan.Zero;

            if (early)
            {
                currentNodeEndTime = this.ConfigureForEarlyArrival(endNode, isFirstStop, connection, ref waitTime, ref nextNodeArrivalTime, ref isFeasableTimeWindow);
            }
            else if (!late)
            {
                isFeasableTimeWindow = true;
            }

            var cumulatingCompletionTime = new TimeSpan(nextNodeCompletionTime.Ticks);
            if (isFeasableTimeWindow)
            {
                isFeasableTimeWindow = this.EnsureFeasibiltyOfWindow(endNode, isFeasableTimeWindow, ref cumulatingCompletionTime);
            }

            TimeSpan nextNodeStartTime = nextNodeArrivalTime + waitTime;

            RouteStatistics localRouteStatistics = new RouteStatistics() {TotalWaitTime = waitTime};
            RouteStatistics cumulativeRouteStatistics = currentRouteStatistics + connection.RouteStatistics + endNode.RouteStatistics + localRouteStatistics;

            var result = new NodeTiming()
            {
                Node = endNode,
                DepartureTime = currentNodeEndTime,
                ArrivalTime = nextNodeArrivalTime,
                StartExecutionTime = nextNodeStartTime,
                EndExecutionTime = cumulatingCompletionTime,
                IsFeasableTimeWindow = isFeasableTimeWindow,
                CumulativeRouteStatistics = cumulativeRouteStatistics
            };

            return result;
        }

        bool EnsureFeasibiltyOfWindow(INode endNode, bool isFeasableTimeWindow, ref TimeSpan cumulatingCompletionTime)
        { 
            // make sure that the following subsequent route stops would not be violated                
            if (endNode is JobNode)
            {
                var jn = endNode as JobNode;

                for (int i = 1; i < jn.RouteStops.Count; i++)
                {
                    if (!isFeasableTimeWindow)
                    {
                        break;
                    }

                    var rs = jn.RouteStops[i];
                    var rsConnection = this.GetNodeConnection(
                        new JobNode() {RouteStops = new List<RouteStop>() {jn.RouteStops[i - 1]},},
                        new JobNode() {RouteStops = new List<RouteStop>() {rs}});

                    var nextStopArrivalTime = cumulatingCompletionTime.Add(rsConnection.RouteStatistics.TotalTravelTime);
                    bool isWaitRequired = nextStopArrivalTime <= rs.WindowStart;

                    cumulatingCompletionTime = isWaitRequired
                                                   ? rs.WindowStart.Add(rs.StopDelay.Value)
                                                   : nextStopArrivalTime.Add(rs.StopDelay.Value);

                    for (int q = i; q < jn.RouteStops.Count; q++)
                    {
                        var nextStop = jn.RouteStops[q];
                        bool nextStopEarly = cumulatingCompletionTime < nextStop.WindowStart;
                        bool nextStopLate = cumulatingCompletionTime > nextStop.WindowEnd;

                        if (nextStopLate)
                        {
                            isFeasableTimeWindow = false;
                            break;
                        }
                        else if (nextStopEarly)
                        {
                            if (this._configuration.MaximumWaitTimeBeforeStart < nextStop.WindowStart - cumulatingCompletionTime)
                            {
                                isFeasableTimeWindow = false;
                                break;
                            }

                            var stopDelay = nextStop.StopDelay ?? this._configuration.MaximumWaitTimeAtStop;
                            cumulatingCompletionTime = cumulatingCompletionTime.Add(nextStop.WindowStart + stopDelay - cumulatingCompletionTime);
                        }
                    }
                }
            }
            return isFeasableTimeWindow;
        }

        TimeSpan ConfigureForEarlyArrival(INode endNode, bool isFirstStop, NodeConnection connection, ref TimeSpan waitTime, ref TimeSpan nextNodeArrivalTime, ref bool isFeasableTimeWindow)
        {
            TimeSpan currentNodeEndTime = TimeSpan.Zero;
            waitTime = endNode.WindowStart.Subtract(nextNodeArrivalTime);

            TimeSpan maxWaitTime = isFirstStop ? this._configuration.MaximumWaitTimeBeforeStart : this._configuration.MaximumWaitTimeAtStop;

            isFeasableTimeWindow = waitTime < maxWaitTime;

            if (isFirstStop && isFeasableTimeWindow)
            {
                waitTime = TimeSpan.Zero;
                currentNodeEndTime = endNode.WindowStart - connection.RouteStatistics.TotalTime;
                nextNodeArrivalTime = currentNodeEndTime + connection.RouteStatistics.TotalTime;
            }
            return currentNodeEndTime;
        }
    }
}
