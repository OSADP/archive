﻿using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Node;
//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Provides an interface for calculating the probabilities of selecting a node, and selects the next node to try
    /// </summary>
    public class ProbabilityMatrix : IProbabilityMatrix
    {
        private readonly IRouteService _routeService;
        private readonly IObjectiveFunction _objectiveFunction;
        private readonly IRandomNumberGenerator _randomNumberGenerator;

        private IPheromoneMatrix PheromoneMatrix { get; set; }
        public float Alpha { get; set; }
        public float Beta { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProbabilityMatrix"/> class.
        /// </summary>
        /// <param name="pheromoneMatrix">The pheromone matrix.</param>
        /// <param name="routeService">The route service.</param>
        /// <param name="objectiveFunction">The objective function.</param>
        /// <param name="randomNumberGenerator">The random number generator.</param>
        public ProbabilityMatrix(IPheromoneMatrix pheromoneMatrix, IRouteService routeService, IObjectiveFunction objectiveFunction, IRandomNumberGenerator randomNumberGenerator)
        {
            this._routeService = routeService;
            this._objectiveFunction = objectiveFunction;
            this._randomNumberGenerator = randomNumberGenerator;
            this.PheromoneMatrix = pheromoneMatrix;
            this.Alpha = 1;
            this.Beta = 5;
        }

        /// <summary>
        /// Returns list of probability data
        /// </summary>
        /// <param name="currentNode">the node from which to calculate probabilities from</param>
        /// <param name="availableNodeTimings">a collection of travel time/distance representing travel from the current node to the unscheduled nodes</param>
        /// <returns>a list of ProbabilityItem containing a node and the weighted probability of selecting it as the next node</returns>
        public virtual IList<ProbabilityItem> BuildProbabilityDataMatrix(INode currentNode, IEnumerable<NodeTiming> availableNodeTimings)
        {
            var probabilityDataList = new List<ProbabilityItem>();

            // build probability data matrix for all unprocessed nodes
            foreach (var nodeTiming in availableNodeTimings)
            {
                var topProbability = this.CalculateProbability(currentNode, nodeTiming);

                var pData = new ProbabilityItem()
                {
                    Element = nodeTiming.Node,
                    TopProbability = topProbability
                };

                // store the result
                probabilityDataList.Add(pData);
            }

            this.CalculateProbabilities(probabilityDataList);

            probabilityDataList = probabilityDataList.OrderBy(p => p.CumulativeProbability).ToList();

            return probabilityDataList;
        }

        /// <summary>
        /// Calculates the probabilities for a list of <see cref="ProbabilityItem"/>
        /// </summary>
        /// <param name="probabilityDataList">a list of ProbabilityItem containing a node and the weighted probability of selecting it as the next node</param>
        public virtual void CalculateProbabilities(IList<ProbabilityItem> probabilityDataList)
        {
            double topProbSummation = probabilityDataList.Sum(f => f.TopProbability);
            double cumulativeProbability = 0.0;

            foreach (var probabilityData in probabilityDataList)
            {
                probabilityData.Probability = probabilityData.TopProbability / topProbSummation;
                cumulativeProbability += probabilityData.Probability;
                probabilityData.CumulativeProbability = cumulativeProbability;
            }
        }

        /// <summary>
        /// Calculates the probability of selecting a given node
        /// </summary>
        /// <param name="currentNode">The current node.</param>
        /// <param name="nodeTiming">The node timing representing time and distance to the next node.</param>
        /// <returns>the adjusted maximun probability value for the current node</returns>
        public virtual double CalculateProbability(INode currentNode, NodeTiming nodeTiming)
        {
            var node = nodeTiming.Node as NodeBase;
            var pheromone = this.PheromoneMatrix.GetValue(currentNode, node);
            
            double topProbability = 1.0;
            
            if (pheromone > 0)
            {
                if (this.Alpha > 0)
                {
                    topProbability *= Math.Pow(pheromone, this.Alpha);
                }
            }

            var routeStatistics = this._routeService.CalculateRouteStatistics(currentNode, node);
            var performanceMeasure = this._objectiveFunction.GetObjectiveMeasure(routeStatistics);

            if (this.Beta > 0 && performanceMeasure > 0)
            {
                topProbability *= Math.Pow(1 / performanceMeasure, this.Beta);
            }
            
            return topProbability;
        }

        /// <summary>
        /// Nomiate node from probability data
        /// </summary>
        /// <param name="probabilityData">a list of ProbabilityItem containing a node and the weighted probability of selecting it as the next node</param>
        /// <returns>a weighted random element selected from the list provided in the argument</returns>
        public virtual object GetNominatedElement(IList<ProbabilityItem> probabilityData)
        {
            var rand = this._randomNumberGenerator.NextDouble();

            var data = probabilityData
                .OrderBy(f=> f.CumulativeProbability)
                .FirstOrDefault(d => d.CumulativeProbability > rand);

            return data != null ? data.Element : (probabilityData.First().Element);
        }
    }
}