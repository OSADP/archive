
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using PAI.Core;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// The main entry point for per driver route optimization
    /// </summary>
    public class DrayageOptimizer : IDrayageOptimizer
    {
        int callCount = 0;
        protected readonly ILogger _logger;
        protected readonly IRouteService _routeService;
        protected readonly INodeService _nodeService;
        protected readonly IPheromoneMatrix _pheromoneMatrix;
        protected readonly IRouteStopService _routeStopService;
        protected readonly IRouteExitFunction _routeExitFunction;
        protected readonly IProbabilityMatrix _probabilityMatrix;
        protected readonly IRandomNumberGenerator _randomNumberGenerator;
        private readonly INodeFactory _nodeFactory;

        protected readonly ReaderWriterLockSlim _rwLock = new ReaderWriterLockSlim();
        protected bool _isCancelling = false;
        private bool _initialized = false;

        public bool EnableParallelism { get; set; }
        public int PheromoneUpdateFrequency { get; set; }
        public int MaxIterations { get; set; }
        public int MaxIterationSinceBestResult { get; set; }
        public int MaxExecutionTime { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DrayageOptimizer"/> class.
        /// </summary>
        /// <param name="probabilityMatrix">The probability matrix.</param>
        /// <param name="routeService">The route service.</param>
        /// <param name="nodeService">The node service.</param>
        /// <param name="routeStopService">The route stop service.</param>
        /// <param name="routeExitFunction">The route exit function.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="pheromoneMatrix">The pheromone matrix.</param>
        /// <param name="randomNumberGenerator">The random number generator.</param>
        /// <param name="nodeFactory">The node factory.</param>
        public DrayageOptimizer(IProbabilityMatrix probabilityMatrix,
            IRouteService routeService, INodeService nodeService, IRouteStopService routeStopService,
            IRouteExitFunction routeExitFunction, ILogger logger, IPheromoneMatrix pheromoneMatrix, IRandomNumberGenerator randomNumberGenerator, INodeFactory nodeFactory)
        {
            this._probabilityMatrix = probabilityMatrix;
            this._routeStopService = routeStopService;
            this._routeExitFunction = routeExitFunction;
            this._logger = logger;
            this._pheromoneMatrix = pheromoneMatrix;
            this._randomNumberGenerator = randomNumberGenerator;
            this._nodeFactory = nodeFactory;
            this._nodeService = nodeService;
            this._routeService = routeService;

            // default values
            this.EnableParallelism = false;
            this.PheromoneUpdateFrequency = 10;
            this.MaxIterations = 10000;
            this.MaxIterationSinceBestResult = 1000;
            this.MaxExecutionTime = 10000;
        }

        /// <summary>
        /// Cancels the optimization run.
        /// </summary>
        public virtual void Cancel()
        {
            this._rwLock.EnterWriteLock();

            this._isCancelling = true;
            
            this._rwLock.ExitWriteLock();
        }

        /// <summary>
        /// Initializes Optimizer
        /// </summary>
        public virtual void Initialize()
        {
            this._initialized = true;
        }


        #region Progress Event
        public event EventHandler<ProgressEventArgs> ProgressChanged = null;

        private void OnProgressEvent(ProgressEventArgs eventArgs)
        {
            if (this.ProgressChanged != null)
            {
                this.ProgressChanged.Invoke(this, eventArgs);
            }
        }
        #endregion

      
        /// <summary>
        /// Creates route assignments from the given trucks and jobs
        /// </summary>
        /// <param name="drivers">the list of drivers available to run routes</param>
        /// <param name="defaultDriver">a default driver to use if there are more routes generated than drivers</param>
        /// <param name="jobs">a list of jobs to optimize</param>
        /// <returns></returns>
        public virtual Solution BuildSolution(IList<Driver> drivers, Driver defaultDriver, IList<Job> jobs)
        {
            if (drivers == null) throw new ArgumentNullException("drivers");
            if (jobs == null) throw new ArgumentNullException("jobs");
            if (defaultDriver == null) throw new ArgumentNullException("defaultDriver");
            if (jobs.Count == 0) throw new OptimizationException("Need at least one job to build solution");

            if (!this._initialized)
            {
                throw new OptimizationException("Optimizer not intialized.  Call Initialize() prior to building solutions.");
            }

            this._isCancelling = false;

            // clear pheromone matrix
            this._pheromoneMatrix.Clear();

            // Create driver nodes
            var driverNodes = drivers.Select(driver => new DriverNode(driver))
                .OrderBy(f => this._randomNumberGenerator.Next())
                .ToList();


            // Create job nodes
            var jobNodes = new List<JobNode>();
            foreach (var job in jobs.OrderBy(f => this._randomNumberGenerator.Next()))
            {
                var jobNode = this._nodeFactory.CreateJobNode(job);  // create node
                //jobNode.RouteStatistics = this._routeStopService.CalculateRouteStatistics(jobNode.RouteStops, new TimeSpan(), false);
                jobNodes.Add(jobNode);
            }

            // create dummy drivers (for worst case scenario)
            var dummyDriversToCreate = jobNodes.Count() - driverNodes.Count();
            if (dummyDriversToCreate > 0)
            {
                for (int i = 0; i < dummyDriversToCreate; i++)
                {
                    var newId = driverNodes.Max(x => x.Driver.Id) + 1;
                    var defaultDriverInstance = new Driver(defaultDriver)
                    {
                        Id = newId,
                        DisplayName = string.Format("Driver {0}", newId)
                    };
                    var dummyDriverNode = new DriverNode(defaultDriverInstance);
                    driverNodes.Add(dummyDriverNode);
                }
            }
            
            // build solution
            var bestSolution = this.BuildSolution(defaultDriver, jobNodes.Cast<INode>().ToList(), driverNodes);
            
            this._isCancelling = false;

            return bestSolution;
        }

        /// <summary>
        /// Builds the solution.
        /// </summary>
        /// <param name="dummyDriver">The dummy driver.</param>
        /// <param name="jobNodes">The job nodes.</param>
        /// <param name="driverNodes">The driver nodes.</param>
        /// <returns></returns>
        public virtual Solution BuildSolution(Driver dummyDriver, IList<INode> jobNodes, IList<DriverNode> driverNodes)
        {
            var stopWatch = new System.Diagnostics.Stopwatch();
            stopWatch.Start();

            int iterationsSinceBestResult = 0;
            int totalIterations = 0;
            bool stopping = false;

            Solution bestSolution = null;
            var subSolutions = new List<Solution>();

            // Define iteration
            Action<int, ParallelLoopState> iterationAction = (i, loopState) =>
                {
                    var solution = this.ProcessDrivers(driverNodes, dummyDriver, jobNodes);
                    
                    this._rwLock.EnterWriteLock();
                    {
                        totalIterations++;
                        iterationsSinceBestResult++;
                        subSolutions.Add(solution);

                        // Update progress
                        this.OnProgressEvent(new ProgressEventArgs() { PrimaryTotal = this.MaxIterations, PrimaryValue = totalIterations });

                        var oldBest = bestSolution;

                        bestSolution = bestSolution == null ? solution : this._routeService.GetBestSolution(bestSolution, solution);

                        if(bestSolution != oldBest)
                        {
                            iterationsSinceBestResult = 0;
                        }

                        // Check exit criteria
                        if ((loopState == null || !loopState.IsStopped) && iterationsSinceBestResult > this.MaxIterationSinceBestResult)
                        {
                            this._logger.Info("Max iterations since best result reached ({0})", this.MaxIterationSinceBestResult);
                            stopping = true;
                        }

                        if ((loopState == null || !loopState.IsStopped) && stopWatch.ElapsedMilliseconds > this.MaxExecutionTime)
                        {
                            this._logger.Info("Max execution time {0} reached", this.MaxExecutionTime);
                            stopping = true;
                        }

                        if (this._isCancelling)
                        {
                            stopping = true;
                        }

                        if (stopping)
                        {
                            if (loopState != null)
                                loopState.Stop();
                        }

                    }
                    this._rwLock.ExitWriteLock();

                    // Update Pheromone Matrix 
                    if (!stopping && this.PheromoneUpdateFrequency > 0 && i > 0 && i % this.PheromoneUpdateFrequency == 0)
                    {
                        List<Solution> subResultCopy = null;

                        this._rwLock.EnterWriteLock();
                        {
                            subResultCopy = subSolutions.ToList();
                            subSolutions.Clear();
                        }
                        this._rwLock.ExitWriteLock();

                        foreach (var subSolution in subResultCopy)
                        {
                            this._pheromoneMatrix.UpdatePheromoneMatrix(subSolution);
                        }
                    }
                };

            stopWatch.Stop();

            // Run iterations
            if (this.EnableParallelism)
            {
                Parallel.For(0, this.MaxIterations, iterationAction);
            }
            else
            {
                for (var i = 0; i < this.MaxIterations; i++)
                {
                    iterationAction(i, null);

                    if (stopping)
                        break;
                }
            }

            return bestSolution;
        }

        /// <summary>
        /// Creates our route assignments by processing all the drivers and getting their routes
        /// </summary>
        /// <returns>a generated solution of optimized stops</returns>
        public virtual Solution ProcessDrivers(IList<DriverNode> driverNodes, Driver dummyDriver, IList<INode> jobNodes)
        {
            var solution = new Solution();
            var availableNodes = jobNodes;

            // going through all the drivers
            foreach (var driverNode in driverNodes)
            {
                if (availableNodes.Count == 0)
                    break;

                // get the route solution for this particular driver
                var nodeRouteSolution = this.GenerateRouteSolution(availableNodes, driverNode);
                                        
                // insert solution
                solution.RouteSolutions.Add(nodeRouteSolution);

                // update available nodes based on new solution
                availableNodes = availableNodes.Where(n => !nodeRouteSolution.Nodes.Contains(n)).ToList();
            }

            // Add unassigned job nodes
            solution.UnassignedJobNodes.AddRange(availableNodes);
            
            return solution;
        }

        /// <summary>
        /// Generates node sequence iteration
        /// </summary>
        /// <param name="nodes">a list of nodes to optimize</param>
        /// <param name="driverNode">the driver for the route</param>
        /// <returns>an optimized route</returns>
        public virtual NodeRouteSolution GenerateRouteSolution(IList<INode> nodes, DriverNode driverNode)
        {
            IList<INode> processedNodes = new List<INode>();
            INode currentNode = driverNode;
            var startTime = driverNode.Driver.EarliestStartTime;
            var currentNodeEndTime = startTime;
            var cumulativeRouteStatistics = new RouteStatistics();

            int exitCounter = 0;
            while (exitCounter++ < 1000)
            {
                // getting avaiable nodes that have not been processed
                var feasibleNodeTimings = this.GetFeasibleNodes(nodes, driverNode, processedNodes, currentNodeEndTime, cumulativeRouteStatistics);

                if (!feasibleNodeTimings.Any())
                    break;
                
                var feasibleNodeTimingsByNode = feasibleNodeTimings.ToDictionary(f => f.Node);

                // build probability matrix for the available nodes
                var probabilityData = this._probabilityMatrix.BuildProbabilityDataMatrix(currentNode, feasibleNodeTimings);

                // find a suitable node based on the cumulative probability
                var selectedNode = (INode) this._probabilityMatrix.GetNominatedElement(probabilityData);
                processedNodes.Add(selectedNode);
                currentNode = selectedNode;
                
                // now we update the current node's end time
                var selectedNodeTiming = feasibleNodeTimingsByNode[selectedNode];

                if (processedNodes.Count == 1 && selectedNodeTiming.DepartureTime != currentNodeEndTime)
                {
                    startTime = selectedNodeTiming.DepartureTime;
                }

                currentNodeEndTime = selectedNodeTiming.EndExecutionTime;
                cumulativeRouteStatistics = selectedNodeTiming.CumulativeRouteStatistics;
            }

            // create solution object
            var result = this._routeService.CreateRouteSolution(processedNodes, driverNode);

            result.StartTime = startTime;
            return result;
        }

        /// <summary>
        /// Gets the feasible nodes.
        /// </summary>
        /// <param name="availableNodes">The available nodes.</param>
        /// <param name="driverNode">The driver node.</param>
        /// <param name="processedNodes">The processed nodes.</param>
        /// <param name="currentNodeEndTime">The current node end time.</param>
        /// <param name="cumulativeRouteStatistics">The cumulative route statistics.</param>
        /// <returns></returns>
        public virtual List<NodeTiming> GetFeasibleNodes(IList<INode> availableNodes, DriverNode driverNode, IList<INode> processedNodes,
            TimeSpan currentNodeEndTime, RouteStatistics cumulativeRouteStatistics)
        {   
            var isFirstStop = (processedNodes.Count == 0);
            var currentNode = isFirstStop ? driverNode : processedNodes.Last();

            // get the node timings for all of the available nodes
            var nodeTimings = availableNodes.Except(processedNodes)
                .Select(nextNode => this._nodeService.GetNodeTiming(currentNode, nextNode, currentNodeEndTime, cumulativeRouteStatistics))
                .ToList();
            var feasibleNodes = new List<NodeTiming>();
            foreach (var nodeTiming in nodeTimings.Where(f => f.IsFeasableTimeWindow))
            {
                var finalConnection = this._nodeService.GetNodeConnection(nodeTiming.Node, driverNode);
                var finalRouteStatistics = nodeTiming.CumulativeRouteStatistics + finalConnection.RouteStatistics;

                if (!this._routeExitFunction.ExeedsExitCriteria(finalRouteStatistics, driverNode.Driver))
                {
                    feasibleNodes.Add(nodeTiming);
                }
                else
                {
                    if (driverNode.Driver.DisplayName.StartsWith("Place"))
                        this._routeExitFunction.ExeedsExitCriteria(finalRouteStatistics, driverNode.Driver);
                }
            }

            return feasibleNodes;
        }
    }

}