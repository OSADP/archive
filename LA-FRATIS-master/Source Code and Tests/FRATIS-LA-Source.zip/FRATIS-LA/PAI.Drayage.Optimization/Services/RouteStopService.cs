using System;
using System.Collections.Generic;

using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    public class RouteStopService : IRouteStopService
    {
        private const int MaximumIdleMinutesAtStop = 30;
        private readonly IDistanceService _distanceService;
        private readonly OptimizerConfiguration _configuration;
        private readonly IRouteStopDelayService _routeStopDelayService;


        public RouteStopService(IDistanceService distanceService, OptimizerConfiguration configuration, IRouteStopDelayService routeStopDelayService)
        {
            _distanceService = distanceService;
            _configuration = configuration;
            _routeStopDelayService = routeStopDelayService;
        }

        /// <summary>
        /// Calculates the trip length between two stops
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        public TripLength CalculateTripLength(RouteStop start, RouteStop end)
        {
            return _distanceService.CalculateDistance(start.Location, end.Location);
        }

        /// <summary>
        /// Calculates the trip length between two stops
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="startTime"></param>
        /// <returns></returns>
        public TripLength CalculateTripLength(RouteStop start, RouteStop end, TimeSpan startTime)
        {
            return _distanceService.CalculateDistance(start.Location, end.Location, startTime);
        }

        /// <summary>
        /// Calculates the toal route statistics a list of route stops
        /// </summary>
        /// <param name="stops"></param>
        /// <param name="ignoreFirstStopDelays"> </param>
        /// <returns></returns>
        public RouteStatistics CalculateRouteStatistics(IList<RouteStop> stops, bool ignoreFirstStopDelays)
        {
            var result = new RouteStatistics();

            for (int i = 0; i < stops.Count; i++)
            {
                var currentStop = stops[i];

                if (!ignoreFirstStopDelays || !(i == 0 || i == stops.Count - 1))
                {
                    var executionTime = _routeStopDelayService.GetExecutionTime(currentStop, TimeSpan.Zero);

                    var staticStats = new RouteStatistics()
                    {
                        TotalExecutionTime = executionTime,
                    };

                    result += staticStats;
                }

                // add travel cost
                if (i < stops.Count - 1)
                {
                    var nextStop = stops[i + 1];

                    // calculate the trip between the current and next stop
                    var tripLength = CalculateTripLength(currentStop, nextStop);

                    var travelStats = new RouteStatistics()
                    {

                        TotalTravelTime = tripLength.Time,
                        TotalTravelDistance = tripLength.Distance,
                    };

                    result += travelStats;
                }
            }

            return result;
        }

        /// <summary>
        /// Calculates the route statistics for a list of stops
        /// </summary>
        /// <param name="stops"></param>
        /// <param name="startTime"></param>
        /// <param name="ignoreFirstStopDelays"> </param>
        /// <returns></returns>
        public RouteStatistics CalculateRouteStatistics(IList<RouteStop> stops, TimeSpan startTime, bool ignoreFirstStopDelays)
        {
            var result = new RouteStatistics();

            var currentTime = startTime;

            for (int i = 0; i < stops.Count; i++)
            {
                var currentStop = stops[i];

                if (!ignoreFirstStopDelays || !(i == 0 || i == stops.Count - 1))
                {
                    var executionTime = _routeStopDelayService.GetExecutionTime(currentStop, currentTime);
                    var staticStats = new RouteStatistics()
                    {
                        TotalExecutionTime = executionTime,
                    };

                    result += staticStats;
                }

                // add travel cost
                if (i < stops.Count - 1)
                {
                    var nextStop = stops[i + 1];
                    if (currentStop.Location != null && nextStop.Location != null)
                    {
                        // calculate the trip between the current and next stop
                        var tripLength = CalculateTripLength(currentStop, nextStop, currentTime);
                        var queueTime = _routeStopDelayService.GetQueueTime(currentStop, nextStop, currentTime);
                        var travelStats = new RouteStatistics()
                        {

                            TotalTravelTime = tripLength.Time,
                            TotalTravelDistance = tripLength.Distance,
                            TotalQueueTime = queueTime,
                        };

                        result += travelStats;
                    }
                }

                // update current time with accumulated total time
                currentTime = startTime + result.TotalTime;
            }

            return result;
        }


        /// <summary>
        /// Calculates the route segment statistics for a list of stops
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="stops"></param>
        /// <returns></returns>
        public IList<RouteSegmentStatistics> CalculateRouteSegmentStatistics(TimeSpan startTime, IList<RouteStop> stops)
        {
            var result = new List<RouteSegmentStatistics>();

            var currentTime = startTime;

            for (int i = 0; i < stops.Count - 1; i++)
            {
                var startStop = stops[i];
                var endStop = stops[i + 1];

                var segment = CreateRouteSegmentStatistics(currentTime, startStop, endStop);
                currentTime = segment.EndTime;

                result.Add(segment);
            }

            return result;
        }

        /// <summary>
        /// Creates a route segment statistics
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="startStop"></param>
        /// <param name="endStop"></param>
        /// <returns></returns>
        public RouteSegmentStatistics CreateRouteSegmentStatistics(TimeSpan startTime, RouteStop startStop, RouteStop endStop)
        {
            // calculate the trip between the current and next stop
            var tripLength = CalculateTripLength(startStop, endStop);
            var maxIdleTime = new TimeSpan(0, MaximumIdleMinutesAtStop, 0);
            var arrivalTimeAtEndStop = startTime + tripLength.Time;

            bool early = arrivalTimeAtEndStop < endStop.WindowStart;
            bool late = arrivalTimeAtEndStop > endStop.WindowEnd;

            TimeSpan idleTime = TimeSpan.Zero;
            bool whiffed = false;

            if (early)
            {
                // when early for window, check how long wait for window is
                idleTime = endStop.WindowStart.Subtract(arrivalTimeAtEndStop);
                // if arrival is after the beginning of the window, idle time is zero
                if (arrivalTimeAtEndStop > endStop.WindowStart)
                {
                    idleTime = TimeSpan.Zero;
                }
                // we whiffed if we idle for longer than allowed time
                whiffed = idleTime > maxIdleTime;
            }
            else if (late)
            {
                // we started past the time window
                whiffed = true;
            }

            var executionTime = _routeStopDelayService.GetExecutionTime(endStop, arrivalTimeAtEndStop);

            TimeSpan queueTime = _routeStopDelayService.GetQueueTime(startStop, endStop, arrivalTimeAtEndStop);

            var routeStatistics = new RouteStatistics()
            {
                TotalExecutionTime = executionTime,
                TotalIdleTime = idleTime,
                TotalTravelTime = tripLength.Time,
                TotalTravelDistance = tripLength.Distance,
                TotalQueueTime = queueTime,
                TotalWaitTime = idleTime + queueTime
            };

            var result = new RouteSegmentStatistics
            {
                StartStop = startStop,
                EndStop = endStop,
                StartTime = startTime,
                Statistics = routeStatistics,
                WhiffedTimeWindow = whiffed
            };

            return result;
        }
    }
}