﻿using System;
using System.Linq;

using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    public interface INodeFactory
    {
        JobNode CreateJobNode(Job job);
    }

    /// <summary>
    /// Factory class for Node creation
    /// </summary>
    public class NodeFactory : INodeFactory
    {
        private readonly IRouteStopService _routeStopService;

        /// <summary>
        /// Initializes a new instance of the <see cref="NodeFactory"/> class.
        /// </summary>
        /// <param name="routeStopService">The route stop service.</param>
        public NodeFactory(IRouteStopService routeStopService)
        {
            this._routeStopService = routeStopService;
        }

        /// <summary>
        /// Creates a JobNode from the provided Job
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public JobNode CreateJobNode(Job job)
        {
            ValidateJobForJobNode(job);

            var result = new JobNode()
            {
                Job = job,
                RouteStops = job.RouteStops.ToList(),
                WindowStart = job.RouteStops.ToList().First().WindowStart,
                WindowEnd = job.RouteStops.ToList().First().WindowEnd,
            };

            var indexOfFirstWindow = this.GetIndexOfFirstRouteStopWithWindow(result);

            for (int i = indexOfFirstWindow; i > 0; i--)
            {
                var rs = result.RouteStops[i];
                var nextStop = result.RouteStops[i - 1];

                var routeSegmentStatistics = this._routeStopService.CreateRouteSegmentStatistics(rs.WindowStart, rs, nextStop);
                var delay = (rs.StopDelay.HasValue) ? routeSegmentStatistics.Statistics.TotalTravelTime + rs.StopDelay : routeSegmentStatistics.Statistics.TotalTravelTime;
                result.WindowEnd = rs.WindowEnd - delay.Value;
            }

            return result;
        }

        /// <summary>
        /// Validates the job used to create the job node.
        /// </summary>
        /// <param name="job">The job.</param>
        /// <exception cref="System.ArgumentNullException">NodeFactory.CreateJobNode requires a job.</exception>
        /// <exception cref="OptimizationException">
        /// NodeFactory.CreateJobNode requires a job with at least one stop in the collection.
        /// or
        /// The job with Start Window of {0} and End Window of {0} has an invalid duration
        /// or
        /// The job with Start Window of {0} and End Window of {0} does not have a location set
        /// </exception>
        static void ValidateJobForJobNode(Job job)
        {
            if (job == null)
            {
                throw new ArgumentNullException("NodeFactory.CreateJobNode requires a job.");
            }
            if (job.RouteStops.Count == 0)
            {
                throw new OptimizationException("NodeFactory.CreateJobNode requires a job with at least one stop in the collection.");
            }
            foreach (var routeStop in job.RouteStops)
            {
                try
                {
                    var test = routeStop.WindowEnd - routeStop.WindowStart;
                }
                catch (Exception)
                {
                    throw new OptimizationException(string.Format("The job with Start Window of {0} and End Window of {0} exceeds allowable range", routeStop.WindowStart, routeStop.WindowEnd));
                }

                if (routeStop.WindowStart >= routeStop.WindowEnd)
                {
                    throw new OptimizationException("The job with Start Window of {0} and End Window of {0} has an invalid duration", routeStop.WindowStart, routeStop.WindowEnd);
                }

                if (routeStop.Location == default(Location))
                {
                    throw new OptimizationException("The job with Start Window of {0} and End Window of {0} does not have a location set", routeStop.WindowStart, routeStop.WindowEnd);
                }
            }
        }

        /// <summary>
        /// Gets the index of first route stop with window.
        /// </summary>
        /// <param name="jobNode">The job node.</param>
        /// <returns>the index of the first job that has a window of less than a day</returns>
        private int GetIndexOfFirstRouteStopWithWindow(JobNode jobNode)
        {
            for (int i = 0; i < jobNode.RouteStops.Count; i++)
            {
                var rs = jobNode.RouteStops[i];
                var duration = rs.WindowEnd - rs.WindowStart;

                if (duration < new TimeSpan(23, 59, 0))
                {
                    return i;
                }
            }

            return -1;
        }
    }
}
