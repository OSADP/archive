﻿using NUnit.Framework;
using Ninject.MockingKernel.Moq;

namespace PAI.FRATIS.Tests
{
    [TestFixture]
    public abstract class TestsBase
    {
        public MoqMockingKernel Kernel { get; set; }

        [SetUp]
        public void BaseSetUp()
        {
            Kernel = new MoqMockingKernel();
        }
    }
}