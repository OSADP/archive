﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public enum InformationalStatusType
    {
        Unspecified = 0,
        NavigationStarted = 1,
        NavigationCancelled = 2,
        DestinationReached = 3
    }
}
