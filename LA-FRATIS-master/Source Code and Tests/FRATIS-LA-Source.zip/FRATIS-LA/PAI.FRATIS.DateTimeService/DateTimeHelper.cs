﻿//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;

using NodaTime.TimeZones;
using NodaTime.TimeZones.Cldr;

namespace PAI.FRATIS.DateTimeService
{
    public interface IDateTimeHelper
    {
        #region Public Methods and Operators

        double ConvertDateTimeToUnixTime(DateTime dt);

        DateTime ConvertLocalToUtcTime(DateTime dt);

        DateTime ConvertToTime(DateTime dt, TimeZoneInfo sourceTimeZone, TimeZoneInfo destinationTimeZone);

        DateTime ConvertUnixTimeToDateTime(double unixTime);

        DateTime ConvertUtcToLocalTime(DateTime dt);

        DateTime GetLocalDateTimeNow();

        TimeZoneInfo GetLocalTimeZoneInfo();

        TimeZoneInfo GetTimeZoneInfo(string timeZoneId);

        #endregion
    }

    /// <summary>The date time helper.</summary>
    public class DateTimeHelper : IDateTimeHelper
    {
        #region Fields

        private TimeZoneInfo _timeZone;

        #endregion

        #region Public Properties

        public TimeZoneInfo CurrentTimeZone
        {
            get
            {
                return this._timeZone ?? (this._timeZone = TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
            }
        }

        #endregion

        #region Public Methods and Operators

        public double ConvertDateTimeToUnixTime(DateTime dt)
        {
            return (dt - new DateTime(1970, 1, 1)).TotalSeconds;
        }

        public DateTime ConvertLocalToUtcTime(DateTime dt)
        {
            if (dt.Kind == DateTimeKind.Utc)
            {
                return dt;
            }
            return this.ConvertToTime(dt, this.CurrentTimeZone, TimeZoneInfo.Utc);
        }

        public DateTime ConvertToTime(DateTime dt, TimeZoneInfo sourceTimeZone, TimeZoneInfo destinationTimeZone)
        {
            try
            {
                switch (dt.Kind)
                {
                    case DateTimeKind.Local:
                        sourceTimeZone = this.CurrentTimeZone;
                        break;
                    case DateTimeKind.Utc:
                        sourceTimeZone = TimeZoneInfo.Utc;
                        break;
                }

                // convert sourceTimeZone and dt to UTC in order to complete the conversion
                dt = TimeZoneInfo.ConvertTime(dt, sourceTimeZone, TimeZoneInfo.Utc);
                sourceTimeZone = TimeZoneInfo.Utc;

                // now convert to desired destination time zone
                dt = dt.Kind == DateTimeKind.Utc
                         ? TimeZoneInfo.ConvertTimeFromUtc(dt, destinationTimeZone)
                         : TimeZoneInfo.ConvertTimeToUtc(dt, sourceTimeZone);

                return dt;
            }
            catch (ArgumentException ex)
            {
                throw new Exception("ConvertToTime Argument Exception");
            }
        }

        public DateTime ConvertUnixTimeToDateTime(double unixTime)
        {
            var dt = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            dt = dt.AddSeconds(unixTime);
            return dt;
        }

        public DateTime ConvertUtcToLocalTime(DateTime dt)
        {
            return dt.Kind == DateTimeKind.Local ? dt : this.ConvertToTime(dt, TimeZoneInfo.Utc, this.CurrentTimeZone);
        }

        public DateTime GetLocalDateTimeNow()
        {
            return this.ConvertUtcToLocalTime(DateTime.UtcNow);
        }

        public TimeZoneInfo GetLocalTimeZoneInfo()
        {
            return this.CurrentTimeZone;
        }

        public TimeZoneInfo GetTimeZoneInfo(string timeZoneId)
        {
            return TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
        }

        public string IanaToWindows(string ianaZoneId)
        {
            TzdbDateTimeZoneSource tzdbSource = TzdbDateTimeZoneSource.Default;
            IList<MapZone> mappings = tzdbSource.WindowsMapping.MapZones;
            MapZone item = mappings.FirstOrDefault(x => x.TzdbIds.Contains(ianaZoneId));
            if (item == null)
            {
                return null;
            }
            return item.WindowsId;
        }

        // This will return the "primary" IANA zone that matches the given windows zone.
        public string WindowsToIana(string windowsZoneId)
        {
            TzdbDateTimeZoneSource tzdbSource = TzdbDateTimeZoneSource.Default;
            TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById(windowsZoneId);
            return tzdbSource.MapTimeZoneId(tzi);
        }

        #endregion
    }
}