﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

using NUnit.Framework;

using Ninject;

using PAI.FRATIS.Tests;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.FRATIS.Wrappers.WebFleet.Mapping;
using PAI.FRATIS.Wrappers.WebFleet.MessagesService;
using PAI.FRATIS.Wrappers.WebFleet.Model;
using PAI.FRATIS.Wrappers.WebFleet.Settings;

namespace PAI.FRATIS.ExternalServices.Tests
{
    public class WebFleetExternalTests : WebFleetTests
    {
        #region Fields
        #endregion

        #region Public Methods and Operators

        [Test]
        public void CanAddDriver()
        {
            bool result = this._driverService.AddDriver("GetRouteSummary Driver", "9999", "", "");
            Assert.That(result);
        }

        [Test]
        public void CanDeleteDriver()
        {
            bool result = this._driverService.DeleteDriver("9999");
            Assert.That(result);
        }

        [Test]
        public void CanGetDrivers()
        {
            var sw = new Stopwatch();
            sw.Start();

            ICollection<WebFleetDriver> result = this._objectService.GetDrivers();

            foreach (var d in result)
            {
                Console.WriteLine(d.Name);
            }
            sw.Stop();

            Console.WriteLine(sw.Elapsed.ToString());
            Assert.That(result.Count > 0);
        }

        [Test]
        public void CanGetObjects()
        {
            ICollection<WebFleetObject> result = this._objectService.GetObjects();
            Assert.That(result.Count > 0);
        }

        [Test]
        public void CanGetOrders()
        {
            ICollection<WebFleetOrder> result = this._orderService.GetOrders(SelectionTimeSpan.ThisMonth);
            Assert.That(result.Count > 0);
        }

        [Test]
        public void CanGetStandStillReport()
        {
            ICollection<WebFleetStandStill> result =
                this._tripReportingService.GetStandStills(SelectionTimeSpan.ThisWeek);
            Assert.That(result.Count > 0);
        }

        [Test]
        public void Can_Assign_Vehicle_From_Driver_Report()
        {
        }

        [Test]
        public void Can_Calculate_Route()
        {
            var location1 = new WebFleetPosition { Latitude = 28.9084, Longitude = -82.0127 };

            WebFleetPosition l1 = this._addressService.GeocodeAddress("Miami", "33111", string.Empty, string.Empty);
            WebFleetPosition location2 = this._addressService.GeocodeAddress(
                "Cumberland", "21502", string.Empty, string.Empty);

            WebFleetRouteEstimate result = this._addressService.CalculateRoute(
                new WebFleetSettings(), l1, location2, false, DateTime.Now.AddHours(3));

            Console.WriteLine(string.Format("Distance: {0}", result.Distance.Miles));
        }

        [Test]
        public void Can_Create_Messages_Queue()
        {
            bool result = this._messagesService.CreateQueue(QueueServiceMessageClassFilter.ALL);
            Assert.That(result);
        }

        [Test]
        public void Can_Get_AddressIds_In_Group()
        {
            ICollection<string> result = this._addressService.GetWebFleetAddressIdsByGroupName("Customer");

            Assert.That(result != null, "Result is null");
            Assert.That(result.Count > 0, "No results found");

            Console.WriteLine("Found records: " + result.Count + "\n");
            int count = 0;
            foreach (string id in result)
            {
                if (count % 6 == 0)
                {
                    Console.Write("\n\t");
                }
                Console.Write(id + " ");
                count++;
            }
        }

        [Test]
        public void Can_Get_Vehicel_Report()
        {
            List<WebFleetObject> result = this._objectService.ShowVehicleReport(string.Empty, true);
            Assert.That(result.Count > 0);

            Console.WriteLine("{0} vehicles returned", result.Count);
            foreach (WebFleetObject v in result)
            {
                Console.WriteLine("\t{0} {1} {2}", v.ObjectNumber, v.LicensePlate, v.Odometer);
            }
        }

        [Test]
        public void Can_get_webfleet_location()
        {
            string addressIdToFetch = "3PLCACAR";
            WebFleetAddress webfleetAddress = this._addressService.GetAddress(addressIdToFetch);

            WebFleetAddress x = webfleetAddress;
        }

        [Test]
        public void Can_get_webfleet_locations_in_group()
        {
            string groupToFetch = "Customer";
            ICollection<string> webfleetAddresses = this._addressService.GetWebFleetAddressIdsByGroupName(groupToFetch);
            int count = webfleetAddresses.Count;
        }

        [Test]
        public void Can_get_webfleet_order()
        {
            // var order = _orderService.GetOrder("test1");
            ICollection<WebFleetOrder> orders = this._orderService.GetOrders(SelectionTimeSpan.ThisWeek);

            //var x = order;
        }
        
        [Test]
        public void Temp_WebFleet_Location_Test()
        {
            ICollection<string> webfleetAddresses = this._addressService.GetWebFleetAddressIdsByGroupName("Customers");
            Console.WriteLine(webfleetAddresses.Count);
        }

        #endregion
    }
}