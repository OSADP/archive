﻿using NUnit.Framework;

using Ninject;

using PAI.FRATIS.Tests;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.FRATIS.Wrappers.WebFleet.Mapping;

namespace PAI.FRATIS.ExternalServices.Tests
{
    public class WebFleetTests : TestsBase
    {
        #region Fields

        protected IWebFleetAddressService _addressService;

        protected IWebFleetDriverService _driverService;

        protected IWebFleetMappingService _mappingService;

        protected IWebFleetMessagesService _messagesService;

        protected IWebFleetObjectService _objectService;

        protected IWebFleetOrderService _orderService;

        protected IWebFleetTripReportingService _tripReportingService;

        #endregion

        #region Public Methods and Operators

        [SetUp]
        public void SetUp()
        {
            this._messagesService = null;
            this._addressService = null;
            this._objectService = null;
            this._orderService = null;
            this._driverService = null;
            this._mappingService = null;
            this._tripReportingService = null;

            this.Kernel.Rebind<IWebFleetMessagesService>().To(typeof(WebFleetMessagesService));
            this.Kernel.Rebind<IWebFleetObjectService>().To(typeof(WebFleetObjectService));
            this.Kernel.Rebind<IWebFleetDriverService>().To(typeof(WebFleetDriverService));
            this.Kernel.Rebind<IWebFleetAddressService>().To(typeof(WebFleetAddressService));
            this.Kernel.Rebind<IWebFleetMappingService>().To(typeof(WebFleetMappingService));
            this.Kernel.Rebind<IWebFleetOrderService>().To(typeof(WebFleetOrderService));
            this.Kernel.Rebind<IWebFleetTripReportingService>().To(typeof(WebFleetTripReportingService));

            this._messagesService = this.Kernel.Get<IWebFleetMessagesService>();
            this._addressService = this.Kernel.Get<IWebFleetAddressService>();
            this._objectService = this.Kernel.Get<IWebFleetObjectService>();
            this._orderService = this.Kernel.Get<IWebFleetOrderService>();
            this._driverService = this.Kernel.Get<IWebFleetDriverService>();
            this._mappingService = this.Kernel.Get<IWebFleetMappingService>();
            this._tripReportingService = this.Kernel.Get<IWebFleetTripReportingService>();
        }

        #endregion
    }
}