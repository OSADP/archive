﻿using System;
using System.Collections.Generic;

using NUnit.Framework;

using Ninject;

using PAI.FRATIS.Domain.Orders;
using PAI.FRATIS.Tests;
using PAI.FRATIS.YusenTerminalService;

namespace PAI.FRATIS.ExternalServices.Tests
{
    /// <summary>The nokia external tests.</summary>
    public class YusenWebServiceTests : TestsBase
    {
        #region Fields

        private IYusenService _yusenService;

        #endregion

        #region Public Methods and Operators

        [Test]
        public void Can_confirm_container_import_pickup_loaded_from_terminal()
        {
            var terminalLocationIds = new List<int?> { 1270 };
            var job = new Job
                {
                    AlgorithmETA = new DateTime(2014, 6, 17, 12, 0, 0),
                    ContainerNumber = "NYKU3719450",
                    RouteStops =
                        new List<RouteStop>
                            {
                                new RouteStop { LocationId = 1270, StopAction = new StopAction { ShortName = "PLWC" } },
                                new RouteStop { LocationId = 1, StopAction = new StopAction { ShortName = "DLWC" } }
                            }
                };

            ConfirmJobResponse confirmResponse = this._yusenService.ConfirmJob(
                job, "PLG", "Driver Name", "PLATE", terminalLocationIds);
            Console.WriteLine(confirmResponse);
        }

        [Test]
        public void Can_confirm_export_pickup()
        {
            //var confirmResponse = _yusenService.ConfirmJob("", "Trucking Company", DateTime.UtcNow.AddHours(24), "Import Driver Name", "PLATE2");
            //Console.WriteLine(confirmResponse);
        }

        [Test]
        public void Can_get_booking_inquiry()
        {
            string bookingNumber = "6054315770";
            BookingInquiryResponse response = this._yusenService.GetBookingInquiry(bookingNumber);
            Console.WriteLine(
                "Booking Number {0}:  Quantity {1} - Empty Containers {2}",
                bookingNumber,
                response.Quantity,
                response.EmptiesAvailable);

            bookingNumber = "6064237302";
            response = this._yusenService.GetBookingInquiry(bookingNumber);
            Console.WriteLine(
                "Booking Number {0}:  Quantity {1} - Empty Containers {2}",
                bookingNumber,
                response.Quantity,
                response.EmptiesAvailable);

            bookingNumber = "2543418240";
            response = this._yusenService.GetBookingInquiry(bookingNumber);
            Console.WriteLine(
                "Booking Number {0}:  Quantity {1} - Empty Containers {2}",
                bookingNumber,
                response.Quantity,
                response.EmptiesAvailable);
        }

        [Test]
        public void Can_get_container_availablity()
        {
            string containerToCheck = "OOLU8918134";
            ContainerAvailabilityResponse response = this._yusenService.GetContainerAvailability(containerToCheck);
            Console.WriteLine(
                "Container {0}:  Is available: {1}  -   {2}",
                containerToCheck,
                response.IsAvailable,
                response.ReadyForDelivery);

            return;
            containerToCheck = "OOLU8464068";
            response = this._yusenService.GetContainerAvailability(containerToCheck);
            Console.WriteLine(
                "Container {0}:  Is available: {1}  -   {2}",
                containerToCheck,
                response.IsAvailable,
                response.ReadyForDelivery);

            containerToCheck = "HLXU3306892";
            response = this._yusenService.GetContainerAvailability(containerToCheck);
            Console.WriteLine(
                "Container {0}:  Is available: {1}  -   {2}",
                containerToCheck,
                response.IsAvailable,
                response.ReadyForDelivery);

            containerToCheck = "EXFU0582895";
            response = this._yusenService.GetContainerAvailability(containerToCheck);
            Console.WriteLine(
                "Container {0}:  Is available: {1}  -   {2}",
                containerToCheck,
                response.IsAvailable,
                response.ReadyForDelivery);

            containerToCheck = "NYKU5642384";
            response = this._yusenService.GetContainerAvailability(containerToCheck);
            Console.WriteLine(
                "Container {0}:  Is available: {1}  -   {2}",
                containerToCheck,
                response.IsAvailable,
                response.ReadyForDelivery);

            containerToCheck = "TCNU6037342";
            response = this._yusenService.GetContainerAvailability(containerToCheck);
            Console.WriteLine(
                "Container {0}:  Is available: {1}  -   {2}",
                containerToCheck,
                response.IsAvailable,
                response.ReadyForDelivery);
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IYusenService>().To(typeof(YusenService));
            this._yusenService = this.Kernel.Get<IYusenService>();
        }

        #endregion
    }
}