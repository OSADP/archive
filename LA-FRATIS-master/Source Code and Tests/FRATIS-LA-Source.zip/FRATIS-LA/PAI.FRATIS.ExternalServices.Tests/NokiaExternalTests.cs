﻿using System;
using System.Collections.Generic;
using System.Linq;

using NUnit.Framework;

using PAI.FRATIS.Domain.Geography.NokiaMaps;
using PAI.FRATIS.Tests;
using PAI.FRATIS.Wrappers.NokiaMaps;

using RestSharp;

namespace PAI.FRATIS.ExternalServices.Tests
{
    /// <summary>The nokia external tests.</summary>
    public class NokiaExternalTests : TestsBase
    {
        #region Public Methods and Operators

        [Test]
        public void Can_Execute_Simple_Nokia_Maps_Request()
        {
            var wrapper = new NokiaMapWrapper();
            //wrapper.GetRouteSummary();
        }

        [Test]
        public void Can_Get_Client()
        {
            RestRequest request = null;
            var wrapper = new NokiaMapWrapper();
            RestClient client = wrapper.GetNokiaRouteClient(out request);

            Assert.That(wrapper != null, "Wrapper is not instantiated");
            Assert.That(client != null, "Client is not instantiated");
            Assert.That(wrapper != null, "Request is not instantiated");
        }

        [Test]
        public void Can_Get_Incident_Summary()
        {
            var wrapper = new NokiaMapWrapper();
            TrafficItemList result = wrapper.GetIncidents(28.5961, -81.3467);
        }

        [Test]
        public void Can_Get_QuadKey()
        {
            var wrapper = new NokiaMapWrapper();
            string result = wrapper.GetCoordinatesQuadKey(28.5961, -81.3467, 8);
            Console.WriteLine(result);

            Assert.That(result == "03202130");
        }

        [Test]
        public void Can_Get_Route_Summary()
        {
            double pos1Lat = 28.600702;
            double pos1Long = -81.222509;
            double pos2Lat = 28.526005;
            double pos2Long = -81.378070;

            var wrapper = new NokiaMapWrapper();

            RouteSummary summary = wrapper.GetRouteSummary(pos1Lat, pos1Long, pos2Lat, pos2Long);
            Assert.That(wrapper != null, "Wrapper is not instantiated");

            Console.WriteLine(string.Format("Distance in Miles: {0}", summary.DistanceMiles));
            Console.WriteLine(string.Format("Base Travel Time: {0}", summary.BaseTime));
            Console.WriteLine(string.Format("Traffic Time: {0}", summary.TrafficTime));

            Assert.That(summary.Distance > 0, "Distance value is empty");
            Assert.That(summary.DistanceMiles > 0, "Distance miles is empty");
            Assert.That(summary.BaseTime > 0, "Base time is not set");

            //Corridor Project
            bool foundOnRamp = false;
            int foundOnRampAtIndex = 0;
            bool foundOffRamp = false;
            int foundOffRampAtIndex = 0;
            int index = 0;
            RouteManeuver? onRampRouteManeuver = null;
            RouteManeuver? offRampRouteManeuver = null;
            var routeManeuvers = new List<RouteManeuver>();
            foreach (RouteManeuver routeManeuver in summary.RouteManeuvers)
            {
                bool containsText = routeManeuver.Instruction.ToLower().Contains("sr-417")
                                    || routeManeuver.Instruction.ToLower().Contains("fl-417");
                if (!foundOnRamp && containsText)
                {
                    foundOnRampAtIndex = index;
                    onRampRouteManeuver = routeManeuver;
                    routeManeuvers.Add(routeManeuver);
                    foundOnRamp = true;
                    break;
                }
                index++;
            }
            index = 0;
            if (foundOnRamp)
            {
                foreach (RouteManeuver routeManeuver in summary.RouteManeuvers)
                {
                    if (index > foundOnRampAtIndex && routeManeuver.Instruction.ToLower().Contains("take exit"))
                    {
                        foundOffRampAtIndex = index;
                        offRampRouteManeuver = routeManeuver;
                        routeManeuvers.Add(routeManeuver);
                        foundOffRamp = true;
                        break;
                    }
                    index++;
                }
            }
            //See if there are any maneuvers in between the on and off ramp
            index = foundOnRampAtIndex + 1;
            while (foundOnRamp && foundOffRamp && foundOffRampAtIndex > index)
            {
                routeManeuvers.Add(summary.RouteManeuvers.ToArray()[index]);
                index++;
            }
            TimeSpan totalTravelTime = TimeSpan.Zero;
            double totalDistanceInMiles = 0;
            if (foundOnRamp && foundOffRamp)
            {
                foreach (RouteManeuver routeManeuver in routeManeuvers)
                {
                    totalTravelTime += TimeSpan.FromSeconds(routeManeuver.TravelTime);
                }
                totalDistanceInMiles = routeManeuvers.Sum(x => x.DistanceMiles);
            }
        }

        [Test]
        public void Can_Get_TileKeys()
        {
            var wrapper = new NokiaMapWrapper();
            MapTileZXY result = wrapper.GetCoordinatesZXY(28.5961, -81.3467, 8);

            Console.WriteLine(result.Z);
            Console.WriteLine(result.X);
            Console.WriteLine(result.Y);

            Assert.That(result.Z == 8);
            Assert.That(result.X == 70);
            Assert.That(result.Y == 106);
        }

        [SetUp]
        public void SetUp()
        {
        }

        #endregion
    }
}