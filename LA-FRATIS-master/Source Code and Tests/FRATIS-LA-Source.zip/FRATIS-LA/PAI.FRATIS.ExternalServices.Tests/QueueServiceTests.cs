﻿using System;

using NUnit.Framework;

using Ninject;

using PAI.FRATIS.DateTimeService;
using PAI.FRATIS.Tests;
using PAI.FRATIS.Wrappers.QueueTimes;

namespace PAI.FRATIS.ExternalServices.Tests
{
    /// <summary>The nokia external tests.</summary>
    public class QueueServiceTests : TestsBase
    {
        #region Fields

        private IDateTimeHelper _dateTimeHelper;

        private IQueueTimeService _queueService;

        #endregion

        #region Public Methods and Operators

        [Test]
        public void Can_Get_Current_Unix_Time_Ranges()
        {
            string start, end;
            this._queueService.GetUnixTime(DateTime.UtcNow, 30, false, out start, out end);

            Console.WriteLine(start);
            Console.WriteLine(end);
        }

        [Test]
        public void Can_Get_Current_Unix_Time_Ranges_Day_Before()
        {
            DateTime dtUtc = DateTime.UtcNow.Date.AddDays(-1).AddHours(23).AddMinutes(30);

            string start, end;
            this._queueService.GetUnixTime(dtUtc, 30, false, out start, out end);

            Console.WriteLine(start);
            Console.WriteLine(end);
        }

        [Test]
        public void Can_Get_Unix_Time_From_Date_Time()
        {
            double unixTime = this._dateTimeHelper.ConvertDateTimeToUnixTime(DateTime.UtcNow);
            Console.WriteLine(unixTime);
        }

        [Test]
        public void Can_Get_Xml_Report()
        {
            // Bobtail Gate
            TimeSpan result = this._queueService.GetQueueTimeNow("265716", "265782", 60);
            Console.WriteLine("\nCumulative Average: " + result);

            // Main Gate
            result = this._queueService.GetQueueTimeNow("265716", "265783", 60);
            Console.WriteLine("\nCumulative Average: " + result);

            result = this._queueService.GetQueueTimeNow("265716", "265714", 0);
            Console.WriteLine("\nCumulative Average: " + result);
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IQueueTimeService>().To(typeof(QueueTimeService));
            this.Kernel.Bind<IDateTimeHelper>().To(typeof(DateTimeHelper));

            this._queueService = this.Kernel.Get<IQueueTimeService>();
            this._dateTimeHelper = this.Kernel.Get<IDateTimeHelper>();
        }

        #endregion
    }
}