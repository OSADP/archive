﻿using System;
using System.Collections.Generic;

using NUnit.Framework;

using Ninject;

using PAI.FRATIS.Tests;
using PAI.FRATIS.Wrappers.WebFleet;
using PAI.FRATIS.Wrappers.WebFleet.Mapping;
using PAI.FRATIS.Wrappers.WebFleet.Model;
using PAI.FRATIS.Wrappers.WebFleet.Settings;

namespace PAI.FRATIS.ExternalServices.Tests
{
    /// <summary>The web fleet address tests.</summary>
    public class WebFleetAddressTests : TestsBase
    {
        #region Fields

        /// <summary>The address service.</summary>
        private IWebFleetAddressService _addressService;

        #endregion

        #region Public Methods and Operators

        [Test]
        public void Can_Calculate_Route()
        {
            var location1 = new WebFleetPosition { Latitude = 28.9084, Longitude = -82.0127 };

            WebFleetPosition l1 = this._addressService.GeocodeAddress("Miami", "33111", "", "");
            WebFleetPosition location2 = this._addressService.GeocodeAddress("Cumberland", "21502", "", "");

            WebFleetRouteEstimate result = this._addressService.CalculateRoute(
                new WebFleetSettings(), l1, location2, false, DateTime.Now.AddHours(3));

            Console.WriteLine(string.Format("Distance: {0}", result.Distance.Miles));
        }

        [Test]
        public void Can_Geocode_Address()
        {
            WebFleetPosition result = this._addressService.GeocodeAddress(
                "The Villages", "32162", "Pawleys Island Path", "2358");
            //var result = _addressService.GeocodeAddress("Huntsville", "35806", "OLD MADISON PIKE, NW BUILDING 340 BRIDGE ST SUITE 101", "6782");
            Console.WriteLine(string.Format("{0} {1}", result.Latitude, result.Longitude));

            result.LatitudeInt.ShouldNotBeNull();
            result.LongitudeInt.ShouldNotBeNull();
            result.LatitudeInt.ShouldNotEqual(0);
            result.LongitudeInt.ShouldNotEqual(0);
        }

        [Test]
        public void Can_Get_AddressIds_In_Group()
        {
            ICollection<string> result = this._addressService.GetWebFleetAddressIdsByGroupName("Customer");

            Assert.That(result != null, "Result is null");
            Assert.That(result.Count > 0, "No results found");

            Console.WriteLine("Found records: " + result.Count + "\n");
            int count = 0;
            foreach (string id in result)
            {
                if (count % 6 == 0)
                {
                    Console.Write("\n\t");
                }
                Console.Write(id + " ");
                count++;
            }
        }

        [Test]
        public void Can_Get_Addresses_In_Group()
        {
            ICollection<WebFleetAddress> result = this._addressService.GetWebFleetAddressesByGroupName("Customer");

            Assert.That(result != null, "Result is null");
            Assert.That(result.Count > 0, "No results found");

            Console.WriteLine("Found records: " + result.Count + "\n");
            foreach (WebFleetAddress address in result)
            {
                Console.WriteLine(
                    string.Format(
                        "\t{0}: {1} {2} {3} {4} {5} {6} {7}",
                        address.WebFleetId,
                        address.DisplayName,
                        address.StreetAddress,
                        address.City,
                        address.State,
                        address.Zip,
                        address.Phone,
                        address.Email));
            }
        }

        [Test]
        public void Can_Get_All_Addresses()
        {
            ICollection<WebFleetAddress> result = this._addressService.GetAddresses();

            Assert.That(result != null, "Result is null");

            Console.WriteLine(string.Format("Returned Addresses: {0}", result.Count));
            foreach (WebFleetAddress address in result)
            {
                Console.WriteLine(
                    string.Format(
                        "\t{0} {1} {2} {3} {4} {5} {6}",
                        address.DisplayName,
                        address.StreetAddress,
                        address.City,
                        address.State,
                        address.Zip,
                        address.Phone,
                        address.Email));
            }

            Assert.That(result.Count > 0, "No addresses returned from WebFleet");
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IWebFleetMessagesService>().To(typeof(WebFleetMessagesService));
            this.Kernel.Bind<IWebFleetObjectService>().To(typeof(WebFleetObjectService));
            this.Kernel.Bind<IWebFleetDriverService>().To(typeof(WebFleetDriverService));
            this.Kernel.Bind<IWebFleetAddressService>().To(typeof(WebFleetAddressService));
            this.Kernel.Bind<IWebFleetMappingService>().To(typeof(WebFleetMappingService));
            this.Kernel.Bind<IWebFleetOrderService>().To(typeof(WebFleetOrderService));

            this._addressService = this.Kernel.Get<IWebFleetAddressService>();
        }

        #endregion
    }
}