﻿using System;

using NUnit.Framework;

using Ninject;

using PAI.FRATIS.Tests;
using PAI.FRATIS.Wrappers.YahooWeather;

namespace PAI.FRATIS.ExternalServices.Tests
{
    /// <summary>The nokia external tests.</summary>
    public class WeatherServiceTests : TestsBase
    {
        #region Fields

        private IWeatherService _weatherService;

        #endregion

        #region Public Methods and Operators

        [Test]
        public void Can_Get_Location_Code()
        {
            string locationCode = "2442047"; // Los Angeles, CA

            string result = this._weatherService.GetLocationCode("The Villages", "Florida");
            Console.WriteLine(result);
            //Assert.That(result.LocationCode == locationCode);
            //Console.WriteLine(string.Format("Current Conditions: {0}", result.CurrentWeather));
        }

        [Test]
        public void Can_Get_Weather_Conditions()
        {
            string locationCode = "2442047"; // Los Angeles, CA

            WeatherResponse result = this._weatherService.GetWeather(locationCode);

            Assert.That(result.LocationCode == locationCode);
            Console.WriteLine(string.Format("Current Conditions: {0}", result.CurrentWeather));
        }

        [SetUp]
        public void SetUp()
        {
            this.Kernel.Bind<IWeatherService>().To(typeof(WeatherService));

            this._weatherService = this.Kernel.Get<IWeatherService>();
        }

        #endregion
    }
}