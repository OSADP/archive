﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PAI.FRATIS.Domain.Orders;

namespace PAI.FRATIS.Services
{
    public interface ITerminalExportManager
    {
        /// <summary>
        /// Get jobs needing to be exported
        /// </summary>
        /// <returns></returns>
        ICollection<Job> GetJobs();

        ICollection<RouteStop> GetRouteStops();

        /// <summary>
        /// Returns true of false based on whether the provided
        /// job needs exported
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        bool IsExportNeeded(Job job);

        bool IsExportNeeded(RouteStop routeStop);

        /// <summary>
        /// Gets the CSV Header for Jobs
        /// </summary>
        /// <returns></returns>
        string GetJobCSVHeader();

        /// <summary>
        /// Gets the CSV Values for a given Job
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        string GetJobCSV(Job job);

        string GetRouteStopCSVHeader();

        string GetRouteStopCSV(RouteStop rs);
    }
    public class TerminalExportManager : ITerminalExportManager
    {
        public ICollection<Job> GetJobs()
        {
            // TODO - get only updated jobs
            throw new NotImplementedException();
        }

        public ICollection<RouteStop> GetRouteStops()
        {
            throw new NotImplementedException();
        }

        public bool IsExportNeeded(Job job)
        {
            throw new NotImplementedException();
        }

        public bool IsExportNeeded(RouteStop routeStop)
        {
            throw new NotImplementedException();
        }

        public string GetJobCSVHeader()
        {
            // TODO - dynamic output via reflection
            return "Id,OrderNumber,ModifiedDate";
        }



        public string GetJobCSV(Job job)
        {
            // TODO - dynamic output via reflection
            var result = string.Empty;
            if (job != null && job.Id > 0)
            {
                result = string.Format("{0},{1},{2}", job.Id, job.OrderNumber, job.ModifiedDate);
            }
            return result;
        }

        public string GetRouteStopCSVHeader()
        {
            // TODO - dynamic output via reflection
            return "Id,JobId,ModifiedDate";
        }

        public string GetRouteStopCSV(RouteStop rs)
        {
            // TODO - dynamic output via reflection
            var result = string.Empty;
            if (rs != null && rs.Id > 0)
            {
                result = string.Format("{0},{1},{2}", rs.Id, rs.JobId, rs.ModifiedDate);
            }
            return result;
        }
    }
}
