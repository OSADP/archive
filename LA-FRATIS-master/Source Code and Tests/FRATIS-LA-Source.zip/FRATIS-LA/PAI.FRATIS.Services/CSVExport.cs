﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Reflection;
using System.Text;

namespace PAI.FRATIS.Services
{
    public class CsvExport<T>
        where T : class
    {
        #region Fields

        private readonly List<T> _objects;

        #endregion

        #region Constructors and Destructors

        public CsvExport(List<T> objects)
        {
            this._objects = objects;
        }

        #endregion

        #region Public Methods and Operators

        public string Export()
        {
            return this.Export(true);
        }

        public string Export(bool includeHeaderLine)
        {
            var sb = new StringBuilder();
            //Get properties using reflection.
            IList<PropertyInfo> propertyInfos = typeof(T).GetProperties();

            if (includeHeaderLine)
            {
                //add header line.
                foreach (PropertyInfo propertyInfo in propertyInfos)
                {
                    if (this.PropertyInfoMatch(propertyInfo))
                    {
                        sb.Append(propertyInfo.Name).Append(",");
                    }
                }

                sb.Remove(sb.Length - 1, 1).AppendLine();
            }

            //add value for each property.
            foreach (T obj in this._objects)
            {
                foreach (PropertyInfo propertyInfo in propertyInfos)
                {
                    if (this.PropertyInfoMatch(propertyInfo))
                    {
                        sb.Append(this.MakeValueCsvFriendly(propertyInfo.GetValue(obj, null))).Append(",");
                    }
                }

                sb.Remove(sb.Length - 1, 1).AppendLine();
            }

            return sb.ToString();
        }

        //export to a file.

        //export as binary data.
        public byte[] ExportToBytes()
        {
            return Encoding.UTF8.GetBytes(this.Export());
        }

        public void ExportToFile(string path)
        {
            File.WriteAllText(path, this.Export());
        }

        #endregion

        //get the csv value for field.

        #region Methods

        private string MakeValueCsvFriendly(object value)
        {
            if (value == null)
            {
                return "";
            }
            if (value is Nullable && ((INullable)value).IsNull)
            {
                return "";
            }

            if (value is DateTime)
            {
                if (((DateTime)value).TimeOfDay.TotalSeconds == 0)
                {
                    return ((DateTime)value).ToString("yyyy-MM-dd");
                }
                return ((DateTime)value).ToString("yyyy-MM-dd HH:mm:ss");
            }
            string output = value.ToString();

            if (output.Contains(",") || output.Contains("\""))
            {
                output = '"' + output.Replace("\"", "\"\"") + '"';
            }

            return output;
        }

        private bool PropertyInfoMatch(PropertyInfo pinfo)
        {
            if (pinfo.PropertyType == typeof(int) || pinfo.PropertyType == typeof(int?)
                || pinfo.PropertyType == typeof(string) || pinfo.PropertyType == typeof(bool)
                || pinfo.PropertyType == typeof(bool?) || pinfo.PropertyType.IsPrimitive)
            {
                return true;
            }
            return false;
        }

        #endregion
    }
}