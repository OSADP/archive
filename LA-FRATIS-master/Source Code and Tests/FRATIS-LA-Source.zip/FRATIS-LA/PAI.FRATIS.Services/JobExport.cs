using System.Collections.Generic;
using System.Text;

using PAI.FRATIS.Web.Models.Orders;

namespace PAI.FRATIS.Services
{
    public class JobExport
    {
        #region Public Methods and Operators

        public string ExportComplete(IEnumerable<JobModel> jobs)
        {
            var result = new StringBuilder();
            result.AppendLine(this.GetCompleteHeader());
            foreach (JobModel j in jobs)
            {
                int count = 0;
                foreach (RouteStopModel rs in j.RouteStops)
                {
                    count++;
                    result.AppendLine(this.GetCompleteRow(j, rs, count));
                }
            }
            return result.ToString();
        }

        public string ExportJobs(IEnumerable<JobModel> jobs, bool includeRoutes = false)
        {
            var result = new StringBuilder();
            result.AppendLine(this.GetJobHeader());
            foreach (JobModel j in jobs)
            {
                result.AppendLine(this.GetJobRow(j));
                if (includeRoutes && j.RouteStops != null)
                {
                    foreach (RouteStopModel rs in j.RouteStops)
                    {
                        result.AppendLine(this.GetRouteStopRow(j, rs, true));
                    }
                }
            }
            return result.ToString();
        }

        public string ExportRoutes(IEnumerable<JobModel> jobs)
        {
            var result = new StringBuilder();
            result.AppendLine(this.GetRouteStopHeader());
            foreach (JobModel j in jobs)
            {
                if (j.RouteStops != null)
                {
                    foreach (RouteStopModel rs in j.RouteStops)
                    {
                        result.AppendLine(this.GetRouteStopRow(j, rs));
                    }
                }
            }
            return result.ToString();
        }

        public string GetCompleteRow(JobModel job, RouteStopModel rs, int? sortOrder = null)
        {
            if (job == null)
            {
                return string.Empty;
            }
            if (rs == null)
            {
                return string.Empty;
            }

            try
            {
                string assignment = "Unassigned";
                if (job.AssignedDriver != null)
                {
                    assignment = job.AssignedDriver.DisplayName;
                }

                if (sortOrder == null)
                {
                    sortOrder = rs.SortOrder;
                }

                return string.Format(
                    "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}",
                    job.Id,
                    job.DueDate.Value.Date.ToShortDateString(),
                    job.OrderNumber,
                    assignment,
                    rs.Id,
                    sortOrder,
                    rs.Location.DisplayName,
                    rs.StopAction.ShortName,
                    rs.WindowStartDateTime.Value.ToShortTimeString(),
                    rs.WindowEndDateTime.Value.ToShortTimeString(),
                    rs.StopDelay.Value);
            }
            catch
            {
                return string.Format("Id{0},Error", rs.Id);
            }
        }

        #endregion

        #region Methods

        private string GetCompleteHeader()
        {
            return
                string.Format(
                    "JobId,Job Due Date,Order Number,Driver Assignment,StopId,Stop Sequence,Stop/Location Name,Stop Action,Start Window,End Window,Stop Time");
        }

        private string GetJobHeader()
        {
            return string.Format("JobId,Job Due Date,Order Number,Driver Assignment");
        }

        private string GetJobRow(JobModel job)
        {
            if (job == null)
            {
                return string.Empty;
            }

            string assignment = "Unassigned";
            if (job.AssignedDriver != null)
            {
                assignment = job.AssignedDriver.DisplayName;
            }

            return string.Format(
                "{0},{1},{2},{3}", job.Id, job.DueDate.Value.Date.ToShortDateString(), job.OrderNumber, assignment);
        }

        private string GetRouteStopHeader(bool jobReportFormatting = false)
        {
            string prefix = string.Empty;
            if (jobReportFormatting)
            {
                prefix = ",,,";
            }

            return string.Format("{0}StopId,Stop/Location Name,Stop Action,Start Window,End Window,Stop Time", prefix);
        }

        private string GetRouteStopRow(JobModel job, RouteStopModel rs, bool jobReportFormatting = false)
        {
            if (rs == null)
            {
                return string.Empty;
            }

            string prefix = string.Empty;
            if (jobReportFormatting)
            {
                prefix = ",,,";
            }

            try
            {
                return string.Format(
                    "{0}{1},{2},{3},{4},{5},{6}",
                    prefix,
                    rs.Id,
                    rs.Location.DisplayName,
                    rs.StopAction.ShortName,
                    rs.WindowStartDateTime.Value.ToShortTimeString(),
                    rs.WindowEndDateTime.Value.ToShortTimeString(),
                    rs.StopDelay.Value);
            }
            catch
            {
                return string.Format("Id{0},Error", rs.Id);
            }
        }

        #endregion
    }
}