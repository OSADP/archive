//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;

using PAI.Core;
using PAI.FRATIS.DataServices.Core.Caching;
using PAI.FRATIS.Domain;
using PAI.FRATIS.Infrastructure.Data;

namespace PAI.FRATIS.DataServices.Core
{
    /// <summary>
    /// Represents the base class for basic <see cref="PAI.FRATIS.Domain.EntityBase"/> services
    /// </summary>
    /// <typeparam name="TEntity"></typeparam>
    public class EntityServiceBase<TEntity> : IEntityServiceBase<TEntity>
        where TEntity : EntityBase
    {
        #region Fields

        protected readonly ICacheManager _cacheManager;

        protected readonly IRepository<TEntity> _repository;

        protected bool _enableCaching = true;
            
        protected bool _enableEventPublishing = true;

        private string _cachePatternKey;

        #endregion

        #region Constructors and Destructors

        public EntityServiceBase(IRepository<TEntity> repository, ICacheManager cacheManager)
        {
            this._repository = repository;
            this._cacheManager = cacheManager;
        }

        #endregion

        #region Public Properties

        public string CachePatternAllKey
        {
            get
            {
                return this.CachePatternKey + "All";
            }
        }

        public virtual string CachePatternKey
        {
            get
            {
                if (string.IsNullOrWhiteSpace(this._cachePatternKey))
                {
                    string name = typeof(TEntity).FullName.Replace("+", ".");
                    this._cachePatternKey = name + ".";
                }
                return this._cachePatternKey;
            }
        }

        #endregion

        #region Properties

        protected virtual string CacheByIdPatternKey
        {
            get
            {
                return this.CachePatternKey + "id-{0}";
            }
        }

        #endregion

        #region Public Methods and Operators

        public void Attach(TEntity entity, bool markDirty = false)
        {
            if (entity != null)
            {
                this._repository.Attach(entity, markDirty);
            }
        }

        /// <summary>
        /// Clear cache
        /// </summary>
        public virtual void ClearCache()
        {
            if (this._enableCaching)
            {
                this._cacheManager.RemoveByPattern(this.CachePatternKey);
            }
        }

        /// <summary>
        /// Deletes an entity
        /// </summary>
        /// <param name="entity">entity</param>
        public virtual void Delete(TEntity entity, bool saveChanges = true)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            var archivedEntity = entity as IArchivedEntity;
            if (archivedEntity != null)
            {
                archivedEntity.IsDeleted = true;
                this._repository.Update(archivedEntity as TEntity, true);
            }
            else
            {
                this._repository.Delete(entity, saveChanges);
            }

            // remove entity from cache
            if (this._enableCaching)
            {
                this._cacheManager.RemoveByPattern(string.Format(this.CacheByIdPatternKey, entity.Id));
            }
        }

        /// <summary>
        /// Gets an entity 
        /// </summary>
        /// <param name="entityId">entity identifier</param>
        /// <returns>Entity</returns>
        public void Delete(int entityId, bool saveChanges = true)
        {
            TEntity entity = this.GetById(entityId);
            if (entity != null)
            {
                Delete(entity);
            }
        }

        /// <summary>
        /// Gets an entity 
        /// </summary>
        /// <param name="entityId">entity identifier</param>
        /// <returns>Entity</returns>
        public virtual TEntity GetById(int entityId)
        {
            if (this._enableCaching)
            {
                string key = string.Format(this.CacheByIdPatternKey, entityId);

                return this.InternalGetById(entityId);

                //TEntity entity;
                //if (_cacheManager.Get(key, () => InternalGetById(entityId), out entity))
                //{
                //    _repository.Attach(entity);
                //}
                //return entity;
            }
            return this.InternalGetById(entityId);
        }

        /// <summary>
        /// Inserts an entity
        /// </summary>
        /// <param name="entity">Entity</param>
        public virtual void Insert(TEntity entity, bool saveChanges = true)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            if (entity is IDatedEntity)
            {
                var datedEntity = entity as IDatedEntity;
                datedEntity.CreatedDate = DateTime.UtcNow;
            }

            this._repository.Insert(entity, saveChanges);
        }

        /// <summary>
        /// Inserts or Updates the given entity
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="saveChanges"></param>
        public virtual void InsertOrUpdate(TEntity entity, bool saveChanges = true)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            // simple check for now, should probably check if EF attached
            if (entity.Id == 0)
            {
                this.Insert(entity, saveChanges);
            }
            else
            {
                this.Update(entity, saveChanges);
            }
        }

        public void InsertOrUpdate(ICollection<TEntity> entities, bool saveChanges = true)
        {
            if (entities != null)
            {
                foreach (TEntity entity in entities)
                {
                    InsertOrUpdate(entity, false);
                }

                if (saveChanges)
                {
                    this.SaveChanges();
                }
            }
        }

        public void SaveChanges()
        {
            this._repository.SaveChanges();
        }

        /// <summary>
        /// Gets an <see cref="IQueryable"/> of <see cref="TEntity"/>
        /// </summary>
        /// <returns><see cref="IQueryable"/> of <see cref="TEntity"/></returns>
        public virtual IQueryable<TEntity> Select()
        {
            return this.InternalSelect();
        }

        /// <summary>
        /// Updates the entity
        /// </summary>
        /// <param name="entity">Entity</param>
        public virtual void Update(TEntity entity, bool saveChanges = true)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }

            if (entity is IDatedEntity)
            {
                var datedEntity = entity as IDatedEntity;
                datedEntity.ModifiedDate = DateTime.UtcNow;
            }

            this._repository.Update(entity, saveChanges);

            // remove entity from cache
            if (this._enableCaching)
            {
                this._cacheManager.RemoveByPattern(string.Format(this.CacheByIdPatternKey, entity.Id));
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets an <see cref="TEntity"/> by id
        /// Override to select eagerly when necessary
        /// </summary>
        /// <returns><see cref="TEntity"/></returns>
        protected virtual TEntity InternalGetById(int entityId)
        {
            return this.InternalSelect().FirstOrDefault(entity => entity.Id == entityId);
        }

        /// <summary>
        /// Gets an <see cref="IQueryable"/> of <see cref="TEntity"/>
        /// Override to select eagerly when necessary
        /// </summary>
        /// <returns><see cref="IQueryable"/> of <see cref="TEntity"/></returns>
        protected virtual IQueryable<TEntity> InternalSelect()
        {
            return this._repository.Select();
        }

        protected IQueryable<TEntity> InternalSelectSimple()
        {
            return this._repository.Select();
        }

        #endregion
    }
}