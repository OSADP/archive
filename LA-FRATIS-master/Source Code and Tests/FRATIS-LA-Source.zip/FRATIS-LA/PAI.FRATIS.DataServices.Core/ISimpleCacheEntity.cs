namespace PAI.FRATIS.DataServices.Core
{

}
