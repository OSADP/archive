//    Copyright 2014 Productivity Apex Inc.
//        http://www.productivityapex.com/
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web;

namespace PAI.FRATIS.DataServices.Core.Caching
{
    /// <summary>
    /// Represents a PerRequest Cache Manager
    /// </summary>
    public class PerRequestCacheManager : ICacheManager
    {
        #region Fields

        private readonly HttpContextBase _context;

        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="context">Context</param>
        public PerRequestCacheManager(HttpContextBase context)
        {
            this._context = context;
        }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Clear all cache data
        /// </summary>
        public void Clear()
        {
            IDictionary items = this.GetItems();
            if (items == null)
            {
                return;
            }

            IDictionaryEnumerator enumerator = items.GetEnumerator();
            var keysToRemove = new List<string>();
            while (enumerator.MoveNext())
            {
                keysToRemove.Add(enumerator.Key.ToString());
            }

            foreach (string key in keysToRemove)
            {
                items.Remove(key);
            }
        }

        /// <summary>
        /// Gets or sets the value associated with the specified key.
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="key">The key of the value to get.</param>
        /// <returns>The value associated with the specified key.</returns>
        public T Get<T>(string key)
        {
            IDictionary items = this.GetItems();
            if (items == null)
            {
                return default(T);
            }

            return (T)items[key];
        }

        /// <summary>
        /// Gets a value indicating whether the value associated with the specified key is cached
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>Result</returns>
        public bool IsSet(string key)
        {
            IDictionary items = this.GetItems();
            if (items == null)
            {
                return false;
            }

            return (items[key] != null);
        }

        /// <summary>
        /// Removes the value with the specified key from the cache
        /// </summary>
        /// <param name="key">/key</param>
        public void Remove(string key)
        {
            IDictionary items = this.GetItems();
            if (items == null)
            {
                return;
            }

            items.Remove(key);
        }

        /// <summary>
        /// Removes items by pattern
        /// </summary>
        /// <param name="pattern">pattern</param>
        public void RemoveByPattern(string pattern)
        {
            IDictionary items = this.GetItems();
            if (items == null)
            {
                return;
            }

            IDictionaryEnumerator enumerator = items.GetEnumerator();
            var regex = new Regex(pattern, RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            var keysToRemove = new List<string>();
            while (enumerator.MoveNext())
            {
                if (regex.IsMatch(enumerator.Key.ToString()))
                {
                    keysToRemove.Add(enumerator.Key.ToString());
                }
            }

            foreach (string key in keysToRemove)
            {
                items.Remove(key);
            }
        }

        /// <summary>
        /// Adds the specified key and object to the cache.
        /// </summary>
        /// <param name="key">key</param>
        /// <param name="data">Data</param>
        /// <param name="cacheTime">Cache time</param>
        public void Set(string key, object data, int cacheTime)
        {
            IDictionary items = this.GetItems();

            if (items == null)
            {
                return;
            }

            if (data == null)
            {
                return;
            }

            if (items.Contains(key))
            {
                items[key] = data;
            }
            else
            {
                items.Add(key, data);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Returns the items contained in this cache
        /// </summary>
        protected IDictionary GetItems()
        {
            return this._context != null ? this._context.Items : null;
        }

        #endregion
    }
}