using System.Collections.Generic;

namespace PAI.FRATIS.DataServices.Core
{
    /// <summary>The GetAllEntity interface.</summary>
    /// <typeparam name="T"></typeparam>
    public interface IGetAllEntity<T> where T: Domain.EntityBase
    {
        /// <summary>
        /// Gets all of the entity objects from the database
        /// </summary>
        /// <returns></returns>
        ICollection<T> GetAll();
    }
}
